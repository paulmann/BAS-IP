/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: basip_smoke
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB-0+deb12u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `access_schedules`
--

DROP TABLE IF EXISTS `access_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_schedules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL DEFAULT '',
  `resident_id` bigint(20) unsigned DEFAULT NULL,
  `days` varchar(32) NOT NULL DEFAULT '1,2,3,4,5,6,7',
  `start_time` varchar(5) NOT NULL DEFAULT '00:00',
  `end_time` varchar(5) NOT NULL DEFAULT '23:59',
  `effect` varchar(16) NOT NULL DEFAULT 'allow',
  `priority` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `notes` longtext DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `access_schedules_resident_id_is_active_index` (`resident_id`,`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_schedules`
--

LOCK TABLES `access_schedules` WRITE;
/*!40000 ALTER TABLE `access_schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `access_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(190) NOT NULL DEFAULT '',
  `body` longtext DEFAULT NULL,
  `level` varchar(16) NOT NULL DEFAULT 'info',
  `audience` varchar(24) NOT NULL DEFAULT 'active',
  `is_published` tinyint(1) NOT NULL DEFAULT 0,
  `pin` tinyint(1) NOT NULL DEFAULT 0,
  `publish_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `views` int(11) NOT NULL DEFAULT 0,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `announcements_is_published_publish_at_index` (`is_published`,`publish_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
INSERT INTO `announcements` VALUES
(1,'Профилактика шлагбаума','В субботу с 10:00 до 12:00 проведём ТО привода.\nВ это время шлагбаум открывается диспетчером по телефону.\n\nСпасибо за понимание!','warning','active',1,1,'2026-10-09 18:58:38','2026-10-16 19:58:38',0,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38');
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_tokens`
--

DROP TABLE IF EXISTS `api_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL DEFAULT '',
  `token_hash` varchar(128) NOT NULL DEFAULT '',
  `prefix` varchar(16) DEFAULT NULL,
  `scopes` longtext DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `expires_at` datetime DEFAULT NULL,
  `last_used_at` datetime DEFAULT NULL,
  `last_used_ip` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_tokens_token_hash_unique` (`token_hash`),
  KEY `api_tokens_is_active_index` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_tokens`
--

LOCK TABLES `api_tokens` WRITE;
/*!40000 ALTER TABLE `api_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `api_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_state`
--

DROP TABLE IF EXISTS `app_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_state` (
  `key` varchar(120) NOT NULL,
  `value` longtext DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_state`
--

LOCK TABLES `app_state` WRITE;
/*!40000 ALTER TABLE `app_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_log`
--

DROP TABLE IF EXISTS `audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `occurred_at` datetime DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `actor_name` varchar(120) DEFAULT NULL,
  `actor_role` varchar(24) DEFAULT NULL,
  `action` varchar(48) NOT NULL DEFAULT '',
  `subject_type` varchar(48) DEFAULT NULL,
  `subject_id` varchar(64) DEFAULT NULL,
  `subject_label` varchar(190) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(512) DEFAULT NULL,
  `request_id` varchar(32) DEFAULT NULL,
  `changes` longtext DEFAULT NULL,
  `meta` longtext DEFAULT NULL,
  `is_security` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `audit_log_occurred_at_index` (`occurred_at`),
  KEY `audit_log_user_id_occurred_at_index` (`user_id`,`occurred_at`),
  KEY `audit_log_subject_type_subject_id_index` (`subject_type`,`subject_id`),
  KEY `audit_log_action_index` (`action`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_log`
--

LOCK TABLES `audit_log` WRITE;
/*!40000 ALTER TABLE `audit_log` DISABLE KEYS */;
INSERT INTO `audit_log` VALUES
(1,'2026-10-09 19:58:40',NULL,'system','system','billing.charge.create','charge','2','CHG-2026-0001',NULL,'cli',NULL,NULL,'{\"total\":15000,\"participants\":20,\"per_unit\":750,\"allocation\":\"equal\",\"period\":\"Сентябрь 2026\"}',0),
(2,'2026-10-09 19:58:40',NULL,'system','system','billing.payment.record','payment','13','Иванов И. И. · 750 ₽',NULL,'cli',NULL,NULL,'{\"resident_id\":1,\"amount\":750,\"allocated\":[{\"invoice_id\":23,\"number\":\"INV-2026-00001\",\"applied\":750,\"status\":\"paid\"}],\"overpay\":0}',0),
(3,'2026-10-09 19:58:40',NULL,'system','system','billing.payment.record','payment','14','Петрова М. П. · 750 ₽',NULL,'cli',NULL,NULL,'{\"resident_id\":2,\"amount\":750,\"allocated\":[{\"invoice_id\":24,\"number\":\"INV-2026-00002\",\"applied\":750,\"status\":\"paid\"}],\"overpay\":0}',0),
(4,'2026-10-09 19:58:40',NULL,'system','system','billing.charge.recalc','charge','2','CHG-2026-0001',NULL,'cli',NULL,'{\"before\":{\"total\":15000,\"participants\":20,\"per_unit\":750},\"after\":{\"total\":18000,\"participants\":22,\"per_unit\":818.18},\"diff\":{\"total\":{\"from\":15000,\"to\":18000},\"participants\":{\"from\":20,\"to\":22},\"per_unit\":{\"from\":750,\"to\":818.18}}}','{\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\",\"adjustments\":20,\"new\":2,\"credits\":0}',0),
(5,'2026-10-09 19:58:40',NULL,'system','system','billing.notify','charge','2','CHG-2026-0001',NULL,'cli',NULL,NULL,'{\"queued\":38,\"skipped\":4,\"template\":\"payment_new\",\"batch_id\":1}',0),
(6,'2026-10-09 19:58:46',NULL,'system','system','gate.open','resident','1','Иванов Иван Иванович',NULL,'cli',NULL,NULL,'{\"access_type\":\"own\",\"source\":\"cli\",\"device\":\"main\",\"event_id\":400}',0),
(7,'2026-10-09 19:58:46',NULL,'system','system','guest.create','guest_pass','7','8AYG-6MMX',NULL,'cli',NULL,NULL,'{\"resident_id\":1,\"resident\":\"Иванов Иван Иванович\",\"ttl_hours\":12,\"valid_until\":\"2026-10-10 07:58:46\",\"guest_name\":\"Курьер\",\"car_plate\":null,\"purpose\":null,\"created_by_type\":\"resident\"}',0),
(8,'2026-10-09 19:58:46',NULL,'system','system','gate.open','resident','1','Иванов Иван Иванович (гость Курьер)',NULL,'cli',NULL,NULL,'{\"access_type\":\"guest\",\"source\":\"web\",\"device\":\"main\",\"event_id\":402}',0),
(9,'2026-10-09 19:58:46',NULL,'system','system','guest.revoke','guest_pass','7','8AYG-6MMX',NULL,'cli',NULL,NULL,'{\"reason\":\"smoke\",\"resident_id\":1}',1),
(10,'2026-10-09 19:58:46',NULL,'system','system','data.export','export_job','1','residents-20261009-195846.csv',NULL,'cli',NULL,NULL,'{\"rows\":24,\"format\":\"csv\",\"filters\":{\"status\":\"all\"}}',1),
(11,'2026-10-09 19:58:46',NULL,'system','system','data.import','import_job','1','upload',NULL,'cli',NULL,NULL,'{\"format\":\"csv\",\"mode\":\"dry-run\",\"total\":24,\"imported\":0,\"updated\":24,\"failed\":0,\"dry_run\":true}',1),
(12,'2026-10-09 19:58:46',NULL,'system','system','data.export','export_job','2','residents-20261009-195846.json',NULL,'cli',NULL,NULL,'{\"rows\":24,\"format\":\"json\",\"filters\":{\"status\":\"all\"}}',1);
/*!40000 ALTER TABLE `audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backups`
--

DROP TABLE IF EXISTS `backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(512) NOT NULL DEFAULT '',
  `type` varchar(16) NOT NULL DEFAULT 'db',
  `size_bytes` int(11) NOT NULL DEFAULT 0,
  `checksum` varchar(64) DEFAULT NULL,
  `driver` varchar(24) DEFAULT NULL,
  `encrypted` tinyint(1) NOT NULL DEFAULT 0,
  `status` varchar(16) NOT NULL DEFAULT 'done',
  `note` longtext DEFAULT NULL,
  `meta` longtext DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `backups_created_at_index` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backups`
--

LOCK TABLES `backups` WRITE;
/*!40000 ALTER TABLE `backups` DISABLE KEYS */;
/*!40000 ALTER TABLE `backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_history`
--

DROP TABLE IF EXISTS `billing_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `billing_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `occurred_at` datetime DEFAULT NULL,
  `resident_id` bigint(20) unsigned DEFAULT NULL,
  `entity` varchar(24) NOT NULL DEFAULT 'invoice',
  `entity_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(32) NOT NULL DEFAULT '',
  `amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `balance_before` decimal(14,2) NOT NULL DEFAULT 0.00,
  `balance_after` decimal(14,2) NOT NULL DEFAULT 0.00,
  `details` longtext DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `billing_history_resident_id_occurred_at_index` (`resident_id`,`occurred_at`),
  KEY `billing_history_entity_entity_id_index` (`entity`,`entity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_history`
--

LOCK TABLES `billing_history` WRITE;
/*!40000 ALTER TABLE `billing_history` DISABLE KEYS */;
INSERT INTO `billing_history` VALUES
(1,'2026-10-02 00:00:00',1,'payment',1,'paid',750.00,0.00,0.00,'{\"demo\":true}',NULL),
(2,'2026-10-23 00:00:00',2,'payment',2,'paid',750.00,0.00,0.00,'{\"demo\":true}',NULL),
(3,'2026-10-14 00:00:00',3,'payment',3,'paid',375.00,0.00,0.00,'{\"demo\":true}',NULL),
(4,'2026-10-02 00:00:00',7,'payment',4,'paid',750.00,0.00,0.00,'{\"demo\":true}',NULL),
(5,'2026-10-03 00:00:00',9,'payment',5,'paid',750.00,0.00,0.00,'{\"demo\":true}',NULL),
(6,'2026-10-24 00:00:00',10,'payment',6,'paid',375.00,0.00,0.00,'{\"demo\":true}',NULL),
(7,'2026-10-18 00:00:00',13,'payment',7,'paid',750.00,0.00,0.00,'{\"demo\":true}',NULL),
(8,'2026-10-17 00:00:00',14,'payment',8,'paid',750.00,0.00,0.00,'{\"demo\":true}',NULL),
(9,'2026-10-09 00:00:00',15,'payment',9,'paid',375.00,0.00,0.00,'{\"demo\":true}',NULL),
(10,'2026-10-20 00:00:00',20,'payment',10,'paid',750.00,0.00,0.00,'{\"demo\":true}',NULL),
(11,'2026-10-07 00:00:00',21,'payment',11,'paid',750.00,0.00,0.00,'{\"demo\":true}',NULL),
(12,'2026-10-02 00:00:00',22,'payment',12,'paid',375.00,0.00,0.00,'{\"demo\":true}',NULL),
(13,'2026-10-09 19:58:40',1,'invoice',NULL,'issued',750.00,-150.00,-150.00,'{\"charge_id\":2,\"number\":\"INV-2026-00001\",\"period\":\"Сентябрь 2026\"}',NULL),
(14,'2026-10-09 19:58:40',2,'invoice',NULL,'issued',750.00,100.00,100.00,'{\"charge_id\":2,\"number\":\"INV-2026-00002\",\"period\":\"Сентябрь 2026\"}',NULL),
(15,'2026-10-09 19:58:40',3,'invoice',NULL,'issued',750.00,-375.00,-375.00,'{\"charge_id\":2,\"number\":\"INV-2026-00003\",\"period\":\"Сентябрь 2026\"}',NULL),
(16,'2026-10-09 19:58:40',5,'invoice',NULL,'issued',750.00,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00004\",\"period\":\"Сентябрь 2026\"}',NULL),
(17,'2026-10-09 19:58:40',6,'invoice',NULL,'issued',750.00,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00005\",\"period\":\"Сентябрь 2026\"}',NULL),
(18,'2026-10-09 19:58:40',7,'invoice',NULL,'issued',750.00,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00006\",\"period\":\"Сентябрь 2026\"}',NULL),
(19,'2026-10-09 19:58:40',9,'invoice',NULL,'issued',750.00,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00007\",\"period\":\"Сентябрь 2026\"}',NULL),
(20,'2026-10-09 19:58:40',10,'invoice',NULL,'issued',750.00,-375.00,-375.00,'{\"charge_id\":2,\"number\":\"INV-2026-00008\",\"period\":\"Сентябрь 2026\"}',NULL),
(21,'2026-10-09 19:58:40',11,'invoice',NULL,'issued',750.00,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00009\",\"period\":\"Сентябрь 2026\"}',NULL),
(22,'2026-10-09 19:58:40',12,'invoice',NULL,'issued',750.00,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00010\",\"period\":\"Сентябрь 2026\"}',NULL),
(23,'2026-10-09 19:58:40',13,'invoice',NULL,'issued',750.00,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00011\",\"period\":\"Сентябрь 2026\"}',NULL),
(24,'2026-10-09 19:58:40',14,'invoice',NULL,'issued',750.00,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00012\",\"period\":\"Сентябрь 2026\"}',NULL),
(25,'2026-10-09 19:58:40',15,'invoice',NULL,'issued',750.00,-375.00,-375.00,'{\"charge_id\":2,\"number\":\"INV-2026-00013\",\"period\":\"Сентябрь 2026\"}',NULL),
(26,'2026-10-09 19:58:40',16,'invoice',NULL,'issued',750.00,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00014\",\"period\":\"Сентябрь 2026\"}',NULL),
(27,'2026-10-09 19:58:40',18,'invoice',NULL,'issued',750.00,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00015\",\"period\":\"Сентябрь 2026\"}',NULL),
(28,'2026-10-09 19:58:40',20,'invoice',NULL,'issued',750.00,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00016\",\"period\":\"Сентябрь 2026\"}',NULL),
(29,'2026-10-09 19:58:40',21,'invoice',NULL,'issued',750.00,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00017\",\"period\":\"Сентябрь 2026\"}',NULL),
(30,'2026-10-09 19:58:40',22,'invoice',NULL,'issued',750.00,-375.00,-375.00,'{\"charge_id\":2,\"number\":\"INV-2026-00018\",\"period\":\"Сентябрь 2026\"}',NULL),
(31,'2026-10-09 19:58:40',23,'invoice',NULL,'issued',750.00,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00019\",\"period\":\"Сентябрь 2026\"}',NULL),
(32,'2026-10-09 19:58:40',24,'invoice',NULL,'issued',750.00,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00020\",\"period\":\"Сентябрь 2026\"}',NULL),
(33,'2026-10-09 19:58:40',1,'payment',13,'paid',750.00,-150.00,-150.00,'{\"allocated\":[{\"invoice_id\":23,\"number\":\"INV-2026-00001\",\"applied\":750,\"status\":\"paid\"}],\"overpay\":0,\"method\":\"cash\"}',NULL),
(34,'2026-10-09 19:58:40',2,'payment',14,'paid',750.00,100.00,100.00,'{\"allocated\":[{\"invoice_id\":24,\"number\":\"INV-2026-00002\",\"applied\":750,\"status\":\"paid\"}],\"overpay\":0,\"method\":\"transfer\"}',NULL),
(35,'2026-10-09 19:58:40',1,'invoice',43,'adjusted',68.19,-150.00,-150.00,'{\"charge_id\":2,\"number\":\"INV-2026-00021-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(36,'2026-10-09 19:58:40',2,'invoice',44,'adjusted',68.19,100.00,100.00,'{\"charge_id\":2,\"number\":\"INV-2026-00022-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(37,'2026-10-09 19:58:40',3,'invoice',45,'adjusted',68.19,-375.00,-375.00,'{\"charge_id\":2,\"number\":\"INV-2026-00023-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(38,'2026-10-09 19:58:40',5,'invoice',46,'adjusted',68.19,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00024-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(39,'2026-10-09 19:58:40',6,'invoice',47,'adjusted',68.18,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00025-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(40,'2026-10-09 19:58:40',7,'invoice',48,'adjusted',68.18,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00026-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(41,'2026-10-09 19:58:40',9,'invoice',49,'adjusted',68.18,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00027-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(42,'2026-10-09 19:58:40',10,'invoice',50,'adjusted',68.18,-375.00,-375.00,'{\"charge_id\":2,\"number\":\"INV-2026-00028-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(43,'2026-10-09 19:58:40',11,'invoice',51,'adjusted',68.18,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00029-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(44,'2026-10-09 19:58:40',12,'invoice',52,'adjusted',68.18,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00030-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(45,'2026-10-09 19:58:40',13,'invoice',53,'adjusted',68.18,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00031-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(46,'2026-10-09 19:58:40',14,'invoice',54,'adjusted',68.18,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00032-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(47,'2026-10-09 19:58:40',15,'invoice',55,'adjusted',68.18,-375.00,-375.00,'{\"charge_id\":2,\"number\":\"INV-2026-00033-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(48,'2026-10-09 19:58:40',16,'invoice',56,'adjusted',68.18,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00034-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(49,'2026-10-09 19:58:40',18,'invoice',57,'adjusted',68.18,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00035-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(50,'2026-10-09 19:58:40',20,'invoice',58,'adjusted',68.18,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00036-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(51,'2026-10-09 19:58:40',21,'invoice',59,'adjusted',68.18,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00037-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(52,'2026-10-09 19:58:40',22,'invoice',60,'adjusted',68.18,-375.00,-375.00,'{\"charge_id\":2,\"number\":\"INV-2026-00038-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(53,'2026-10-09 19:58:40',23,'invoice',61,'adjusted',68.18,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00039-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(54,'2026-10-09 19:58:40',24,'invoice',62,'adjusted',68.18,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00040-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(55,'2026-10-09 19:58:40',8,'invoice',63,'adjusted',818.18,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00041\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(56,'2026-10-09 19:58:40',19,'invoice',64,'adjusted',818.18,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00042\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL);
/*!40000 ALTER TABLE `billing_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cars`
--

DROP TABLE IF EXISTS `cars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cars` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `resident_id` bigint(20) unsigned NOT NULL,
  `plate` varchar(32) NOT NULL DEFAULT '',
  `plate_normalized` varchar(32) NOT NULL DEFAULT '',
  `brand` varchar(64) DEFAULT NULL,
  `model` varchar(64) DEFAULT NULL,
  `color` varchar(32) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `type` varchar(16) NOT NULL DEFAULT 'car',
  `rfid_tag` varchar(64) DEFAULT NULL,
  `sticker` varchar(32) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `valid_from` datetime DEFAULT NULL,
  `valid_until` datetime DEFAULT NULL,
  `notes` longtext DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cars_resident_id_index` (`resident_id`),
  KEY `cars_plate_normalized_index` (`plate_normalized`),
  KEY `cars_is_active_index` (`is_active`),
  CONSTRAINT `cars_resident_id_fk` FOREIGN KEY (`resident_id`) REFERENCES `residents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cars`
--

LOCK TABLES `cars` WRITE;
/*!40000 ALTER TABLE `cars` DISABLE KEYS */;
INSERT INTO `cars` VALUES
(1,1,'А366ММ132','A366MM132','Geely','Coolray','серый',2017,'car','RFID-C2FCD9E9',NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(2,2,'А489СК68','A489SK68','Lada','Vesta','серебристый',2022,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(3,2,'Е603ХР37','E603HR37','Lada','Vesta','серебристый',2015,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(4,3,'А593СВ193','A593SV193','Chery','Tiggo 7','чёрный',2010,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(5,3,'М544РО132','M544RO132','Nissan','Qashqai','чёрный',2024,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(6,3,'Н212МО26','N212MO26','Chery','Tiggo 7','чёрный',2023,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(7,4,'М983ЕН54','M983EN54','BMW','X5','белый',2022,'car','RFID-C01FF939',NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(8,5,'Х576ЕК146','H576EK146','Chery','Tiggo 7','красный',2019,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(9,5,'В864КТ38','V864KT38','Hyundai','Solaris','красный',2015,'car',NULL,NULL,0,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(10,6,'Т855ВУ99','T855VU99','Chery','Tiggo 7','красный',2020,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(11,6,'С153НУ52','S153NU52','Nissan','Qashqai','красный',2010,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(12,6,'У635СВ144','U635SV144','Kia','Rio','чёрный',2019,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(13,7,'Н366ОУ103','N366OU103','Lada','Vesta','синий',2010,'car','RFID-A05E68CC',NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(14,8,'Р659ТК10','R659TK10','Skoda','Octavia','красный',2021,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(15,8,'Н144КР146','N144KR146','Nissan','Qashqai','красный',2010,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(16,9,'Н609ММ61','N609MM61','Volkswagen','Polo','синий',2013,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(17,9,'А182ВУ185','A182VU185','Skoda','Octavia','серый',2017,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(18,9,'Х534НЕ79','H534NE79','Renault','Duster','чёрный',2017,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(19,10,'Х302МХ144','H302MH144','Hyundai','Solaris','чёрный',2013,'car','RFID-F2AD33A0',NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(20,11,'У699ЕН63','U699EN63','Chery','Tiggo 7','серебристый',2017,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(21,11,'К849АУ196','K849AU196','Geely','Coolray','чёрный',2012,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(22,12,'Т824АЕ42','T824AE42','Volkswagen','Polo','синий',2017,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(23,12,'Х167МО113','H167MO113','BMW','X5','синий',2021,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(24,12,'А851МВ163','A851MV163','Hyundai','Solaris','синий',2011,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(25,13,'К567НН150','K567NN150','Hyundai','Solaris','белый',2011,'car','RFID-8D459DFA',NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(26,14,'Р840КА96','R840KA96','Nissan','Qashqai','белый',2019,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(27,14,'Р052ВТ92','R052VT92','Renault','Duster','белый',2014,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(28,15,'В244ВМ190','V244VM190','BMW','X5','синий',2016,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(29,15,'А221АУ190','A221AU190','Nissan','Qashqai','серый',2014,'car',NULL,NULL,0,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(30,15,'Т198ВУ60','T198VU60','BMW','X5','белый',2011,'car',NULL,NULL,0,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(31,16,'Р084СР22','R084SR22','Lada','Vesta','чёрный',2017,'car','RFID-645C9ACC',NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(32,17,'Е084УЕ134','E084UE134','Volkswagen','Polo','белый',2024,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(33,17,'Н693ВУ196','N693VU196','Lada','Vesta','красный',2017,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(34,18,'Х203СА42','H203SA42','Nissan','Qashqai','красный',2023,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(35,18,'У949АУ180','U949AU180','Skoda','Octavia','чёрный',2025,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(36,18,'Х671ЕУ72','H671EU72','Haval','Jolion','красный',2015,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(37,19,'Е409ТУ74','E409TU74','Nissan','Qashqai','белый',2013,'car','RFID-43C59A36',NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(38,20,'Р446СС186','R446SS186','Renault','Duster','красный',2017,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(39,20,'Х187НХ104','H187NH104','BMW','X5','красный',2021,'car',NULL,NULL,0,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(40,21,'Х166СС71','H166SS71','Nissan','Qashqai','серый',2022,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(41,21,'Е960ОН11','E960ON11','Toyota','Camry','синий',2014,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(42,21,'К152АО37','K152AO37','Hyundai','Solaris','синий',2011,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(43,22,'М904НО130','M904NO130','Hyundai','Solaris','синий',2015,'car','RFID-6531DDB1',NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(44,23,'Т056АХ105','T056AH105','Lada','Vesta','синий',2012,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(45,23,'В368ВН44','V368VN44','Haval','Jolion','чёрный',2021,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(46,24,'А311УС152','A311US152','Nissan','Qashqai','красный',2016,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(47,24,'Н856ОА10','N856OA10','Geely','Coolray','синий',2010,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(48,24,'О478УМ36','O478UM36','Volkswagen','Polo','чёрный',2013,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38');
/*!40000 ALTER TABLE `cars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charges`
--

DROP TABLE IF EXISTS `charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `charges` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `number` varchar(48) NOT NULL DEFAULT '',
  `title` varchar(190) NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `period_start` date DEFAULT NULL,
  `period_end` date DEFAULT NULL,
  `period_label` varchar(64) NOT NULL DEFAULT '',
  `total_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `active_count` int(11) NOT NULL DEFAULT 0,
  `per_unit_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `allocation` varchar(16) NOT NULL DEFAULT 'equal',
  `due_days` int(11) NOT NULL DEFAULT 14,
  `due_date` date DEFAULT NULL,
  `message` longtext DEFAULT NULL,
  `pay_link` longtext DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'draft',
  `recalc_of` bigint(20) unsigned DEFAULT NULL,
  `recalc_reason` varchar(255) DEFAULT NULL,
  `invoices_total` int(11) NOT NULL DEFAULT 0,
  `invoices_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `paid_count` int(11) NOT NULL DEFAULT 0,
  `notes` longtext DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `issued_at` datetime DEFAULT NULL,
  `closed_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `charges_uuid_unique` (`uuid`),
  KEY `charges_status_index` (`status`),
  KEY `charges_period_start_index` (`period_start`),
  KEY `charges_recalc_of_index` (`recalc_of`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charges`
--

LOCK TABLES `charges` WRITE;
/*!40000 ALTER TABLE `charges` DISABLE KEYS */;
INSERT INTO `charges` VALUES
(1,'018f93d2-0a10-4963-bd56-9a452b2d79e7','НАЧ-2026-09-0001','Обслуживание шлагбаума, Сентябрь 2026','Демо-начисление: обслуживание привода, видеонаблюдение, связь, ТО.','2026-09-01','2026-09-30','Сентябрь 2026',15000.00,20,750.00,'equal',14,'2026-10-14','Здравствуйте, {name}!\n\nНачислена оплата за обслуживание шлагбаума за {period}: {amount}.\nСрок оплаты: {due_date}.\n\nОплатить: {pay_link}','https://pay.example.com/barrier?apt={apartment}&amount={amount}','issued',NULL,NULL,22,15050.00,7500.00,8,NULL,NULL,'2026-09-30 00:00:00',NULL,'2026-09-30 00:00:00','2026-10-09 19:58:40'),
(2,'f04e1bbd-ef34-41db-9aab-91a7c4cb5af8','CHG-2026-0001','Smoke, Сентябрь 2026',NULL,'2026-09-01','2026-09-30','Сентябрь 2026',18000.00,22,818.18,'equal',14,'2026-10-23',NULL,NULL,'issued',NULL,'Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22',42,18000.00,1500.00,2,NULL,NULL,'2026-10-09 19:58:40',NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40');
/*!40000 ALTER TABLE `charges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `resident_id` bigint(20) unsigned NOT NULL,
  `type` varchar(16) NOT NULL DEFAULT 'phone',
  `value` varchar(190) NOT NULL DEFAULT '',
  `value_normalized` varchar(190) DEFAULT NULL,
  `label` varchar(40) DEFAULT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT 0,
  `notify` tinyint(1) NOT NULL DEFAULT 1,
  `verified` tinyint(1) NOT NULL DEFAULT 0,
  `verified_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contacts_resident_id_type_index` (`resident_id`,`type`),
  KEY `contacts_value_normalized_index` (`value_normalized`),
  CONSTRAINT `contacts_resident_id_fk` FOREIGN KEY (`resident_id`) REFERENCES `residents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` VALUES
(1,1,'phone','+79077593446','+79077593446','мобильный',1,1,1,NULL,'2026-10-09 19:58:38'),
(2,1,'phone','+79060971867','+79060971867','второй',0,1,1,NULL,'2026-10-09 19:58:38'),
(3,1,'phone','+74959531952','+74959531952','домашний',0,0,1,NULL,'2026-10-09 19:58:38'),
(4,1,'email','Ivanov.i1@example.com','ivanov.i1@example.com','основная',1,1,1,NULL,'2026-10-09 19:58:38'),
(5,1,'email','work.ivanov@company.example','work.ivanov@company.example','рабочая',0,0,1,NULL,'2026-10-09 19:58:38'),
(6,2,'phone','+79079283500','+79079283500','мобильный',1,1,0,NULL,'2026-10-09 19:58:38'),
(7,2,'email','Petrova.m2@example.com','petrova.m2@example.com','основная',1,1,0,NULL,'2026-10-09 19:58:38'),
(8,2,'telegram','@petrova2','@petrova2','telegram',1,1,0,NULL,'2026-10-09 19:58:38'),
(9,3,'phone','+79071925462','+79071925462','мобильный',1,1,0,NULL,'2026-10-09 19:58:38'),
(10,3,'phone','+79055380041','+79055380041','второй',0,1,0,NULL,'2026-10-09 19:58:38'),
(11,3,'email','Sidorov.a3@example.com','sidorov.a3@example.com','основная',1,1,0,NULL,'2026-10-09 19:58:38'),
(12,4,'phone','+79055684610','+79055684610','мобильный',1,1,1,NULL,'2026-10-09 19:58:38'),
(13,4,'phone','+74957134513','+74957134513','домашний',0,0,1,NULL,'2026-10-09 19:58:38'),
(14,4,'email','Kuznecova.o4@example.com','kuznecova.o4@example.com','основная',1,1,1,NULL,'2026-10-09 19:58:38'),
(15,4,'telegram','@kuznecova4','@kuznecova4','telegram',1,1,1,NULL,'2026-10-09 19:58:38'),
(16,5,'phone','+79052326473','+79052326473','мобильный',1,1,0,NULL,'2026-10-09 19:58:38'),
(17,5,'phone','+79085074585','+79085074585','второй',0,1,0,NULL,'2026-10-09 19:58:38'),
(18,5,'email','Smirnov.d5@example.com','smirnov.d5@example.com','основная',1,1,0,NULL,'2026-10-09 19:58:38'),
(19,5,'email','work.smirno@company.example','work.smirno@company.example','рабочая',0,0,0,NULL,'2026-10-09 19:58:38'),
(20,6,'phone','+79018714791','+79018714791','мобильный',1,1,0,NULL,'2026-10-09 19:58:38'),
(21,6,'email','Vasileva.a6@example.com','vasileva.a6@example.com','основная',1,1,0,NULL,'2026-10-09 19:58:38'),
(22,6,'telegram','@vasileva6','@vasileva6','telegram',1,1,0,NULL,'2026-10-09 19:58:38'),
(23,7,'phone','+79048639433','+79048639433','мобильный',1,1,1,NULL,'2026-10-09 19:58:38'),
(24,7,'phone','+79047246968','+79047246968','второй',0,1,1,NULL,'2026-10-09 19:58:38'),
(25,7,'phone','+74959801952','+74959801952','домашний',0,0,1,NULL,'2026-10-09 19:58:38'),
(26,7,'email','Sokolov.s7@example.com','sokolov.s7@example.com','основная',1,1,1,NULL,'2026-10-09 19:58:38'),
(27,8,'phone','+79094656270','+79094656270','мобильный',1,1,0,NULL,'2026-10-09 19:58:38'),
(28,8,'email','Mihaylova.e8@example.com','mihaylova.e8@example.com','основная',1,1,0,NULL,'2026-10-09 19:58:38'),
(29,8,'telegram','@mihaylova8','@mihaylova8','telegram',1,1,0,NULL,'2026-10-09 19:58:38'),
(30,9,'phone','+79062181099','+79062181099','мобильный',1,1,0,NULL,'2026-10-09 19:58:38'),
(31,9,'phone','+79066686169','+79066686169','второй',0,1,0,NULL,'2026-10-09 19:58:38'),
(32,9,'email','Fedorov.a9@example.com','fedorov.a9@example.com','основная',1,1,0,NULL,'2026-10-09 19:58:38'),
(33,9,'email','work.fedoro@company.example','work.fedoro@company.example','рабочая',0,0,0,NULL,'2026-10-09 19:58:38'),
(34,10,'phone','+79056133849','+79056133849','мобильный',1,1,1,NULL,'2026-10-09 19:58:38'),
(35,10,'phone','+74957874070','+74957874070','домашний',0,0,1,NULL,'2026-10-09 19:58:38'),
(36,10,'email','Morozova.n10@example.com','morozova.n10@example.com','основная',1,1,1,NULL,'2026-10-09 19:58:38'),
(37,10,'telegram','@morozova10','@morozova10','telegram',1,1,1,NULL,'2026-10-09 19:58:38'),
(38,11,'phone','+79056592424','+79056592424','мобильный',1,1,0,NULL,'2026-10-09 19:58:38'),
(39,11,'phone','+79060703828','+79060703828','второй',0,1,0,NULL,'2026-10-09 19:58:38'),
(40,11,'email','Volkov.p11@example.com','volkov.p11@example.com','основная',1,1,0,NULL,'2026-10-09 19:58:38'),
(41,12,'phone','+79097998532','+79097998532','мобильный',1,1,0,NULL,'2026-10-09 19:58:38'),
(42,12,'email','Alekseeva.e12@example.com','alekseeva.e12@example.com','основная',1,1,0,NULL,'2026-10-09 19:58:38'),
(43,12,'telegram','@alekseeva12','@alekseeva12','telegram',1,1,0,NULL,'2026-10-09 19:58:38'),
(44,13,'phone','+79012985243','+79012985243','мобильный',1,1,1,NULL,'2026-10-09 19:58:38'),
(45,13,'phone','+79069884039','+79069884039','второй',0,1,1,NULL,'2026-10-09 19:58:38'),
(46,13,'phone','+74952178814','+74952178814','домашний',0,0,1,NULL,'2026-10-09 19:58:38'),
(47,13,'email','Lebedev.n13@example.com','lebedev.n13@example.com','основная',1,1,1,NULL,'2026-10-09 19:58:38'),
(48,13,'email','work.lebede@company.example','work.lebede@company.example','рабочая',0,0,1,NULL,'2026-10-09 19:58:38'),
(49,14,'phone','+79075649845','+79075649845','мобильный',1,1,0,NULL,'2026-10-09 19:58:38'),
(50,14,'email','Semenova.t14@example.com','semenova.t14@example.com','основная',1,1,0,NULL,'2026-10-09 19:58:38'),
(51,14,'telegram','@semenova14','@semenova14','telegram',1,1,0,NULL,'2026-10-09 19:58:38'),
(52,15,'phone','+79060573286','+79060573286','мобильный',1,1,0,NULL,'2026-10-09 19:58:38'),
(53,15,'phone','+79063775896','+79063775896','второй',0,1,0,NULL,'2026-10-09 19:58:38'),
(54,15,'email','Egorov.v15@example.com','egorov.v15@example.com','основная',1,1,0,NULL,'2026-10-09 19:58:38'),
(55,16,'phone','+79017894122','+79017894122','мобильный',1,1,1,NULL,'2026-10-09 19:58:38'),
(56,16,'phone','+74957480741','+74957480741','домашний',0,0,1,NULL,'2026-10-09 19:58:38'),
(57,16,'email','Pavlova.y16@example.com','pavlova.y16@example.com','основная',1,1,1,NULL,'2026-10-09 19:58:38'),
(58,16,'telegram','@pavlova16','@pavlova16','telegram',1,1,1,NULL,'2026-10-09 19:58:38'),
(59,17,'phone','+79042648978','+79042648978','мобильный',1,1,0,NULL,'2026-10-09 19:58:38'),
(60,17,'phone','+79030155627','+79030155627','второй',0,1,0,NULL,'2026-10-09 19:58:38'),
(61,17,'email','Kozlov.i17@example.com','kozlov.i17@example.com','основная',1,1,0,NULL,'2026-10-09 19:58:38'),
(62,17,'email','work.kozlov@company.example','work.kozlov@company.example','рабочая',0,0,0,NULL,'2026-10-09 19:58:38'),
(63,18,'phone','+79013485844','+79013485844','мобильный',1,1,0,NULL,'2026-10-09 19:58:38'),
(64,18,'email','Stepanova.m18@example.com','stepanova.m18@example.com','основная',1,1,0,NULL,'2026-10-09 19:58:38'),
(65,18,'telegram','@stepanova18','@stepanova18','telegram',1,1,0,NULL,'2026-10-09 19:58:38'),
(66,19,'phone','+79051837970','+79051837970','мобильный',1,1,1,NULL,'2026-10-09 19:58:38'),
(67,19,'phone','+79055747244','+79055747244','второй',0,1,1,NULL,'2026-10-09 19:58:38'),
(68,19,'phone','+74952919123','+74952919123','домашний',0,0,1,NULL,'2026-10-09 19:58:38'),
(69,19,'email','Nikolaev.a19@example.com','nikolaev.a19@example.com','основная',1,1,1,NULL,'2026-10-09 19:58:38'),
(70,20,'phone','+79050789102','+79050789102','мобильный',1,1,0,NULL,'2026-10-09 19:58:38'),
(71,20,'email','Orlova.o20@example.com','orlova.o20@example.com','основная',1,1,0,NULL,'2026-10-09 19:58:38'),
(72,20,'telegram','@orlova20','@orlova20','telegram',1,1,0,NULL,'2026-10-09 19:58:38'),
(73,21,'phone','+79093707173','+79093707173','мобильный',1,1,0,NULL,'2026-10-09 19:58:38'),
(74,21,'phone','+79070879601','+79070879601','второй',0,1,0,NULL,'2026-10-09 19:58:38'),
(75,21,'email','Andreev.d21@example.com','andreev.d21@example.com','основная',1,1,0,NULL,'2026-10-09 19:58:38'),
(76,21,'email','work.andree@company.example','work.andree@company.example','рабочая',0,0,0,NULL,'2026-10-09 19:58:38'),
(77,22,'phone','+79063223589','+79063223589','мобильный',1,1,1,NULL,'2026-10-09 19:58:38'),
(78,22,'phone','+74951255416','+74951255416','домашний',0,0,1,NULL,'2026-10-09 19:58:38'),
(79,22,'email','Makarova.a22@example.com','makarova.a22@example.com','основная',1,1,1,NULL,'2026-10-09 19:58:38'),
(80,22,'telegram','@makarova22','@makarova22','telegram',1,1,1,NULL,'2026-10-09 19:58:38'),
(81,23,'phone','+79022534178','+79022534178','мобильный',1,1,0,NULL,'2026-10-09 19:58:38'),
(82,23,'phone','+79042663381','+79042663381','второй',0,1,0,NULL,'2026-10-09 19:58:38'),
(83,23,'email','Zaharov.s23@example.com','zaharov.s23@example.com','основная',1,1,0,NULL,'2026-10-09 19:58:38'),
(84,24,'phone','+79069693134','+79069693134','мобильный',1,1,0,NULL,'2026-10-09 19:58:38'),
(85,24,'email','Zayceva.e24@example.com','zayceva.e24@example.com','основная',1,1,0,NULL,'2026-10-09 19:58:38'),
(86,24,'telegram','@zayceva24','@zayceva24','telegram',1,1,0,NULL,'2026-10-09 19:58:38');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `devices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL DEFAULT '',
  `slug` varchar(64) NOT NULL DEFAULT '',
  `driver` varchar(24) NOT NULL DEFAULT 'basip',
  `base_url` varchar(255) DEFAULT NULL,
  `login` varchar(120) DEFAULT NULL,
  `password_enc` longtext DEFAULT NULL,
  `channel` int(11) NOT NULL DEFAULT 1,
  `location` varchar(190) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `options` longtext DEFAULT NULL,
  `last_seen_at` datetime DEFAULT NULL,
  `last_status` longtext DEFAULT NULL,
  `error_count` int(11) NOT NULL DEFAULT 0,
  `notes` longtext DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `devices_slug_unique` (`slug`),
  KEY `devices_is_active_index` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devices`
--

LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `export_jobs`
--

DROP TABLE IF EXISTS `export_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `export_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `kind` varchar(32) NOT NULL DEFAULT 'residents',
  `format` varchar(12) NOT NULL DEFAULT 'csv',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `rows` int(11) NOT NULL DEFAULT 0,
  `size_bytes` int(11) NOT NULL DEFAULT 0,
  `filters` longtext DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `export_jobs_uuid_unique` (`uuid`),
  KEY `export_jobs_created_at_index` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `export_jobs`
--

LOCK TABLES `export_jobs` WRITE;
/*!40000 ALTER TABLE `export_jobs` DISABLE KEYS */;
INSERT INTO `export_jobs` VALUES
(1,'16a188f0-5a2d-4109-b9fb-83b836324088','residents','csv','residents-20261009-195846.csv',24,9781,'{\"status\":\"all\"}',NULL,NULL,'2026-10-09 19:58:46','2026-10-10 19:58:46'),
(2,'23401e77-d5d2-464b-aa9a-719440198f70','residents','json','residents-20261009-195846.json',24,96917,'{\"status\":\"all\"}',NULL,NULL,'2026-10-09 19:58:46','2026-10-10 19:58:46');
/*!40000 ALTER TABLE `export_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gate_events`
--

DROP TABLE IF EXISTS `gate_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gate_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `occurred_at` datetime DEFAULT NULL,
  `device_id` bigint(20) unsigned DEFAULT NULL,
  `channel` int(11) NOT NULL DEFAULT 1,
  `actor_type` varchar(24) NOT NULL DEFAULT 'system',
  `resident_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `guest_pass_id` bigint(20) unsigned DEFAULT NULL,
  `actor_name` varchar(190) DEFAULT NULL,
  `apartment` varchar(24) DEFAULT NULL,
  `access_type` varchar(24) NOT NULL DEFAULT 'own',
  `action` varchar(16) NOT NULL DEFAULT 'open',
  `source` varchar(24) NOT NULL DEFAULT 'web',
  `result` varchar(16) NOT NULL DEFAULT 'success',
  `reason` varchar(190) DEFAULT NULL,
  `plate` varchar(32) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(512) DEFAULT NULL,
  `request_id` varchar(32) DEFAULT NULL,
  `duration_ms` int(11) DEFAULT NULL,
  `device_response` longtext DEFAULT NULL,
  `meta` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gate_events_occurred_at_index` (`occurred_at`),
  KEY `gate_events_resident_id_occurred_at_index` (`resident_id`,`occurred_at`),
  KEY `gate_events_access_type_occurred_at_index` (`access_type`,`occurred_at`),
  KEY `gate_events_result_index` (`result`),
  KEY `gate_events_guest_pass_id_index` (`guest_pass_id`),
  KEY `gate_events_device_id_occurred_at_index` (`device_id`,`occurred_at`)
) ENGINE=InnoDB AUTO_INCREMENT=405 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gate_events`
--

LOCK TABLES `gate_events` WRITE;
/*!40000 ALTER TABLE `gate_events` DISABLE KEYS */;
INSERT INTO `gate_events` VALUES
(1,'66e149da-c0cf-4ad8-bd17-df24cfe8b83e','2026-09-10 18:55:24',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','own','open','admin','success',NULL,NULL,'192.168.1.57',NULL,NULL,632,NULL,'{\"demo\":true}'),
(2,'ebb7e3c7-6e0e-4806-9ebd-31c26b21b301','2026-09-10 20:17:32',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','own','open','api','success',NULL,NULL,'192.168.1.141',NULL,NULL,609,NULL,'{\"demo\":true}'),
(3,'5ed07dc4-86f4-44fc-9424-83670424ed20','2026-09-10 21:58:41',NULL,1,'admin',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','manual','open','api','success',NULL,NULL,'192.168.1.132',NULL,NULL,897,NULL,'{\"demo\":true}'),
(4,'b902f767-bec8-4333-b57b-8dd6aa985c9a','2026-09-10 11:37:47',NULL,1,'admin',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','manual','open','api','success',NULL,NULL,'192.168.1.128',NULL,NULL,364,NULL,'{\"demo\":true}'),
(5,'6a691030-9e57-489b-9fc2-3680bd0dc34f','2026-09-10 14:02:45',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','admin','success',NULL,NULL,'192.168.1.55',NULL,NULL,627,NULL,'{\"demo\":true}'),
(6,'eeb931df-d2ec-42c5-86b6-b850cf5f3d91','2026-09-10 21:10:05',NULL,1,'resident',22,NULL,NULL,'Макарова Анна Петровна','22','own','open','api','success',NULL,NULL,'192.168.1.225',NULL,NULL,369,NULL,'{\"demo\":true}'),
(7,'8efae458-5bf7-486f-8888-7e0093efd02d','2026-09-11 06:37:19',NULL,1,'guest',9,NULL,NULL,'Фёдоров Андрей Иванович','9','guest','open','api','success',NULL,NULL,'192.168.1.81',NULL,NULL,740,NULL,'{\"demo\":true}'),
(8,'72ff529d-0ed2-4934-a9d9-92355553f844','2026-09-11 13:30:56',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','own','open','telegram','success',NULL,NULL,'192.168.1.167',NULL,NULL,830,NULL,'{\"demo\":true}'),
(9,'d36e8792-3cc1-41af-b308-ebc55d7a411b','2026-09-11 22:33:06',NULL,1,'guest',20,NULL,NULL,'Орлова Ольга Андреевич','20','guest','open','cabinet','success',NULL,NULL,'192.168.1.193',NULL,NULL,321,NULL,'{\"demo\":true}'),
(10,'2e3ca71a-9d9f-44b3-9a01-f90b9d95bc74','2026-09-11 10:42:37',NULL,1,'resident',20,NULL,NULL,'Орлова Ольга Андреевич','20','own','open','cabinet','success',NULL,NULL,'192.168.1.221',NULL,NULL,492,NULL,'{\"demo\":true}'),
(11,'12989398-9589-48ec-afdc-5cc8916a6542','2026-09-12 11:28:43',NULL,1,'admin',2,NULL,NULL,'Петрова Мария Петрович','2','manual','open','cabinet','success',NULL,NULL,'192.168.1.177',NULL,NULL,574,NULL,'{\"demo\":true}'),
(12,'017de4f0-84ba-44c3-a173-f6eec0a03b5d','2026-09-12 17:20:25',NULL,1,'admin',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','manual','open','admin','success',NULL,NULL,'192.168.1.184',NULL,NULL,260,NULL,'{\"demo\":true}'),
(13,'4e9395e7-a4fb-432a-910f-60d02bce713d','2026-09-12 07:57:31',NULL,1,'guest',17,NULL,NULL,'Козлов Иван Иванович','17','guest','open','api','success',NULL,NULL,'192.168.1.120',NULL,NULL,233,NULL,'{\"demo\":true}'),
(14,'44c23562-14c2-4bc5-98ac-4b3813bad701','2026-09-12 06:28:03',NULL,1,'resident',6,NULL,NULL,'Васильева Анна Петровна','6','own','open','admin','success',NULL,NULL,'192.168.1.135',NULL,NULL,175,NULL,'{\"demo\":true}'),
(15,'cdef536c-807b-4d7b-84a1-ae670ee7ce83','2026-09-12 23:09:19',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','own','open','cabinet','success',NULL,NULL,'192.168.1.107',NULL,NULL,826,NULL,'{\"demo\":true}'),
(16,'49c6d7fe-bb19-432d-bfed-69ffc4f3ef5f','2026-09-12 22:03:34',NULL,1,'guest',13,NULL,NULL,'Лебедев Николай Ивановна','13','guest','open','admin','success',NULL,NULL,'192.168.1.163',NULL,NULL,598,NULL,'{\"demo\":true}'),
(17,'ad4686a7-3dcb-45f1-8134-f43345496857','2026-09-12 14:03:46',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','own','open','cabinet','success',NULL,NULL,'192.168.1.43',NULL,NULL,538,NULL,'{\"demo\":true}'),
(18,'95f1bca5-336e-4356-8fc1-1385ccb0d0e6','2026-09-12 10:58:28',NULL,1,'resident',16,NULL,NULL,'Павлова Юлия Николаевич','16','own','open','api','success',NULL,NULL,'192.168.1.100',NULL,NULL,149,NULL,'{\"demo\":true}'),
(19,'06fa377f-5014-4d89-8807-4dc274cdb43a','2026-09-12 22:27:22',NULL,1,'guest',15,NULL,NULL,'Егоров Виктор Сергеевна','15','guest','open','web','success',NULL,NULL,'192.168.1.150',NULL,NULL,567,NULL,'{\"demo\":true}'),
(20,'be1e749e-6d15-477b-94a4-1bd57d462de6','2026-09-12 06:50:46',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','own','open','api','success',NULL,NULL,'192.168.1.150',NULL,NULL,789,NULL,'{\"demo\":true}'),
(21,'340172c5-ff5d-4403-b9df-f43ea0b0764c','2026-09-12 23:27:31',NULL,1,'resident',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','own','open','admin','success',NULL,NULL,'192.168.1.183',NULL,NULL,351,NULL,'{\"demo\":true}'),
(22,'51402a06-1bfe-4539-8a3f-eca607583c1f','2026-09-12 16:17:22',NULL,1,'guest',13,NULL,NULL,'Лебедев Николай Ивановна','13','guest','open','telegram','success',NULL,NULL,'192.168.1.122',NULL,NULL,144,NULL,'{\"demo\":true}'),
(23,'eb2e586c-5047-44bd-b2bd-f3093233ca14','2026-09-12 23:33:12',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','own','open','admin','success',NULL,NULL,'192.168.1.217',NULL,NULL,802,NULL,'{\"demo\":true}'),
(24,'ff317784-2bb0-4082-b423-5b7068851edc','2026-09-13 15:00:33',NULL,1,'resident',6,NULL,NULL,'Васильева Анна Петровна','6','own','open','api','success',NULL,NULL,'192.168.1.151',NULL,NULL,875,NULL,'{\"demo\":true}'),
(25,'4ef252a8-7b5a-49c8-a655-16d49e05fa1f','2026-09-13 14:19:10',NULL,1,'guest',17,NULL,NULL,'Козлов Иван Иванович','17','guest','open','admin','success',NULL,NULL,'192.168.1.32',NULL,NULL,137,NULL,'{\"demo\":true}'),
(26,'ba62b9a9-2203-48e9-9136-5516f878f265','2026-09-13 17:28:05',NULL,1,'resident',11,NULL,NULL,'Волков Павел Сергеевич','11','own','open','api','success',NULL,NULL,'192.168.1.67',NULL,NULL,457,NULL,'{\"demo\":true}'),
(27,'ed8821a2-a62e-4fbb-a7d8-2cd3e559029d','2026-09-13 15:14:09',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','plate','open','admin','success',NULL,NULL,'192.168.1.152',NULL,NULL,157,NULL,'{\"demo\":true}'),
(28,'308b0a37-dfbd-4fea-80e8-502dc471cd5b','2026-09-13 16:37:26',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','own','open','admin','success',NULL,NULL,'192.168.1.97',NULL,NULL,517,NULL,'{\"demo\":true}'),
(29,'10384fd0-9bba-46db-be87-8fea93ebfa35','2026-09-13 19:21:33',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','plate','open','cabinet','success',NULL,NULL,'192.168.1.186',NULL,NULL,530,NULL,'{\"demo\":true}'),
(30,'903db650-3829-4864-a434-47c6b0e076aa','2026-09-14 22:52:38',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','own','open','web','success',NULL,NULL,'192.168.1.48',NULL,NULL,649,NULL,'{\"demo\":true}'),
(31,'df3e944b-a6f3-4bff-bff1-9b3fcf53476f','2026-09-14 07:59:56',NULL,1,'admin',8,NULL,NULL,'Михайлова Елена Николаевич','8','manual','open','cabinet','success',NULL,NULL,'192.168.1.221',NULL,NULL,686,NULL,'{\"demo\":true}'),
(32,'479dde91-3eeb-462e-8e6d-bafe117b89bb','2026-09-14 23:44:31',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','admin','success',NULL,NULL,'192.168.1.163',NULL,NULL,212,NULL,'{\"demo\":true}'),
(33,'3cdeb321-4d71-43ad-894f-c2b38eede860','2026-09-14 06:39:17',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','own','open','admin','success',NULL,NULL,'192.168.1.192',NULL,NULL,536,NULL,'{\"demo\":true}'),
(34,'c3d64221-724a-4041-b605-3a89f08a4869','2026-09-14 11:23:25',NULL,1,'guest',6,NULL,NULL,'Васильева Анна Петровна','6','guest','open','api','success',NULL,NULL,'192.168.1.218',NULL,NULL,639,NULL,'{\"demo\":true}'),
(35,'6439ba73-1d24-4185-b9bb-248df2605a8a','2026-09-14 17:41:57',NULL,1,'resident',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','own','open','admin','success',NULL,NULL,'192.168.1.194',NULL,NULL,289,NULL,'{\"demo\":true}'),
(36,'a58712ec-da43-46f2-8dda-8d1bcebf1554','2026-09-14 07:30:13',NULL,1,'admin',1,NULL,NULL,'Иванов Иван Иванович','1','manual','open','admin','success',NULL,NULL,'192.168.1.139',NULL,NULL,239,NULL,'{\"demo\":true}'),
(37,'de6810e3-3dc9-458b-a89e-543a3870abea','2026-09-14 22:11:44',NULL,1,'guest',14,NULL,NULL,'Семёнова Татьяна Петровна','14','guest','denied','telegram','denied','Доступ приостановлен',NULL,'192.168.1.236',NULL,NULL,637,NULL,'{\"demo\":true}'),
(38,'d949015a-c5d0-4efc-8579-547c3855b55e','2026-09-14 20:03:05',NULL,1,'guest',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','guest','open','admin','success',NULL,NULL,'192.168.1.38',NULL,NULL,536,NULL,'{\"demo\":true}'),
(39,'cb9801d1-5f09-49de-b295-79503a645451','2026-09-14 10:27:58',NULL,1,'admin',7,NULL,NULL,'Соколов Сергей Сергеевна','7','manual','open','telegram','success',NULL,NULL,'192.168.1.25',NULL,NULL,268,NULL,'{\"demo\":true}'),
(40,'bee66568-dafb-447f-964f-ca982d253d9d','2026-09-14 14:04:27',NULL,1,'resident',8,NULL,NULL,'Михайлова Елена Николаевич','8','own','open','admin','success',NULL,NULL,'192.168.1.239',NULL,NULL,563,NULL,'{\"demo\":true}'),
(41,'aa9c3be2-516e-4008-97b8-0a197e999124','2026-09-14 23:32:57',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','telegram','success',NULL,NULL,'192.168.1.82',NULL,NULL,690,NULL,'{\"demo\":true}'),
(42,'13ef7b97-f6fe-4942-9dde-a8f2f7b85342','2026-09-14 09:37:52',NULL,1,'admin',14,NULL,NULL,'Семёнова Татьяна Петровна','14','manual','open','telegram','success',NULL,NULL,'192.168.1.73',NULL,NULL,273,NULL,'{\"demo\":true}'),
(43,'c2d79eaf-bf8e-4d78-a837-f2fba508e3da','2026-09-15 18:58:33',NULL,1,'resident',6,NULL,NULL,'Васильева Анна Петровна','6','own','open','web','success',NULL,NULL,'192.168.1.115',NULL,NULL,350,NULL,'{\"demo\":true}'),
(44,'7d5f1560-664d-4b35-8139-f9723026f335','2026-09-15 08:01:03',NULL,1,'admin',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','manual','open','api','success',NULL,NULL,'192.168.1.172',NULL,NULL,794,NULL,'{\"demo\":true}'),
(45,'446d4ab8-528f-424f-8fd8-e22a940393f0','2026-09-15 12:06:49',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','plate','open','web','success',NULL,NULL,'192.168.1.186',NULL,NULL,886,NULL,'{\"demo\":true}'),
(46,'bc58115c-53b2-4454-b36c-5121e8089b04','2026-09-15 19:11:16',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','own','open','web','success',NULL,NULL,'192.168.1.116',NULL,NULL,896,NULL,'{\"demo\":true}'),
(47,'099ae2cb-2ae5-4f6e-a636-7a7ca05c2c6b','2026-09-15 18:59:32',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','plate','denied','web','denied','Превышен лимит открытий',NULL,'192.168.1.70',NULL,NULL,830,NULL,'{\"demo\":true}'),
(48,'3c6cdaa5-7844-4f5a-91d9-042fe622d10d','2026-09-15 22:07:40',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','own','open','web','success',NULL,NULL,'192.168.1.70',NULL,NULL,861,NULL,'{\"demo\":true}'),
(49,'535f9435-80db-4311-8c25-fe5367d4c99b','2026-09-15 14:54:07',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','own','open','api','success',NULL,NULL,'192.168.1.72',NULL,NULL,403,NULL,'{\"demo\":true}'),
(50,'9b895211-91f1-4386-8180-a4d18eeab687','2026-09-15 18:49:54',NULL,1,'resident',22,NULL,NULL,'Макарова Анна Петровна','22','own','open','api','success',NULL,NULL,'192.168.1.135',NULL,NULL,713,NULL,'{\"demo\":true}'),
(51,'8f98d374-dbaa-41b6-bf84-fab713afff1c','2026-09-15 23:44:24',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','own','open','web','success',NULL,NULL,'192.168.1.222',NULL,NULL,690,NULL,'{\"demo\":true}'),
(52,'2bb8125c-adaa-47ba-bab9-3b52f204f110','2026-09-15 09:11:48',NULL,1,'guest',1,NULL,NULL,'Иванов Иван Иванович','1','guest','open','cabinet','success',NULL,NULL,'192.168.1.63',NULL,NULL,758,NULL,'{\"demo\":true}'),
(53,'b323705c-90ab-450a-9163-35c44518d8fc','2026-09-15 14:01:26',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','own','open','web','success',NULL,NULL,'192.168.1.119',NULL,NULL,280,NULL,'{\"demo\":true}'),
(54,'57308399-4732-40e8-aef5-38519773d612','2026-09-15 18:28:19',NULL,1,'guest',16,NULL,NULL,'Павлова Юлия Николаевич','16','guest','denied','cabinet','denied','Тихие часы',NULL,'192.168.1.139',NULL,NULL,867,NULL,'{\"demo\":true}'),
(55,'5f3a1700-52bb-4faa-affa-f8032f8085da','2026-09-15 19:11:32',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','own','open','admin','success',NULL,NULL,'192.168.1.231',NULL,NULL,476,NULL,'{\"demo\":true}'),
(56,'4a36eef9-ee9b-4bde-8927-e47710b7518b','2026-09-15 06:37:49',NULL,1,'admin',2,NULL,NULL,'Петрова Мария Петрович','2','manual','open','telegram','success',NULL,NULL,'192.168.1.162',NULL,NULL,547,NULL,'{\"demo\":true}'),
(57,'0d34f61d-f225-4b19-91b3-f889a89272cb','2026-09-15 09:40:23',NULL,1,'admin',22,NULL,NULL,'Макарова Анна Петровна','22','manual','open','admin','success',NULL,NULL,'192.168.1.44',NULL,NULL,246,NULL,'{\"demo\":true}'),
(58,'843118b3-17c9-4b4b-a859-89a676a8ef95','2026-09-16 17:42:50',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','plate','open','admin','success',NULL,NULL,'192.168.1.197',NULL,NULL,596,NULL,'{\"demo\":true}'),
(59,'a5912322-6ae0-4665-aee2-11cc012b43b8','2026-09-16 12:18:33',NULL,1,'resident',22,NULL,NULL,'Макарова Анна Петровна','22','own','open','admin','success',NULL,NULL,'192.168.1.232',NULL,NULL,513,NULL,'{\"demo\":true}'),
(60,'54581275-87b2-4400-966a-960125306ef1','2026-09-16 07:55:07',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','admin','success',NULL,NULL,'192.168.1.183',NULL,NULL,484,NULL,'{\"demo\":true}'),
(61,'7161ec5d-4916-4da7-b041-63585cd58316','2026-09-16 17:09:02',NULL,1,'guest',14,NULL,NULL,'Семёнова Татьяна Петровна','14','guest','open','admin','success',NULL,NULL,'192.168.1.36',NULL,NULL,191,NULL,'{\"demo\":true}'),
(62,'6a52dead-3edf-4970-953b-71cff30835d1','2026-09-16 16:41:03',NULL,1,'guest',10,NULL,NULL,'Морозова Наталья Петрович','10','guest','denied','api','denied','Превышен лимит открытий',NULL,'192.168.1.64',NULL,NULL,718,NULL,'{\"demo\":true}'),
(63,'b62e973d-d64f-472a-954f-340a349553d3','2026-09-16 23:51:57',NULL,1,'guest',11,NULL,NULL,'Волков Павел Сергеевич','11','guest','open','web','success',NULL,NULL,'192.168.1.105',NULL,NULL,133,NULL,'{\"demo\":true}'),
(64,'38144b99-3f8f-4fdd-94d5-ee20e76a9012','2026-09-16 23:09:33',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','own','open','admin','success',NULL,NULL,'192.168.1.194',NULL,NULL,870,NULL,'{\"demo\":true}'),
(65,'cb961c5c-7805-45dc-bfe6-23b6990a9ad2','2026-09-16 07:29:55',NULL,1,'resident',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','own','open','web','success',NULL,NULL,'192.168.1.152',NULL,NULL,756,NULL,'{\"demo\":true}'),
(66,'9107ec80-5874-4d61-883d-81b149f3d8cf','2026-09-16 16:54:53',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','own','open','telegram','success',NULL,NULL,'192.168.1.196',NULL,NULL,876,NULL,'{\"demo\":true}'),
(67,'b1ec9527-5dec-4037-a40a-ed4cc0f0f586','2026-09-16 19:01:23',NULL,1,'resident',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','plate','open','api','success',NULL,NULL,'192.168.1.43',NULL,NULL,754,NULL,'{\"demo\":true}'),
(68,'b10e3a11-7e22-40c1-b574-fcbe5ce93d24','2026-09-17 12:53:44',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','own','open','cabinet','success',NULL,NULL,'192.168.1.73',NULL,NULL,345,NULL,'{\"demo\":true}'),
(69,'e8116907-7a1e-4923-a9b2-2234950baee7','2026-09-17 12:01:48',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','api','success',NULL,NULL,'192.168.1.104',NULL,NULL,268,NULL,'{\"demo\":true}'),
(70,'c33e9e00-1287-4d6b-9260-5b8500b9ce32','2026-09-17 10:13:58',NULL,1,'resident',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','plate','open','cabinet','success',NULL,NULL,'192.168.1.122',NULL,NULL,569,NULL,'{\"demo\":true}'),
(71,'9ea37553-8a64-4285-bce9-afb5cd893108','2026-09-17 07:42:36',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','web','success',NULL,NULL,'192.168.1.211',NULL,NULL,380,NULL,'{\"demo\":true}'),
(72,'df793dda-5a2b-4c32-9715-a70f01189e35','2026-09-17 16:21:26',NULL,1,'admin',24,NULL,NULL,'Зайцева Елена Николаевич','24','manual','open','api','success',NULL,NULL,'192.168.1.51',NULL,NULL,371,NULL,'{\"demo\":true}'),
(73,'17ec3c1d-a11f-4ca7-a0f0-f8b523c3d03d','2026-09-17 16:50:32',NULL,1,'admin',13,NULL,NULL,'Лебедев Николай Ивановна','13','manual','open','telegram','success',NULL,NULL,'192.168.1.87',NULL,NULL,799,NULL,'{\"demo\":true}'),
(74,'09c92dcd-4b9a-411c-b652-9552ea8b421c','2026-09-17 12:08:35',NULL,1,'guest',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','guest','open','cabinet','success',NULL,NULL,'192.168.1.245',NULL,NULL,702,NULL,'{\"demo\":true}'),
(75,'1a40c153-daae-4ad2-be50-8b34692ea0c1','2026-09-17 21:15:27',NULL,1,'resident',16,NULL,NULL,'Павлова Юлия Николаевич','16','own','open','cabinet','success',NULL,NULL,'192.168.1.47',NULL,NULL,420,NULL,'{\"demo\":true}'),
(76,'36e17358-1e92-43bf-9d2e-ff79c7d42512','2026-09-17 20:01:28',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','plate','open','telegram','success',NULL,NULL,'192.168.1.166',NULL,NULL,143,NULL,'{\"demo\":true}'),
(77,'9d2eff74-6779-4ad8-a760-461c96932a42','2026-09-17 06:14:14',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','plate','open','web','success',NULL,NULL,'192.168.1.96',NULL,NULL,170,NULL,'{\"demo\":true}'),
(78,'5136de0c-3895-46a1-8073-715afbf234f3','2026-09-17 18:51:39',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','own','open','api','success',NULL,NULL,'192.168.1.36',NULL,NULL,613,NULL,'{\"demo\":true}'),
(79,'83d58a58-dd64-4a70-b50c-25f6919e510f','2026-09-17 07:27:19',NULL,1,'admin',13,NULL,NULL,'Лебедев Николай Ивановна','13','manual','open','cabinet','success',NULL,NULL,'192.168.1.138',NULL,NULL,671,NULL,'{\"demo\":true}'),
(80,'504c65e7-0f91-4891-b8de-f8d9cbeb2956','2026-09-17 06:55:00',NULL,1,'guest',18,NULL,NULL,'Степанова Мария Петрович','18','guest','open','api','success',NULL,NULL,'192.168.1.209',NULL,NULL,304,NULL,'{\"demo\":true}'),
(81,'311ad4a6-b4b8-4a16-b579-e795f1a7d6cb','2026-09-17 18:58:29',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','telegram','success',NULL,NULL,'192.168.1.146',NULL,NULL,340,NULL,'{\"demo\":true}'),
(82,'42f60a7e-612c-41d0-b332-c7c8a8a66456','2026-09-17 09:38:03',NULL,1,'guest',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','guest','open','web','success',NULL,NULL,'192.168.1.236',NULL,NULL,548,NULL,'{\"demo\":true}'),
(83,'1c204c81-ebfc-4d8a-b76e-777b5863741e','2026-09-18 18:49:19',NULL,1,'resident',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','own','open','web','success',NULL,NULL,'192.168.1.84',NULL,NULL,386,NULL,'{\"demo\":true}'),
(84,'1140c867-b6a2-4fb2-a02a-ab7f010a5392','2026-09-18 18:23:54',NULL,1,'guest',13,NULL,NULL,'Лебедев Николай Ивановна','13','guest','open','cabinet','success',NULL,NULL,'192.168.1.142',NULL,NULL,135,NULL,'{\"demo\":true}'),
(85,'c2a42388-87f7-4e79-bb03-554db47b2f2a','2026-09-18 21:19:04',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','own','open','admin','success',NULL,NULL,'192.168.1.164',NULL,NULL,532,NULL,'{\"demo\":true}'),
(86,'61507800-6947-4b97-8684-d9e6f34a7479','2026-09-18 14:35:19',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','own','open','web','success',NULL,NULL,'192.168.1.217',NULL,NULL,256,NULL,'{\"demo\":true}'),
(87,'e3750644-8f77-44ba-9203-2e04d7fde55c','2026-09-18 23:26:48',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','plate','open','web','success',NULL,NULL,'192.168.1.155',NULL,NULL,360,NULL,'{\"demo\":true}'),
(88,'47d3fa53-4729-44c2-b50f-7734c083fd22','2026-09-18 23:54:23',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','denied','admin','denied','Тихие часы',NULL,'192.168.1.237',NULL,NULL,512,NULL,'{\"demo\":true}'),
(89,'0127010d-0e27-41b1-b2ae-3d480e457e24','2026-09-18 06:38:06',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','own','open','telegram','success',NULL,NULL,'192.168.1.193',NULL,NULL,333,NULL,'{\"demo\":true}'),
(90,'e97ea383-d2eb-47fa-9d4f-aa9a54b4b817','2026-09-18 09:38:39',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','own','open','cabinet','success',NULL,NULL,'192.168.1.241',NULL,NULL,830,NULL,'{\"demo\":true}'),
(91,'14ddf567-a795-403c-a67c-f15ff7e1b4b8','2026-09-18 13:36:21',NULL,1,'resident',15,NULL,NULL,'Егоров Виктор Сергеевна','15','own','open','cabinet','success',NULL,NULL,'192.168.1.172',NULL,NULL,278,NULL,'{\"demo\":true}'),
(92,'65ad2180-75f8-4b81-bffa-c419f1bcc146','2026-09-18 23:28:21',NULL,1,'guest',9,NULL,NULL,'Фёдоров Андрей Иванович','9','guest','open','web','success',NULL,NULL,'192.168.1.24',NULL,NULL,745,NULL,'{\"demo\":true}'),
(93,'cb7e9d21-ac66-4016-9da8-c413ed63b76f','2026-09-18 23:26:53',NULL,1,'guest',9,NULL,NULL,'Фёдоров Андрей Иванович','9','guest','open','web','success',NULL,NULL,'192.168.1.203',NULL,NULL,706,NULL,'{\"demo\":true}'),
(94,'1b45a397-6757-435a-8b53-83242bb092fb','2026-09-18 21:28:30',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','plate','open','admin','success',NULL,NULL,'192.168.1.213',NULL,NULL,209,NULL,'{\"demo\":true}'),
(95,'1b6bfa06-880d-4480-adc1-1aadbacbf38c','2026-09-18 08:33:31',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','own','open','web','success',NULL,NULL,'192.168.1.107',NULL,NULL,317,NULL,'{\"demo\":true}'),
(96,'253f8373-d8ce-412c-bcc0-b956254a056d','2026-09-18 18:35:54',NULL,1,'resident',20,NULL,NULL,'Орлова Ольга Андреевич','20','own','open','admin','success',NULL,NULL,'192.168.1.126',NULL,NULL,253,NULL,'{\"demo\":true}'),
(97,'ad441ce7-d3c9-4789-9f35-b46a3e18ecee','2026-09-18 13:50:26',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','own','open','web','success',NULL,NULL,'192.168.1.40',NULL,NULL,174,NULL,'{\"demo\":true}'),
(98,'58b2cc37-687c-4942-8451-7b261cb34992','2026-09-18 07:23:03',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','own','open','api','success',NULL,NULL,'192.168.1.61',NULL,NULL,491,NULL,'{\"demo\":true}'),
(99,'1a62636a-7344-43ad-bed1-30a55e9d98d2','2026-09-18 12:39:53',NULL,1,'guest',7,NULL,NULL,'Соколов Сергей Сергеевна','7','guest','denied','telegram','denied','Доступ приостановлен',NULL,'192.168.1.241',NULL,NULL,178,NULL,'{\"demo\":true}'),
(100,'ab2c8c96-a668-46b6-8876-b9e2c2bf7f44','2026-09-18 08:19:41',NULL,1,'resident',20,NULL,NULL,'Орлова Ольга Андреевич','20','own','open','telegram','success',NULL,NULL,'192.168.1.218',NULL,NULL,611,NULL,'{\"demo\":true}'),
(101,'9e3af9a6-aea2-46bb-ae50-9082f549dd22','2026-09-18 19:11:02',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','own','denied','admin','denied','Превышен лимит открытий',NULL,'192.168.1.134',NULL,NULL,349,NULL,'{\"demo\":true}'),
(102,'a72d54a6-edcc-41a0-97a0-0d70ade305f8','2026-09-19 09:00:53',NULL,1,'resident',14,NULL,NULL,'Семёнова Татьяна Петровна','14','own','open','api','success',NULL,NULL,'192.168.1.94',NULL,NULL,815,NULL,'{\"demo\":true}'),
(103,'e2faf0f0-7801-4c4f-83d3-835bd703c56b','2026-09-19 14:29:35',NULL,1,'resident',8,NULL,NULL,'Михайлова Елена Николаевич','8','own','open','web','success',NULL,NULL,'192.168.1.48',NULL,NULL,572,NULL,'{\"demo\":true}'),
(104,'06ef1cbc-8c4a-4fc7-94f9-db72c337bea0','2026-09-19 22:15:39',NULL,1,'resident',8,NULL,NULL,'Михайлова Елена Николаевич','8','own','open','web','success',NULL,NULL,'192.168.1.171',NULL,NULL,827,NULL,'{\"demo\":true}'),
(105,'94a21c72-135b-4d76-9c59-6e5089e90771','2026-09-19 14:08:44',NULL,1,'resident',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','own','open','telegram','success',NULL,NULL,'192.168.1.109',NULL,NULL,375,NULL,'{\"demo\":true}'),
(106,'ae360573-e79a-4129-9523-962a4d405bcd','2026-09-19 11:08:36',NULL,1,'guest',8,NULL,NULL,'Михайлова Елена Николаевич','8','guest','open','telegram','success',NULL,NULL,'192.168.1.122',NULL,NULL,695,NULL,'{\"demo\":true}'),
(107,'b111d8f3-e963-4115-ad60-b366216a2419','2026-09-19 14:26:40',NULL,1,'resident',15,NULL,NULL,'Егоров Виктор Сергеевна','15','own','open','web','success',NULL,NULL,'192.168.1.47',NULL,NULL,599,NULL,'{\"demo\":true}'),
(108,'c4581bea-71b2-457c-b384-3e0a00538c0d','2026-09-19 15:14:49',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','telegram','success',NULL,NULL,'192.168.1.228',NULL,NULL,547,NULL,'{\"demo\":true}'),
(109,'4b3eb248-4311-4607-abd7-916f9cb07277','2026-09-19 12:10:34',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','cabinet','success',NULL,NULL,'192.168.1.32',NULL,NULL,683,NULL,'{\"demo\":true}'),
(110,'fb5d98d4-d612-4c40-bb9e-09f3ba3ebd91','2026-09-19 11:00:37',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','own','open','cabinet','success',NULL,NULL,'192.168.1.140',NULL,NULL,652,NULL,'{\"demo\":true}'),
(111,'0a826ed8-9c05-45e6-9b35-155ecde579e0','2026-09-19 11:03:22',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','own','open','api','success',NULL,NULL,'192.168.1.184',NULL,NULL,894,NULL,'{\"demo\":true}'),
(112,'ae96eb3d-4664-4095-a3d2-0215299e0daa','2026-09-19 08:16:26',NULL,1,'resident',6,NULL,NULL,'Васильева Анна Петровна','6','own','open','api','success',NULL,NULL,'192.168.1.246',NULL,NULL,622,NULL,'{\"demo\":true}'),
(113,'20a3d470-a912-4132-9829-eab324645164','2026-09-19 11:31:26',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','open','api','success',NULL,NULL,'192.168.1.100',NULL,NULL,382,NULL,'{\"demo\":true}'),
(114,'8255ac90-8d8a-4c78-a83e-c8433bd143e7','2026-09-19 16:25:09',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','own','open','web','success',NULL,NULL,'192.168.1.140',NULL,NULL,485,NULL,'{\"demo\":true}'),
(115,'5ce2a45c-bab1-45f9-bba8-af981909fa35','2026-09-19 08:35:19',NULL,1,'admin',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','manual','open','admin','success',NULL,NULL,'192.168.1.32',NULL,NULL,522,NULL,'{\"demo\":true}'),
(116,'7c57361d-b6ab-4aed-a440-dffe38ba3449','2026-09-20 07:46:47',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','own','open','telegram','success',NULL,NULL,'192.168.1.44',NULL,NULL,433,NULL,'{\"demo\":true}'),
(117,'2f0f23f2-6e84-4983-b89e-325eaf498a1e','2026-09-20 21:28:36',NULL,1,'resident',20,NULL,NULL,'Орлова Ольга Андреевич','20','own','open','web','success',NULL,NULL,'192.168.1.146',NULL,NULL,155,NULL,'{\"demo\":true}'),
(118,'07008db1-aa41-4f1f-8201-78d1494cc524','2026-09-20 17:57:42',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','open','cabinet','success',NULL,NULL,'192.168.1.122',NULL,NULL,894,NULL,'{\"demo\":true}'),
(119,'4ac6540b-4a35-402f-aa60-5370d7d36160','2026-09-20 22:53:56',NULL,1,'admin',22,NULL,NULL,'Макарова Анна Петровна','22','manual','open','telegram','success',NULL,NULL,'192.168.1.219',NULL,NULL,214,NULL,'{\"demo\":true}'),
(120,'bc667ae1-e86e-4ad7-af99-c0120845d0e6','2026-09-20 07:58:26',NULL,1,'resident',20,NULL,NULL,'Орлова Ольга Андреевич','20','own','open','web','success',NULL,NULL,'192.168.1.97',NULL,NULL,771,NULL,'{\"demo\":true}'),
(121,'12c141d8-4b5b-4586-be1c-e72fe285bf0a','2026-09-20 06:23:38',NULL,1,'resident',16,NULL,NULL,'Павлова Юлия Николаевич','16','own','open','web','success',NULL,NULL,'192.168.1.89',NULL,NULL,145,NULL,'{\"demo\":true}'),
(122,'d6e833ba-53c0-424e-a0f4-2a616906f1df','2026-09-20 22:10:48',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','own','open','api','success',NULL,NULL,'192.168.1.50',NULL,NULL,836,NULL,'{\"demo\":true}'),
(123,'ad4eb9ec-20bd-4a1e-b7d2-2ef551e9eafd','2026-09-20 17:47:41',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','plate','open','admin','success',NULL,NULL,'192.168.1.183',NULL,NULL,178,NULL,'{\"demo\":true}'),
(124,'13ada08d-0fd4-460c-a5ae-42a92aee46b8','2026-09-20 20:25:09',NULL,1,'guest',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','guest','open','admin','success',NULL,NULL,'192.168.1.226',NULL,NULL,802,NULL,'{\"demo\":true}'),
(125,'ab6412de-af2f-4822-b74d-9bae1f0ded8b','2026-09-20 15:25:08',NULL,1,'admin',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','manual','open','cabinet','success',NULL,NULL,'192.168.1.40',NULL,NULL,610,NULL,'{\"demo\":true}'),
(126,'7b6ceef4-1170-4faf-9d37-260a33607715','2026-09-20 11:03:59',NULL,1,'resident',15,NULL,NULL,'Егоров Виктор Сергеевна','15','own','open','cabinet','success',NULL,NULL,'192.168.1.61',NULL,NULL,865,NULL,'{\"demo\":true}'),
(127,'e000f10f-1029-4d6e-84e9-a68b56bc7ff8','2026-09-20 13:09:06',NULL,1,'resident',11,NULL,NULL,'Волков Павел Сергеевич','11','own','open','admin','success',NULL,NULL,'192.168.1.248',NULL,NULL,626,NULL,'{\"demo\":true}'),
(128,'06d963b8-bfff-4ae3-9ca0-da872f9f3935','2026-09-20 23:37:05',NULL,1,'resident',1,NULL,NULL,'Иванов Иван Иванович','1','own','denied','api','denied','Превышен лимит открытий',NULL,'192.168.1.214',NULL,NULL,185,NULL,'{\"demo\":true}'),
(129,'0e109904-5cbf-48d9-94fb-c7817a409a85','2026-09-20 20:01:17',NULL,1,'guest',10,NULL,NULL,'Морозова Наталья Петрович','10','guest','open','web','success',NULL,NULL,'192.168.1.83',NULL,NULL,471,NULL,'{\"demo\":true}'),
(130,'45fcf877-274d-4aa2-aab6-e18cca6071ca','2026-09-20 23:50:54',NULL,1,'guest',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','guest','denied','cabinet','denied','Превышен лимит открытий',NULL,'192.168.1.156',NULL,NULL,512,NULL,'{\"demo\":true}'),
(131,'3b3cf0d8-ff33-452d-bcb8-4ed1a51d1015','2026-09-20 18:00:07',NULL,1,'admin',8,NULL,NULL,'Михайлова Елена Николаевич','8','manual','open','telegram','success',NULL,NULL,'192.168.1.238',NULL,NULL,333,NULL,'{\"demo\":true}'),
(132,'11341145-918e-4954-9e0e-cb7657446baf','2026-09-20 16:27:19',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','own','open','telegram','success',NULL,NULL,'192.168.1.241',NULL,NULL,126,NULL,'{\"demo\":true}'),
(133,'779902b4-b4b4-47c2-a24f-6f40135d97f9','2026-09-20 11:57:12',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','own','open','telegram','success',NULL,NULL,'192.168.1.217',NULL,NULL,679,NULL,'{\"demo\":true}'),
(134,'7dbc2d24-1cc8-4e11-b06f-821aa4f1b0bc','2026-09-20 20:42:59',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','own','open','cabinet','success',NULL,NULL,'192.168.1.155',NULL,NULL,627,NULL,'{\"demo\":true}'),
(135,'c95995d6-a9fa-4716-8b2b-e044d6220149','2026-09-21 20:32:42',NULL,1,'guest',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','guest','open','web','success',NULL,NULL,'192.168.1.187',NULL,NULL,572,NULL,'{\"demo\":true}'),
(136,'abd634b0-31e0-4e5b-a511-6fac5c3f8cf3','2026-09-21 15:38:47',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','telegram','success',NULL,NULL,'192.168.1.150',NULL,NULL,765,NULL,'{\"demo\":true}'),
(137,'1bba93ee-db43-4bb1-862f-580554da064e','2026-09-21 14:24:10',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','plate','open','telegram','success',NULL,NULL,'192.168.1.116',NULL,NULL,157,NULL,'{\"demo\":true}'),
(138,'af4b63ae-6ad1-422e-9c88-440b97e08163','2026-09-21 20:56:11',NULL,1,'admin',13,NULL,NULL,'Лебедев Николай Ивановна','13','manual','open','cabinet','success',NULL,NULL,'192.168.1.250',NULL,NULL,662,NULL,'{\"demo\":true}'),
(139,'c38548e9-c5ff-47df-9098-c03dccc6af11','2026-09-21 16:00:05',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','own','open','api','success',NULL,NULL,'192.168.1.73',NULL,NULL,457,NULL,'{\"demo\":true}'),
(140,'26e8d13c-6eea-447e-9389-b7cd9bd270e6','2026-09-21 13:47:02',NULL,1,'guest',15,NULL,NULL,'Егоров Виктор Сергеевна','15','guest','denied','web','denied','Тихие часы',NULL,'192.168.1.133',NULL,NULL,887,NULL,'{\"demo\":true}'),
(141,'b1884e15-f277-47f3-83b0-cb9d8f5c23ad','2026-09-21 23:03:10',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','own','open','admin','success',NULL,NULL,'192.168.1.222',NULL,NULL,559,NULL,'{\"demo\":true}'),
(142,'22258e5b-178c-45a5-8f50-0d5ea4e11610','2026-09-21 08:18:06',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','plate','open','web','success',NULL,NULL,'192.168.1.25',NULL,NULL,498,NULL,'{\"demo\":true}'),
(143,'e42ef71b-fcec-4f04-856f-cfaf74232c0a','2026-09-21 06:53:59',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','open','web','success',NULL,NULL,'192.168.1.86',NULL,NULL,257,NULL,'{\"demo\":true}'),
(144,'90f6a546-29dc-4347-813e-cf1ad206187a','2026-09-21 20:37:29',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','plate','open','cabinet','success',NULL,NULL,'192.168.1.24',NULL,NULL,850,NULL,'{\"demo\":true}'),
(145,'821ae9ce-13e4-4788-bdd7-760602cdb55a','2026-09-21 19:34:45',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','own','open','telegram','success',NULL,NULL,'192.168.1.196',NULL,NULL,669,NULL,'{\"demo\":true}'),
(146,'f5986f09-3edb-44a0-a65c-ff866278234e','2026-09-21 15:30:30',NULL,1,'admin',6,NULL,NULL,'Васильева Анна Петровна','6','manual','open','cabinet','success',NULL,NULL,'192.168.1.127',NULL,NULL,696,NULL,'{\"demo\":true}'),
(147,'1067dd60-9045-4bf1-a10c-f62e95437c3e','2026-09-21 12:40:49',NULL,1,'guest',6,NULL,NULL,'Васильева Анна Петровна','6','guest','open','api','success',NULL,NULL,'192.168.1.43',NULL,NULL,127,NULL,'{\"demo\":true}'),
(148,'ac595712-c2eb-4cc6-8bc0-57b8260c72a5','2026-09-21 12:56:12',NULL,1,'admin',1,NULL,NULL,'Иванов Иван Иванович','1','manual','open','telegram','success',NULL,NULL,'192.168.1.246',NULL,NULL,850,NULL,'{\"demo\":true}'),
(149,'09703991-0be3-4824-8b52-b10bcffed91b','2026-09-21 17:49:40',NULL,1,'resident',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','own','open','cabinet','success',NULL,NULL,'192.168.1.60',NULL,NULL,900,NULL,'{\"demo\":true}'),
(150,'360576a9-e67f-469c-8cfd-74618fef7f5f','2026-09-21 11:51:29',NULL,1,'admin',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','manual','open','telegram','success',NULL,NULL,'192.168.1.142',NULL,NULL,341,NULL,'{\"demo\":true}'),
(151,'12a03859-1c6e-4862-af4a-c77f8df92f6a','2026-09-21 12:41:25',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','plate','open','web','success',NULL,NULL,'192.168.1.196',NULL,NULL,311,NULL,'{\"demo\":true}'),
(152,'1f1d71f9-3bf5-4076-bde8-54bee9240851','2026-09-21 09:00:14',NULL,1,'guest',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','guest','open','api','success',NULL,NULL,'192.168.1.183',NULL,NULL,371,NULL,'{\"demo\":true}'),
(153,'98104351-7bd4-4cbc-93e4-f0c5090f3d24','2026-09-21 18:35:40',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','own','open','web','success',NULL,NULL,'192.168.1.164',NULL,NULL,311,NULL,'{\"demo\":true}'),
(154,'3510a75d-7f5c-46e9-a07c-38bdf6275044','2026-09-21 13:29:45',NULL,1,'admin',15,NULL,NULL,'Егоров Виктор Сергеевна','15','manual','open','telegram','success',NULL,NULL,'192.168.1.207',NULL,NULL,528,NULL,'{\"demo\":true}'),
(155,'4fac69f8-3452-435f-a5ad-08a9a2f5b9ec','2026-09-22 15:48:20',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','own','open','admin','success',NULL,NULL,'192.168.1.81',NULL,NULL,355,NULL,'{\"demo\":true}'),
(156,'7ff1f7d4-5ed9-43ba-8aed-bc997e6ec859','2026-09-22 15:55:55',NULL,1,'admin',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','manual','open','cabinet','success',NULL,NULL,'192.168.1.95',NULL,NULL,233,NULL,'{\"demo\":true}'),
(157,'f004d2ff-8977-4429-9016-57206e15a9f3','2026-09-22 12:22:30',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','plate','open','web','success',NULL,NULL,'192.168.1.236',NULL,NULL,616,NULL,'{\"demo\":true}'),
(158,'eebaadf7-ac6f-40fd-99c2-c5a06b70a9d3','2026-09-22 21:11:23',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','plate','open','cabinet','success',NULL,NULL,'192.168.1.193',NULL,NULL,523,NULL,'{\"demo\":true}'),
(159,'ce247c77-3bdf-4d51-aadf-f4cd79e653a8','2026-09-22 16:11:07',NULL,1,'resident',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','plate','open','admin','success',NULL,NULL,'192.168.1.233',NULL,NULL,571,NULL,'{\"demo\":true}'),
(160,'10f71ffb-1740-47a8-b5ca-ca9bdc33d026','2026-09-22 07:41:02',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','own','open','api','success',NULL,NULL,'192.168.1.130',NULL,NULL,636,NULL,'{\"demo\":true}'),
(161,'780d5661-e8b6-4b06-9184-45cc506aa2d1','2026-09-22 16:01:09',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','own','open','cabinet','success',NULL,NULL,'192.168.1.175',NULL,NULL,462,NULL,'{\"demo\":true}'),
(162,'a27f9bbf-3e55-4a6a-bf36-e682e7740873','2026-09-22 08:00:01',NULL,1,'resident',20,NULL,NULL,'Орлова Ольга Андреевич','20','own','open','admin','success',NULL,NULL,'192.168.1.170',NULL,NULL,179,NULL,'{\"demo\":true}'),
(163,'435afb84-8335-4cdf-9968-d01c4c79d77a','2026-09-22 09:06:13',NULL,1,'guest',1,NULL,NULL,'Иванов Иван Иванович','1','guest','open','api','success',NULL,NULL,'192.168.1.105',NULL,NULL,646,NULL,'{\"demo\":true}'),
(164,'80608370-a7a7-4a07-992b-7509c51350af','2026-09-22 07:43:38',NULL,1,'resident',22,NULL,NULL,'Макарова Анна Петровна','22','plate','open','api','success',NULL,NULL,'192.168.1.167',NULL,NULL,431,NULL,'{\"demo\":true}'),
(165,'f54cda4f-f875-43cc-84a4-13c2caae2f2d','2026-09-22 22:21:25',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','plate','open','telegram','success',NULL,NULL,'192.168.1.59',NULL,NULL,287,NULL,'{\"demo\":true}'),
(166,'47e7a89c-58a3-418b-8828-48675b094306','2026-09-22 16:02:47',NULL,1,'resident',1,NULL,NULL,'Иванов Иван Иванович','1','own','open','cabinet','success',NULL,NULL,'192.168.1.118',NULL,NULL,750,NULL,'{\"demo\":true}'),
(167,'3ce4537c-b89d-4de3-bab0-b678143070e0','2026-09-22 23:50:31',NULL,1,'admin',8,NULL,NULL,'Михайлова Елена Николаевич','8','manual','open','telegram','success',NULL,NULL,'192.168.1.154',NULL,NULL,398,NULL,'{\"demo\":true}'),
(168,'61c7f9e7-3d29-43d5-9660-b5beac15f78e','2026-09-22 13:48:47',NULL,1,'resident',14,NULL,NULL,'Семёнова Татьяна Петровна','14','plate','open','telegram','success',NULL,NULL,'192.168.1.230',NULL,NULL,607,NULL,'{\"demo\":true}'),
(169,'735f4097-5dca-45c0-a2bd-c09a977b03ab','2026-09-22 10:10:45',NULL,1,'resident',22,NULL,NULL,'Макарова Анна Петровна','22','plate','open','cabinet','success',NULL,NULL,'192.168.1.141',NULL,NULL,809,NULL,'{\"demo\":true}'),
(170,'b8423084-5b65-48e6-95cd-a07d6974b37c','2026-09-22 17:39:33',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','own','open','admin','success',NULL,NULL,'192.168.1.222',NULL,NULL,595,NULL,'{\"demo\":true}'),
(171,'48a8e3d1-0ba2-4e75-9522-139779c8d583','2026-09-22 15:07:48',NULL,1,'resident',15,NULL,NULL,'Егоров Виктор Сергеевна','15','own','open','admin','success',NULL,NULL,'192.168.1.106',NULL,NULL,225,NULL,'{\"demo\":true}'),
(172,'fc4144d7-f4bc-4a5b-9d8d-599f807a1bfe','2026-09-22 16:08:42',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','own','open','web','success',NULL,NULL,'192.168.1.131',NULL,NULL,705,NULL,'{\"demo\":true}'),
(173,'4bd84a12-8917-4552-99b6-24046a8c6f64','2026-09-22 22:41:12',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','plate','open','admin','success',NULL,NULL,'192.168.1.206',NULL,NULL,557,NULL,'{\"demo\":true}'),
(174,'4c2baddb-2745-4a1a-a29b-54f30f38c5ad','2026-09-22 13:08:36',NULL,1,'guest',18,NULL,NULL,'Степанова Мария Петрович','18','guest','open','web','success',NULL,NULL,'192.168.1.150',NULL,NULL,787,NULL,'{\"demo\":true}'),
(175,'f27813a6-57eb-4e3d-b155-c743adbeb299','2026-09-22 11:35:01',NULL,1,'resident',16,NULL,NULL,'Павлова Юлия Николаевич','16','own','open','telegram','success',NULL,NULL,'192.168.1.62',NULL,NULL,269,NULL,'{\"demo\":true}'),
(176,'6d23c055-4d0e-45c9-b98c-6a3008000052','2026-09-23 09:23:26',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','own','open','web','success',NULL,NULL,'192.168.1.65',NULL,NULL,885,NULL,'{\"demo\":true}'),
(177,'68ba5f96-dc01-4720-b105-847e6467d0ca','2026-09-23 22:49:24',NULL,1,'guest',9,NULL,NULL,'Фёдоров Андрей Иванович','9','guest','open','api','success',NULL,NULL,'192.168.1.56',NULL,NULL,166,NULL,'{\"demo\":true}'),
(178,'68a32492-9a52-4a56-99df-2913e92b16a5','2026-09-23 06:37:18',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','own','open','telegram','success',NULL,NULL,'192.168.1.102',NULL,NULL,706,NULL,'{\"demo\":true}'),
(179,'1eb737a3-1a70-4ef0-a631-e3a9e4a266fe','2026-09-23 20:31:41',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','own','open','admin','success',NULL,NULL,'192.168.1.189',NULL,NULL,151,NULL,'{\"demo\":true}'),
(180,'bd7d7651-0c06-43de-9305-1e69fa563a43','2026-09-23 07:12:39',NULL,1,'guest',7,NULL,NULL,'Соколов Сергей Сергеевна','7','guest','open','api','success',NULL,NULL,'192.168.1.149',NULL,NULL,842,NULL,'{\"demo\":true}'),
(181,'84fc0092-a662-4a51-97c6-2265c7435790','2026-09-23 09:35:40',NULL,1,'resident',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','own','open','web','success',NULL,NULL,'192.168.1.48',NULL,NULL,373,NULL,'{\"demo\":true}'),
(182,'cbe15527-6bda-4a46-98d6-598e77ab1399','2026-09-23 13:51:50',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','own','open','telegram','success',NULL,NULL,'192.168.1.180',NULL,NULL,669,NULL,'{\"demo\":true}'),
(183,'9e9374dc-c8ea-4f5d-820e-9ce3fefd47e1','2026-09-23 16:58:54',NULL,1,'resident',16,NULL,NULL,'Павлова Юлия Николаевич','16','own','open','web','success',NULL,NULL,'192.168.1.60',NULL,NULL,657,NULL,'{\"demo\":true}'),
(184,'85117bec-6671-4dcf-97d3-af39b715a6b2','2026-09-24 17:09:53',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','plate','denied','cabinet','denied','Доступ приостановлен',NULL,'192.168.1.174',NULL,NULL,844,NULL,'{\"demo\":true}'),
(185,'525239ff-2705-4677-b683-f7f1b27c43df','2026-09-24 08:41:37',NULL,1,'guest',9,NULL,NULL,'Фёдоров Андрей Иванович','9','guest','open','web','success',NULL,NULL,'192.168.1.118',NULL,NULL,245,NULL,'{\"demo\":true}'),
(186,'59d2c93c-1e42-41af-a131-a8351b669382','2026-09-24 12:24:30',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','own','open','api','success',NULL,NULL,'192.168.1.62',NULL,NULL,737,NULL,'{\"demo\":true}'),
(187,'1fe70511-b246-42d4-8159-83c43a75d057','2026-09-24 23:29:49',NULL,1,'admin',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','manual','open','web','success',NULL,NULL,'192.168.1.82',NULL,NULL,334,NULL,'{\"demo\":true}'),
(188,'62bf5d76-6400-4fe2-9e6b-6093329b7d0a','2026-09-24 21:21:28',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','own','open','api','success',NULL,NULL,'192.168.1.117',NULL,NULL,808,NULL,'{\"demo\":true}'),
(189,'da4c42c3-d723-4331-8eeb-7c29f53da3cb','2026-09-24 14:31:20',NULL,1,'admin',17,NULL,NULL,'Козлов Иван Иванович','17','manual','open','web','success',NULL,NULL,'192.168.1.124',NULL,NULL,173,NULL,'{\"demo\":true}'),
(190,'f591dd3b-b030-4603-a967-5527eae624bc','2026-09-24 19:38:14',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','plate','open','api','success',NULL,NULL,'192.168.1.111',NULL,NULL,761,NULL,'{\"demo\":true}'),
(191,'a3896b2d-b157-4fe1-8cec-cd6488d5fc9d','2026-09-24 06:58:08',NULL,1,'resident',8,NULL,NULL,'Михайлова Елена Николаевич','8','own','open','cabinet','success',NULL,NULL,'192.168.1.76',NULL,NULL,371,NULL,'{\"demo\":true}'),
(192,'95235d33-e243-4c54-875c-bbb192d87ee5','2026-09-24 08:44:37',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','plate','open','api','success',NULL,NULL,'192.168.1.53',NULL,NULL,713,NULL,'{\"demo\":true}'),
(193,'0316a9d3-8059-4fb5-b1b1-326044c9de59','2026-09-24 13:24:04',NULL,1,'resident',15,NULL,NULL,'Егоров Виктор Сергеевна','15','plate','open','admin','success',NULL,NULL,'192.168.1.219',NULL,NULL,767,NULL,'{\"demo\":true}'),
(194,'93a9845e-8cdd-4347-92b5-f59d59c109d9','2026-09-25 22:54:51',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','plate','open','telegram','success',NULL,NULL,'192.168.1.136',NULL,NULL,702,NULL,'{\"demo\":true}'),
(195,'a2f8a2e6-2dcb-41b5-b01d-35cd8967c8d4','2026-09-25 17:31:23',NULL,1,'resident',22,NULL,NULL,'Макарова Анна Петровна','22','own','denied','telegram','denied','Превышен лимит открытий',NULL,'192.168.1.163',NULL,NULL,132,NULL,'{\"demo\":true}'),
(196,'069a4071-adf8-4187-ba32-687508b01f2f','2026-09-25 16:26:38',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','own','open','telegram','success',NULL,NULL,'192.168.1.226',NULL,NULL,368,NULL,'{\"demo\":true}'),
(197,'c9f296a7-eac6-414c-b501-d903b563d863','2026-09-25 11:18:37',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','plate','open','web','success',NULL,NULL,'192.168.1.109',NULL,NULL,774,NULL,'{\"demo\":true}'),
(198,'5c996b7d-153a-47d4-bd6a-3dd6e714bd0b','2026-09-25 09:17:15',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','own','open','admin','success',NULL,NULL,'192.168.1.153',NULL,NULL,306,NULL,'{\"demo\":true}'),
(199,'a47b243a-0b66-4029-8d1e-00fc01f90b73','2026-09-25 17:24:00',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','own','denied','telegram','denied','Превышен лимит открытий',NULL,'192.168.1.122',NULL,NULL,674,NULL,'{\"demo\":true}'),
(200,'0f60152e-c705-4d28-9739-1348c0affb8b','2026-09-25 09:22:27',NULL,1,'resident',6,NULL,NULL,'Васильева Анна Петровна','6','own','open','telegram','success',NULL,NULL,'192.168.1.103',NULL,NULL,651,NULL,'{\"demo\":true}'),
(201,'a7c9e0fb-ea6b-4a67-a626-e9f47ad22579','2026-09-25 14:45:21',NULL,1,'admin',1,NULL,NULL,'Иванов Иван Иванович','1','manual','open','admin','success',NULL,NULL,'192.168.1.234',NULL,NULL,588,NULL,'{\"demo\":true}'),
(202,'a7df6ff5-1c43-42e8-854c-ac2201377fdf','2026-09-25 22:40:20',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','api','success',NULL,NULL,'192.168.1.22',NULL,NULL,896,NULL,'{\"demo\":true}'),
(203,'9b40f2d8-a534-4f8b-ab1b-2a55d61e2482','2026-09-25 07:06:17',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','own','open','telegram','success',NULL,NULL,'192.168.1.230',NULL,NULL,204,NULL,'{\"demo\":true}'),
(204,'426a4085-e3b7-41e1-a84e-eb56beba6e08','2026-09-25 14:00:30',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','plate','open','telegram','success',NULL,NULL,'192.168.1.208',NULL,NULL,445,NULL,'{\"demo\":true}'),
(205,'3a41e757-3327-4508-9fdf-ef9057948c59','2026-09-25 12:19:21',NULL,1,'admin',15,NULL,NULL,'Егоров Виктор Сергеевна','15','manual','open','telegram','success',NULL,NULL,'192.168.1.219',NULL,NULL,455,NULL,'{\"demo\":true}'),
(206,'4eb13c13-bade-41df-946d-c390d154cfec','2026-09-25 08:38:43',NULL,1,'admin',22,NULL,NULL,'Макарова Анна Петровна','22','manual','open','web','success',NULL,NULL,'192.168.1.114',NULL,NULL,577,NULL,'{\"demo\":true}'),
(207,'c977f17b-d72c-45a5-8ef3-af3ef552c182','2026-09-25 06:49:02',NULL,1,'admin',20,NULL,NULL,'Орлова Ольга Андреевич','20','manual','open','admin','success',NULL,NULL,'192.168.1.35',NULL,NULL,337,NULL,'{\"demo\":true}'),
(208,'38ab9355-c2d4-4578-9f72-a745744b4fd1','2026-09-25 21:13:40',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','own','open','cabinet','success',NULL,NULL,'192.168.1.171',NULL,NULL,618,NULL,'{\"demo\":true}'),
(209,'05428387-c81f-40d5-bc21-b9be21bcbac8','2026-09-25 11:33:58',NULL,1,'resident',8,NULL,NULL,'Михайлова Елена Николаевич','8','plate','open','web','success',NULL,NULL,'192.168.1.31',NULL,NULL,453,NULL,'{\"demo\":true}'),
(210,'ac03cef5-a654-4508-8e3e-113ae8dacdbc','2026-09-26 18:06:27',NULL,1,'guest',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','guest','open','admin','success',NULL,NULL,'192.168.1.242',NULL,NULL,492,NULL,'{\"demo\":true}'),
(211,'9c8c30d8-1624-4766-b654-6e778627a0fd','2026-09-26 09:39:40',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','own','open','telegram','success',NULL,NULL,'192.168.1.121',NULL,NULL,869,NULL,'{\"demo\":true}'),
(212,'e226c88c-b5ea-4559-9597-3be08e176d78','2026-09-26 12:03:17',NULL,1,'guest',18,NULL,NULL,'Степанова Мария Петрович','18','guest','open','telegram','success',NULL,NULL,'192.168.1.243',NULL,NULL,220,NULL,'{\"demo\":true}'),
(213,'0343a676-c099-4a7b-acf9-112928f2a529','2026-09-26 07:12:20',NULL,1,'resident',16,NULL,NULL,'Павлова Юлия Николаевич','16','own','open','api','success',NULL,NULL,'192.168.1.179',NULL,NULL,570,NULL,'{\"demo\":true}'),
(214,'073792ce-b689-4bad-8bda-eced4c3e9203','2026-09-26 23:58:05',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','own','open','api','success',NULL,NULL,'192.168.1.207',NULL,NULL,676,NULL,'{\"demo\":true}'),
(215,'2bd30cf1-2d38-4a6f-84ee-d0114940b52d','2026-09-26 09:32:07',NULL,1,'admin',6,NULL,NULL,'Васильева Анна Петровна','6','manual','open','admin','success',NULL,NULL,'192.168.1.217',NULL,NULL,627,NULL,'{\"demo\":true}'),
(216,'17c5bc94-6a49-4228-b013-5e7190c8b353','2026-09-26 12:46:00',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','own','open','api','success',NULL,NULL,'192.168.1.30',NULL,NULL,777,NULL,'{\"demo\":true}'),
(217,'65680914-2126-4a03-b62c-435fd2e51c69','2026-09-26 17:07:09',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','plate','open','telegram','success',NULL,NULL,'192.168.1.231',NULL,NULL,562,NULL,'{\"demo\":true}'),
(218,'1731c518-eeef-4d1b-8781-c91b7b18c239','2026-09-26 17:26:51',NULL,1,'admin',16,NULL,NULL,'Павлова Юлия Николаевич','16','manual','open','cabinet','success',NULL,NULL,'192.168.1.26',NULL,NULL,784,NULL,'{\"demo\":true}'),
(219,'20dd878e-a2b2-4776-a3ee-6f15066f0f5d','2026-09-26 15:15:06',NULL,1,'resident',16,NULL,NULL,'Павлова Юлия Николаевич','16','own','open','api','success',NULL,NULL,'192.168.1.161',NULL,NULL,657,NULL,'{\"demo\":true}'),
(220,'e7555e4f-7ef2-482e-be4c-783d71fde23e','2026-09-26 12:38:56',NULL,1,'resident',11,NULL,NULL,'Волков Павел Сергеевич','11','own','open','telegram','success',NULL,NULL,'192.168.1.196',NULL,NULL,765,NULL,'{\"demo\":true}'),
(221,'85538365-30f4-4f28-b0ec-fc403e893726','2026-09-26 21:50:43',NULL,1,'resident',14,NULL,NULL,'Семёнова Татьяна Петровна','14','own','open','cabinet','success',NULL,NULL,'192.168.1.65',NULL,NULL,368,NULL,'{\"demo\":true}'),
(222,'e926c05d-538e-4fe6-b81c-7081f15b017c','2026-09-26 07:35:37',NULL,1,'resident',8,NULL,NULL,'Михайлова Елена Николаевич','8','own','denied','telegram','denied','Превышен лимит открытий',NULL,'192.168.1.79',NULL,NULL,158,NULL,'{\"demo\":true}'),
(223,'38d93580-33e0-4d7b-a6af-bf61357ff091','2026-09-26 16:47:31',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','own','denied','api','denied','Доступ приостановлен',NULL,'192.168.1.157',NULL,NULL,765,NULL,'{\"demo\":true}'),
(224,'f7738b02-2c2f-43c7-b70f-0742fdd9b10f','2026-09-26 14:23:24',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','own','open','api','success',NULL,NULL,'192.168.1.146',NULL,NULL,867,NULL,'{\"demo\":true}'),
(225,'813d5224-af22-404c-8287-5633b558f5ba','2026-09-26 15:41:18',NULL,1,'guest',18,NULL,NULL,'Степанова Мария Петрович','18','guest','open','cabinet','success',NULL,NULL,'192.168.1.142',NULL,NULL,770,NULL,'{\"demo\":true}'),
(226,'9e151f8a-a6d2-46a4-a8ad-586e85b3de8b','2026-09-26 10:22:18',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','own','open','admin','success',NULL,NULL,'192.168.1.38',NULL,NULL,835,NULL,'{\"demo\":true}'),
(227,'fb0651ad-db1d-4c63-a6b4-19b78765780c','2026-09-26 14:29:33',NULL,1,'guest',9,NULL,NULL,'Фёдоров Андрей Иванович','9','guest','open','admin','success',NULL,NULL,'192.168.1.141',NULL,NULL,248,NULL,'{\"demo\":true}'),
(228,'2c4b3f35-dae0-438c-8e87-bb7e6c3be083','2026-09-26 17:44:12',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','cabinet','success',NULL,NULL,'192.168.1.211',NULL,NULL,245,NULL,'{\"demo\":true}'),
(229,'b7cd4bc4-8419-4f48-887d-bcc405f819df','2026-09-26 20:28:17',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','plate','open','api','success',NULL,NULL,'192.168.1.93',NULL,NULL,291,NULL,'{\"demo\":true}'),
(230,'aae105d0-986e-4dd0-8809-9c28d274708e','2026-09-27 09:11:35',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','own','open','telegram','success',NULL,NULL,'192.168.1.192',NULL,NULL,740,NULL,'{\"demo\":true}'),
(231,'ffcdf425-e43a-4bb6-8d48-651595ea7623','2026-09-27 20:12:44',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','plate','open','web','success',NULL,NULL,'192.168.1.220',NULL,NULL,321,NULL,'{\"demo\":true}'),
(232,'be2dfc6b-3cef-4e71-9a9d-b108dfd07741','2026-09-27 15:38:15',NULL,1,'resident',14,NULL,NULL,'Семёнова Татьяна Петровна','14','plate','open','api','success',NULL,NULL,'192.168.1.129',NULL,NULL,873,NULL,'{\"demo\":true}'),
(233,'387543a8-1add-49ab-b0fd-574c84b64473','2026-09-27 10:16:52',NULL,1,'resident',20,NULL,NULL,'Орлова Ольга Андреевич','20','own','open','api','success',NULL,NULL,'192.168.1.162',NULL,NULL,673,NULL,'{\"demo\":true}'),
(234,'9e4afb85-c164-4951-9a2f-a4ef32f41aca','2026-09-27 10:22:33',NULL,1,'admin',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','manual','open','admin','success',NULL,NULL,'192.168.1.82',NULL,NULL,842,NULL,'{\"demo\":true}'),
(235,'be688b2a-9d86-448b-b9ee-02fa127df51e','2026-09-27 09:30:10',NULL,1,'admin',13,NULL,NULL,'Лебедев Николай Ивановна','13','manual','open','telegram','success',NULL,NULL,'192.168.1.54',NULL,NULL,737,NULL,'{\"demo\":true}'),
(236,'555c1f6d-3048-4f4e-ba1c-161ac26e010b','2026-09-27 06:50:23',NULL,1,'guest',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','guest','open','telegram','success',NULL,NULL,'192.168.1.162',NULL,NULL,276,NULL,'{\"demo\":true}'),
(237,'536460ef-67b1-4307-b34e-8630729183f4','2026-09-27 08:51:44',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','plate','open','web','success',NULL,NULL,'192.168.1.136',NULL,NULL,641,NULL,'{\"demo\":true}'),
(238,'1b4ac87c-832a-49aa-8a05-f730227a3d9b','2026-09-27 23:53:34',NULL,1,'resident',20,NULL,NULL,'Орлова Ольга Андреевич','20','own','open','admin','success',NULL,NULL,'192.168.1.72',NULL,NULL,758,NULL,'{\"demo\":true}'),
(239,'21c85709-6474-4b7c-a4d5-1c6d13a587ca','2026-09-27 07:20:48',NULL,1,'resident',14,NULL,NULL,'Семёнова Татьяна Петровна','14','own','open','cabinet','success',NULL,NULL,'192.168.1.36',NULL,NULL,252,NULL,'{\"demo\":true}'),
(240,'169a3fc9-0e4c-4439-a087-7229848f65ca','2026-09-27 16:37:10',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','own','open','admin','success',NULL,NULL,'192.168.1.142',NULL,NULL,746,NULL,'{\"demo\":true}'),
(241,'2bf87e95-c9f5-41f0-9468-999df5ccb4b0','2026-09-28 06:29:11',NULL,1,'resident',14,NULL,NULL,'Семёнова Татьяна Петровна','14','plate','open','cabinet','success',NULL,NULL,'192.168.1.165',NULL,NULL,675,NULL,'{\"demo\":true}'),
(242,'0b5dfb00-aea1-46f9-88c6-cfe35b1f9300','2026-09-28 08:40:51',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','own','open','web','success',NULL,NULL,'192.168.1.24',NULL,NULL,154,NULL,'{\"demo\":true}'),
(243,'1e1dafdb-fcd4-4e31-8c87-58f1fce0bea2','2026-09-28 23:23:03',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','plate','open','web','success',NULL,NULL,'192.168.1.25',NULL,NULL,819,NULL,'{\"demo\":true}'),
(244,'b74f754c-8e8e-4dc0-8d58-2dba93c90e35','2026-09-28 06:13:54',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','own','open','cabinet','success',NULL,NULL,'192.168.1.194',NULL,NULL,619,NULL,'{\"demo\":true}'),
(245,'daa85d96-4df6-4357-a435-c2b13680e830','2026-09-28 15:27:56',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','own','open','telegram','success',NULL,NULL,'192.168.1.185',NULL,NULL,343,NULL,'{\"demo\":true}'),
(246,'d50dd3e5-8271-44aa-80db-c38b5b96b11d','2026-09-28 16:51:08',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','own','open','cabinet','success',NULL,NULL,'192.168.1.202',NULL,NULL,838,NULL,'{\"demo\":true}'),
(247,'9284c5f4-457e-4446-a35c-5037622510ed','2026-09-28 13:26:59',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','api','success',NULL,NULL,'192.168.1.59',NULL,NULL,748,NULL,'{\"demo\":true}'),
(248,'febafa2e-2aa6-413a-aaf2-f08692f0ee45','2026-09-28 12:17:46',NULL,1,'resident',16,NULL,NULL,'Павлова Юлия Николаевич','16','own','open','admin','success',NULL,NULL,'192.168.1.222',NULL,NULL,725,NULL,'{\"demo\":true}'),
(249,'5e9ee7c8-5bb8-4bc4-9573-3bf3281e8ab9','2026-09-28 20:57:11',NULL,1,'resident',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','plate','open','admin','success',NULL,NULL,'192.168.1.83',NULL,NULL,481,NULL,'{\"demo\":true}'),
(250,'e0caafd6-7ee0-431b-8343-292cbf40337f','2026-09-28 15:33:58',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','own','open','admin','success',NULL,NULL,'192.168.1.26',NULL,NULL,444,NULL,'{\"demo\":true}'),
(251,'31c03317-a832-481d-99fc-5fed3d2f462d','2026-09-28 17:04:13',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','plate','open','api','success',NULL,NULL,'192.168.1.29',NULL,NULL,563,NULL,'{\"demo\":true}'),
(252,'f9d06a0d-079f-4cf4-9398-4086aaf8a74e','2026-09-28 17:07:15',NULL,1,'resident',20,NULL,NULL,'Орлова Ольга Андреевич','20','plate','open','api','success',NULL,NULL,'192.168.1.190',NULL,NULL,317,NULL,'{\"demo\":true}'),
(253,'61001b68-de82-4d11-ad9c-0b777536b63b','2026-09-28 12:22:12',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','own','open','web','success',NULL,NULL,'192.168.1.111',NULL,NULL,787,NULL,'{\"demo\":true}'),
(254,'0f2e24bc-d3af-443a-9f02-102ad251906e','2026-09-28 22:44:49',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','own','open','api','success',NULL,NULL,'192.168.1.131',NULL,NULL,346,NULL,'{\"demo\":true}'),
(255,'1693fc56-5366-4fec-b158-18ff8257d2bf','2026-09-28 11:34:46',NULL,1,'admin',10,NULL,NULL,'Морозова Наталья Петрович','10','manual','open','admin','success',NULL,NULL,'192.168.1.47',NULL,NULL,879,NULL,'{\"demo\":true}'),
(256,'400b39f7-97f6-4fcc-b462-454388a664ad','2026-09-28 15:04:02',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','plate','open','api','success',NULL,NULL,'192.168.1.21',NULL,NULL,451,NULL,'{\"demo\":true}'),
(257,'9ca2ebd9-0c90-4fa9-9722-3821d94e0260','2026-09-28 18:04:31',NULL,1,'resident',11,NULL,NULL,'Волков Павел Сергеевич','11','own','open','cabinet','success',NULL,NULL,'192.168.1.203',NULL,NULL,887,NULL,'{\"demo\":true}'),
(258,'71f4219e-da87-4cce-9d03-f3bb23699028','2026-09-28 11:57:05',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','plate','open','telegram','success',NULL,NULL,'192.168.1.90',NULL,NULL,411,NULL,'{\"demo\":true}'),
(259,'959dc1b6-735d-4581-8074-50f841a7574b','2026-09-28 06:45:27',NULL,1,'admin',10,NULL,NULL,'Морозова Наталья Петрович','10','manual','open','web','success',NULL,NULL,'192.168.1.98',NULL,NULL,583,NULL,'{\"demo\":true}'),
(260,'e121da94-d7c9-4c8f-8fc9-eb0f7b908045','2026-09-28 09:07:06',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','open','admin','success',NULL,NULL,'192.168.1.162',NULL,NULL,622,NULL,'{\"demo\":true}'),
(261,'6159b16e-284e-4bb5-a08e-0549e1b5d13f','2026-09-29 14:26:15',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','plate','open','api','success',NULL,NULL,'192.168.1.33',NULL,NULL,746,NULL,'{\"demo\":true}'),
(262,'24158032-3a67-4cfe-a12c-c96bca66971b','2026-09-29 20:18:11',NULL,1,'guest',15,NULL,NULL,'Егоров Виктор Сергеевна','15','guest','open','web','success',NULL,NULL,'192.168.1.179',NULL,NULL,252,NULL,'{\"demo\":true}'),
(263,'9a57a317-e993-4f67-a5a3-54d7bb648caa','2026-09-29 06:01:34',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','plate','open','api','success',NULL,NULL,'192.168.1.79',NULL,NULL,745,NULL,'{\"demo\":true}'),
(264,'45e4a631-ad31-40ac-8a9d-e787f2d5b03e','2026-09-29 23:15:33',NULL,1,'resident',22,NULL,NULL,'Макарова Анна Петровна','22','own','open','telegram','success',NULL,NULL,'192.168.1.102',NULL,NULL,509,NULL,'{\"demo\":true}'),
(265,'2bd7fe5f-b6c6-4db2-8a66-75b3f444d454','2026-09-29 19:27:43',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','own','open','telegram','success',NULL,NULL,'192.168.1.178',NULL,NULL,364,NULL,'{\"demo\":true}'),
(266,'b5af3abe-03a3-4ab7-8241-29fea54831cc','2026-09-29 23:00:53',NULL,1,'resident',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','own','open','cabinet','success',NULL,NULL,'192.168.1.127',NULL,NULL,812,NULL,'{\"demo\":true}'),
(267,'58f6bd12-c63a-4e01-b412-01c3b6e05e04','2026-09-29 08:45:59',NULL,1,'resident',22,NULL,NULL,'Макарова Анна Петровна','22','own','open','web','success',NULL,NULL,'192.168.1.102',NULL,NULL,160,NULL,'{\"demo\":true}'),
(268,'8a165fb7-3e47-4800-85f2-678cb57589a6','2026-09-29 22:58:41',NULL,1,'admin',11,NULL,NULL,'Волков Павел Сергеевич','11','manual','open','cabinet','success',NULL,NULL,'192.168.1.224',NULL,NULL,511,NULL,'{\"demo\":true}'),
(269,'e7ab43d5-d47c-4466-be1c-0b1d6745b0d1','2026-09-30 10:15:52',NULL,1,'guest',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','guest','open','web','success',NULL,NULL,'192.168.1.50',NULL,NULL,363,NULL,'{\"demo\":true}'),
(270,'9cc2fed5-5777-4452-8d21-bdd52ab21fbb','2026-09-30 11:59:43',NULL,1,'resident',16,NULL,NULL,'Павлова Юлия Николаевич','16','plate','open','cabinet','success',NULL,NULL,'192.168.1.112',NULL,NULL,715,NULL,'{\"demo\":true}'),
(271,'8fb801c0-c9c2-4b9b-ad4f-02d4b30c5f8f','2026-09-30 17:40:34',NULL,1,'resident',11,NULL,NULL,'Волков Павел Сергеевич','11','plate','open','web','success',NULL,NULL,'192.168.1.196',NULL,NULL,703,NULL,'{\"demo\":true}'),
(272,'07bb4f3d-4335-4d48-a5f5-7af307f4cb5a','2026-09-30 11:53:49',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','own','open','cabinet','success',NULL,NULL,'192.168.1.44',NULL,NULL,132,NULL,'{\"demo\":true}'),
(273,'07846e6b-0a95-41f1-989b-d362e51c7d75','2026-09-30 15:19:00',NULL,1,'guest',13,NULL,NULL,'Лебедев Николай Ивановна','13','guest','open','cabinet','success',NULL,NULL,'192.168.1.43',NULL,NULL,691,NULL,'{\"demo\":true}'),
(274,'5dc95867-10cf-4dcb-a4a7-bfc9728e4b19','2026-09-30 23:17:49',NULL,1,'guest',1,NULL,NULL,'Иванов Иван Иванович','1','guest','open','cabinet','success',NULL,NULL,'192.168.1.84',NULL,NULL,694,NULL,'{\"demo\":true}'),
(275,'a9366f4f-3d6c-4871-8e42-f512e0b2f7ef','2026-09-30 19:59:51',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','own','open','web','success',NULL,NULL,'192.168.1.208',NULL,NULL,878,NULL,'{\"demo\":true}'),
(276,'a0c01ff8-3d52-4d9e-bdda-66151af2f247','2026-09-30 18:12:19',NULL,1,'guest',13,NULL,NULL,'Лебедев Николай Ивановна','13','guest','denied','api','denied','Тихие часы',NULL,'192.168.1.32',NULL,NULL,248,NULL,'{\"demo\":true}'),
(277,'337c9486-b075-4a46-b58a-fae8e700e495','2026-09-30 15:04:58',NULL,1,'admin',17,NULL,NULL,'Козлов Иван Иванович','17','manual','open','cabinet','success',NULL,NULL,'192.168.1.146',NULL,NULL,869,NULL,'{\"demo\":true}'),
(278,'3375e4fd-bb3c-4869-a946-17e3797ce77d','2026-09-30 23:12:42',NULL,1,'guest',9,NULL,NULL,'Фёдоров Андрей Иванович','9','guest','open','api','success',NULL,NULL,'192.168.1.204',NULL,NULL,564,NULL,'{\"demo\":true}'),
(279,'f655db35-67d0-4383-af20-5a5014faa9f9','2026-09-30 13:09:34',NULL,1,'admin',16,NULL,NULL,'Павлова Юлия Николаевич','16','manual','open','telegram','success',NULL,NULL,'192.168.1.173',NULL,NULL,172,NULL,'{\"demo\":true}'),
(280,'b8c315f5-d83e-43cd-9a9d-b3e3555c93aa','2026-09-30 18:53:58',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','plate','open','cabinet','success',NULL,NULL,'192.168.1.196',NULL,NULL,608,NULL,'{\"demo\":true}'),
(281,'7f9bdfb5-927b-4ed0-8b66-6e101d7ef2ac','2026-10-01 11:58:09',NULL,1,'resident',8,NULL,NULL,'Михайлова Елена Николаевич','8','own','open','web','success',NULL,NULL,'192.168.1.47',NULL,NULL,266,NULL,'{\"demo\":true}'),
(282,'2cf519f1-5af6-4ed8-b50c-5e9d0b2a7ac5','2026-10-01 07:02:02',NULL,1,'guest',17,NULL,NULL,'Козлов Иван Иванович','17','guest','open','web','success',NULL,NULL,'192.168.1.202',NULL,NULL,233,NULL,'{\"demo\":true}'),
(283,'a0d40f92-cfbb-46d1-b37d-9b9adf8e8c16','2026-10-01 10:58:03',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','own','open','web','success',NULL,NULL,'192.168.1.212',NULL,NULL,763,NULL,'{\"demo\":true}'),
(284,'228979bc-5d37-4d6b-a7e8-5006031b2251','2026-10-01 18:30:08',NULL,1,'resident',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','own','open','api','success',NULL,NULL,'192.168.1.200',NULL,NULL,687,NULL,'{\"demo\":true}'),
(285,'bf1a2054-ccd4-4e5f-89b9-ffb77c17b792','2026-10-01 07:01:53',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','denied','web','denied','Превышен лимит открытий',NULL,'192.168.1.212',NULL,NULL,363,NULL,'{\"demo\":true}'),
(286,'880749d7-ec99-4496-ae64-92ba340ff26f','2026-10-01 21:18:45',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','own','open','telegram','success',NULL,NULL,'192.168.1.197',NULL,NULL,303,NULL,'{\"demo\":true}'),
(287,'19040fc6-2907-4d82-8490-83ee1c153d9e','2026-10-01 11:37:59',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','own','open','cabinet','success',NULL,NULL,'192.168.1.201',NULL,NULL,728,NULL,'{\"demo\":true}'),
(288,'cc07ec19-a52b-4c31-b667-207e8cdf5876','2026-10-01 21:10:12',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','own','open','telegram','success',NULL,NULL,'192.168.1.79',NULL,NULL,632,NULL,'{\"demo\":true}'),
(289,'5df38501-da2b-412b-b2ca-3757b758e9dd','2026-10-01 06:52:13',NULL,1,'guest',7,NULL,NULL,'Соколов Сергей Сергеевна','7','guest','open','cabinet','success',NULL,NULL,'192.168.1.204',NULL,NULL,617,NULL,'{\"demo\":true}'),
(290,'1fe0ba16-bf9d-4212-a8fd-6de60e590665','2026-10-01 12:14:48',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','plate','open','cabinet','success',NULL,NULL,'192.168.1.161',NULL,NULL,270,NULL,'{\"demo\":true}'),
(291,'1d1bef8d-155e-4e14-8bb7-006d3bf83c60','2026-10-01 21:44:56',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','own','open','admin','success',NULL,NULL,'192.168.1.173',NULL,NULL,290,NULL,'{\"demo\":true}'),
(292,'6cad71b3-b0d4-42d9-8273-98749a502495','2026-10-01 08:54:16',NULL,1,'guest',19,NULL,NULL,'Николаев Алексей Сергеевич','19','guest','open','api','success',NULL,NULL,'192.168.1.175',NULL,NULL,218,NULL,'{\"demo\":true}'),
(293,'e93651a4-d705-4759-a78c-50054d6bbf00','2026-10-01 22:39:41',NULL,1,'resident',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','own','open','telegram','success',NULL,NULL,'192.168.1.84',NULL,NULL,856,NULL,'{\"demo\":true}'),
(294,'25cf7ab9-faf9-4545-825f-47e5dcb2b665','2026-10-01 06:12:53',NULL,1,'resident',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','own','open','web','success',NULL,NULL,'192.168.1.137',NULL,NULL,407,NULL,'{\"demo\":true}'),
(295,'4e524e07-0400-4954-a10c-c4fa83475525','2026-10-01 06:02:01',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','telegram','success',NULL,NULL,'192.168.1.222',NULL,NULL,622,NULL,'{\"demo\":true}'),
(296,'76032a38-3e71-4bdd-b49f-5559cb7aae6e','2026-10-01 22:31:50',NULL,1,'admin',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','manual','denied','api','denied','Доступ приостановлен',NULL,'192.168.1.36',NULL,NULL,583,NULL,'{\"demo\":true}'),
(297,'183f3ce4-2d37-4bdd-b094-31fddb691d0e','2026-10-01 06:45:33',NULL,1,'guest',11,NULL,NULL,'Волков Павел Сергеевич','11','guest','open','telegram','success',NULL,NULL,'192.168.1.187',NULL,NULL,432,NULL,'{\"demo\":true}'),
(298,'34c6ccbc-8c5f-4a69-a815-ad00070207de','2026-10-01 19:29:18',NULL,1,'resident',16,NULL,NULL,'Павлова Юлия Николаевич','16','own','open','web','success',NULL,NULL,'192.168.1.250',NULL,NULL,774,NULL,'{\"demo\":true}'),
(299,'42b11267-bbd1-4882-909f-0ce463d490b1','2026-10-01 19:35:26',NULL,1,'admin',9,NULL,NULL,'Фёдоров Андрей Иванович','9','manual','denied','telegram','denied','Доступ приостановлен',NULL,'192.168.1.201',NULL,NULL,391,NULL,'{\"demo\":true}'),
(300,'6a0cda9d-98ac-46ea-bbde-d08ab0737312','2026-10-01 12:13:53',NULL,1,'admin',7,NULL,NULL,'Соколов Сергей Сергеевна','7','manual','open','cabinet','success',NULL,NULL,'192.168.1.188',NULL,NULL,629,NULL,'{\"demo\":true}'),
(301,'bcf8c47e-5660-46db-9b03-26fd62edad55','2026-10-02 21:28:59',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','cabinet','success',NULL,NULL,'192.168.1.243',NULL,NULL,816,NULL,'{\"demo\":true}'),
(302,'db10e44d-ea3f-4a57-90e9-5465e43228f6','2026-10-02 18:48:05',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','plate','open','web','success',NULL,NULL,'192.168.1.176',NULL,NULL,276,NULL,'{\"demo\":true}'),
(303,'7f7dc9de-5bcc-443e-b67b-8da475cf3d12','2026-10-02 22:17:47',NULL,1,'resident',11,NULL,NULL,'Волков Павел Сергеевич','11','own','open','cabinet','success',NULL,NULL,'192.168.1.36',NULL,NULL,711,NULL,'{\"demo\":true}'),
(304,'abfb61cd-5c01-4268-a313-7515d7fbd702','2026-10-02 07:50:44',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','own','open','admin','success',NULL,NULL,'192.168.1.203',NULL,NULL,643,NULL,'{\"demo\":true}'),
(305,'f8eb3fdd-b318-42d1-874f-7ff913f02afb','2026-10-02 22:09:43',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','cabinet','success',NULL,NULL,'192.168.1.35',NULL,NULL,433,NULL,'{\"demo\":true}'),
(306,'7c30431b-b194-4918-8d5b-ba7bb78095ae','2026-10-02 06:59:31',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','own','open','web','success',NULL,NULL,'192.168.1.57',NULL,NULL,830,NULL,'{\"demo\":true}'),
(307,'441a732e-568a-4f97-998c-abbdf469f80b','2026-10-02 15:00:25',NULL,1,'admin',18,NULL,NULL,'Степанова Мария Петрович','18','manual','open','cabinet','success',NULL,NULL,'192.168.1.62',NULL,NULL,884,NULL,'{\"demo\":true}'),
(308,'6683a2de-1407-4d84-a01c-ef46b5bba17b','2026-10-03 13:56:40',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','own','open','telegram','success',NULL,NULL,'192.168.1.34',NULL,NULL,190,NULL,'{\"demo\":true}'),
(309,'53c00ed7-5421-4d99-b841-e8a16fe3c386','2026-10-03 14:52:59',NULL,1,'resident',22,NULL,NULL,'Макарова Анна Петровна','22','own','open','cabinet','success',NULL,NULL,'192.168.1.139',NULL,NULL,373,NULL,'{\"demo\":true}'),
(310,'34a2bfbe-0933-4e94-b3d5-5cd1add7c0c9','2026-10-03 14:57:40',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','own','open','api','success',NULL,NULL,'192.168.1.130',NULL,NULL,793,NULL,'{\"demo\":true}'),
(311,'47cfa25f-c4bf-43d9-a17b-d3fcdafe2816','2026-10-03 19:22:52',NULL,1,'guest',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','guest','open','cabinet','success',NULL,NULL,'192.168.1.97',NULL,NULL,530,NULL,'{\"demo\":true}'),
(312,'8dce2567-3edb-4e1d-91b5-863b1ae834b2','2026-10-03 07:18:26',NULL,1,'admin',9,NULL,NULL,'Фёдоров Андрей Иванович','9','manual','open','admin','success',NULL,NULL,'192.168.1.81',NULL,NULL,231,NULL,'{\"demo\":true}'),
(313,'ba9be25e-fa3b-4cf6-a484-ba864084c9fb','2026-10-03 12:29:07',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','own','open','api','success',NULL,NULL,'192.168.1.102',NULL,NULL,610,NULL,'{\"demo\":true}'),
(314,'a315a6ba-3b39-4671-b1d1-dd0931b73b8c','2026-10-03 06:14:16',NULL,1,'guest',17,NULL,NULL,'Козлов Иван Иванович','17','guest','open','web','success',NULL,NULL,'192.168.1.36',NULL,NULL,861,NULL,'{\"demo\":true}'),
(315,'7c1ebf08-86aa-41d9-a410-a66b4cd431a3','2026-10-03 19:29:21',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','own','open','cabinet','success',NULL,NULL,'192.168.1.132',NULL,NULL,273,NULL,'{\"demo\":true}'),
(316,'e32ce481-fe3d-40e0-b7b5-cc9acf72cc24','2026-10-03 22:54:03',NULL,1,'resident',16,NULL,NULL,'Павлова Юлия Николаевич','16','plate','denied','web','denied','Доступ приостановлен',NULL,'192.168.1.141',NULL,NULL,607,NULL,'{\"demo\":true}'),
(317,'ef5d5f56-c412-4ea1-91f3-aa6e8214acfa','2026-10-04 10:47:44',NULL,1,'guest',7,NULL,NULL,'Соколов Сергей Сергеевна','7','guest','open','telegram','success',NULL,NULL,'192.168.1.208',NULL,NULL,284,NULL,'{\"demo\":true}'),
(318,'af0080d5-b0d4-4296-8ce7-360e840bdc63','2026-10-04 08:34:44',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','own','open','web','success',NULL,NULL,'192.168.1.70',NULL,NULL,363,NULL,'{\"demo\":true}'),
(319,'80fd4ef2-122d-4f7a-a0f8-9db088db5390','2026-10-04 14:41:44',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','own','open','web','success',NULL,NULL,'192.168.1.80',NULL,NULL,364,NULL,'{\"demo\":true}'),
(320,'5c336c9e-c824-4492-ba10-63c96f7eb07c','2026-10-04 19:06:06',NULL,1,'admin',14,NULL,NULL,'Семёнова Татьяна Петровна','14','manual','open','cabinet','success',NULL,NULL,'192.168.1.199',NULL,NULL,578,NULL,'{\"demo\":true}'),
(321,'967383f9-4814-4f8b-9c94-394baaa4aabd','2026-10-04 16:05:40',NULL,1,'resident',15,NULL,NULL,'Егоров Виктор Сергеевна','15','own','open','admin','success',NULL,NULL,'192.168.1.51',NULL,NULL,703,NULL,'{\"demo\":true}'),
(322,'15f77857-63ce-4185-ab36-c10908892865','2026-10-04 23:13:33',NULL,1,'resident',22,NULL,NULL,'Макарова Анна Петровна','22','own','open','cabinet','success',NULL,NULL,'192.168.1.143',NULL,NULL,515,NULL,'{\"demo\":true}'),
(323,'a907dad2-7c91-4b30-be46-9778750d305e','2026-10-04 11:11:15',NULL,1,'resident',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','own','open','api','success',NULL,NULL,'192.168.1.100',NULL,NULL,517,NULL,'{\"demo\":true}'),
(324,'8a2bac0d-995b-4423-9cd0-22c7c456247a','2026-10-04 06:49:35',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','own','open','admin','success',NULL,NULL,'192.168.1.76',NULL,NULL,563,NULL,'{\"demo\":true}'),
(325,'b9e05301-ebef-4c75-a576-fc5cc2b50c08','2026-10-04 12:23:46',NULL,1,'admin',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','manual','open','web','success',NULL,NULL,'192.168.1.91',NULL,NULL,448,NULL,'{\"demo\":true}'),
(326,'47507a12-9f22-4c5c-be99-06fec96d6fee','2026-10-04 18:03:34',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','own','open','telegram','success',NULL,NULL,'192.168.1.54',NULL,NULL,607,NULL,'{\"demo\":true}'),
(327,'c751e2b9-b716-46ac-bea0-27ca31c6c7fa','2026-10-04 09:33:00',NULL,1,'resident',14,NULL,NULL,'Семёнова Татьяна Петровна','14','own','open','api','success',NULL,NULL,'192.168.1.153',NULL,NULL,506,NULL,'{\"demo\":true}'),
(328,'43c89fa9-a92f-4bf2-a93f-32218e9f4bd2','2026-10-04 06:00:39',NULL,1,'resident',15,NULL,NULL,'Егоров Виктор Сергеевна','15','own','open','cabinet','success',NULL,NULL,'192.168.1.209',NULL,NULL,423,NULL,'{\"demo\":true}'),
(329,'d9e70724-a0b9-4198-8ec5-f37317f40c01','2026-10-04 15:45:51',NULL,1,'guest',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','guest','open','admin','success',NULL,NULL,'192.168.1.108',NULL,NULL,451,NULL,'{\"demo\":true}'),
(330,'eacac79f-9d2e-4382-9f8a-cbce17d9d358','2026-10-04 16:32:44',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','web','success',NULL,NULL,'192.168.1.237',NULL,NULL,672,NULL,'{\"demo\":true}'),
(331,'dd9aa9a3-fc35-401a-96f5-204fa45e8408','2026-10-04 20:42:13',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','plate','open','admin','success',NULL,NULL,'192.168.1.30',NULL,NULL,492,NULL,'{\"demo\":true}'),
(332,'6e6318c9-393d-41cb-9e3e-9c258eaae56f','2026-10-04 08:07:16',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','open','cabinet','success',NULL,NULL,'192.168.1.159',NULL,NULL,468,NULL,'{\"demo\":true}'),
(333,'89de5175-895e-4a1f-ab60-21892cc20a9a','2026-10-04 07:09:41',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','api','success',NULL,NULL,'192.168.1.91',NULL,NULL,592,NULL,'{\"demo\":true}'),
(334,'5c2c97b8-fc74-4f2f-b6fc-e3e0152e241a','2026-10-04 23:27:47',NULL,1,'admin',15,NULL,NULL,'Егоров Виктор Сергеевна','15','manual','open','web','success',NULL,NULL,'192.168.1.82',NULL,NULL,646,NULL,'{\"demo\":true}'),
(335,'713e6453-6e54-495c-98ed-cce1bf7ced55','2026-10-04 22:18:21',NULL,1,'guest',10,NULL,NULL,'Морозова Наталья Петрович','10','guest','open','admin','success',NULL,NULL,'192.168.1.190',NULL,NULL,263,NULL,'{\"demo\":true}'),
(336,'d12e67f2-d26c-45e2-a55c-4f39b70a7e0b','2026-10-04 15:29:13',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','plate','open','web','success',NULL,NULL,'192.168.1.125',NULL,NULL,762,NULL,'{\"demo\":true}'),
(337,'234f15af-745d-465d-927a-3d9debfd7cff','2026-10-04 19:11:10',NULL,1,'guest',20,NULL,NULL,'Орлова Ольга Андреевич','20','guest','open','admin','success',NULL,NULL,'192.168.1.122',NULL,NULL,136,NULL,'{\"demo\":true}'),
(338,'2eb11550-33cc-4320-9ef2-fefab27137ee','2026-10-05 13:50:35',NULL,1,'resident',1,NULL,NULL,'Иванов Иван Иванович','1','own','open','telegram','success',NULL,NULL,'192.168.1.90',NULL,NULL,441,NULL,'{\"demo\":true}'),
(339,'c45612f2-807c-4261-9c7b-c76b9c3779dc','2026-10-05 18:34:31',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','own','open','api','success',NULL,NULL,'192.168.1.150',NULL,NULL,743,NULL,'{\"demo\":true}'),
(340,'451c08b5-8d12-445b-bcdc-bcb8f12fdcef','2026-10-05 22:20:25',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','cabinet','success',NULL,NULL,'192.168.1.229',NULL,NULL,818,NULL,'{\"demo\":true}'),
(341,'c5093660-b601-4cec-81c8-419dc3eda212','2026-10-05 09:02:34',NULL,1,'guest',14,NULL,NULL,'Семёнова Татьяна Петровна','14','guest','open','telegram','success',NULL,NULL,'192.168.1.127',NULL,NULL,295,NULL,'{\"demo\":true}'),
(342,'863b6362-14d1-4e37-b027-a9c1afa18359','2026-10-05 14:34:55',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','open','web','success',NULL,NULL,'192.168.1.169',NULL,NULL,815,NULL,'{\"demo\":true}'),
(343,'57e43a40-82af-4ea5-9aba-8ae05d9a79f8','2026-10-05 09:31:43',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','plate','open','admin','success',NULL,NULL,'192.168.1.126',NULL,NULL,163,NULL,'{\"demo\":true}'),
(344,'d947a33c-0c8f-4cf2-bcc8-9da9facbf9be','2026-10-06 20:41:13',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','plate','open','web','success',NULL,NULL,'192.168.1.222',NULL,NULL,748,NULL,'{\"demo\":true}'),
(345,'72e03888-8c5a-44f1-b58c-fcc0bdbca3d7','2026-10-06 11:38:39',NULL,1,'guest',1,NULL,NULL,'Иванов Иван Иванович','1','guest','open','cabinet','success',NULL,NULL,'192.168.1.48',NULL,NULL,141,NULL,'{\"demo\":true}'),
(346,'0ad47fad-e026-481a-98a8-21f02a362270','2026-10-06 18:16:30',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','own','open','admin','success',NULL,NULL,'192.168.1.166',NULL,NULL,721,NULL,'{\"demo\":true}'),
(347,'2a745148-8ac3-4817-a35a-d8a63cbc4f0c','2026-10-06 23:11:09',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','own','open','cabinet','success',NULL,NULL,'192.168.1.54',NULL,NULL,333,NULL,'{\"demo\":true}'),
(348,'abf11b56-5134-417c-a00c-3fafeabe6f6a','2026-10-06 09:25:23',NULL,1,'admin',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','manual','open','telegram','success',NULL,NULL,'192.168.1.235',NULL,NULL,874,NULL,'{\"demo\":true}'),
(349,'d50d3836-5e8b-422e-a398-8a693575ce89','2026-10-06 15:14:39',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','plate','open','admin','success',NULL,NULL,'192.168.1.95',NULL,NULL,746,NULL,'{\"demo\":true}'),
(350,'5635dcb0-ce4d-4d39-a042-2c0a811df331','2026-10-06 15:16:42',NULL,1,'resident',22,NULL,NULL,'Макарова Анна Петровна','22','plate','open','api','success',NULL,NULL,'192.168.1.68',NULL,NULL,602,NULL,'{\"demo\":true}'),
(351,'c06ad21e-f400-4cd4-a171-3871e307055c','2026-10-06 10:37:23',NULL,1,'admin',15,NULL,NULL,'Егоров Виктор Сергеевна','15','manual','open','cabinet','success',NULL,NULL,'192.168.1.117',NULL,NULL,213,NULL,'{\"demo\":true}'),
(352,'4da84438-86f5-42fb-96f7-6d467d32d270','2026-10-06 12:06:30',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','plate','denied','telegram','denied','Превышен лимит открытий',NULL,'192.168.1.80',NULL,NULL,768,NULL,'{\"demo\":true}'),
(353,'391aef75-5c03-4f2b-b4e0-f93e77d10560','2026-10-06 12:46:22',NULL,1,'resident',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','own','open','api','success',NULL,NULL,'192.168.1.26',NULL,NULL,483,NULL,'{\"demo\":true}'),
(354,'8a4c7ccd-b75f-4ca2-96ab-4dcb974f26d2','2026-10-07 08:35:43',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','own','open','web','success',NULL,NULL,'192.168.1.237',NULL,NULL,703,NULL,'{\"demo\":true}'),
(355,'92c5d8ef-6d8a-42c3-81eb-2d709176b438','2026-10-07 10:02:02',NULL,1,'resident',15,NULL,NULL,'Егоров Виктор Сергеевна','15','own','open','telegram','success',NULL,NULL,'192.168.1.165',NULL,NULL,579,NULL,'{\"demo\":true}'),
(356,'8e5604d7-0220-45de-8e1a-c073fc0928af','2026-10-07 22:37:56',NULL,1,'resident',16,NULL,NULL,'Павлова Юлия Николаевич','16','own','open','telegram','success',NULL,NULL,'192.168.1.23',NULL,NULL,494,NULL,'{\"demo\":true}'),
(357,'e3dbdec7-78c4-4b95-82f8-71043171b64d','2026-10-07 12:25:18',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','plate','open','telegram','success',NULL,NULL,'192.168.1.232',NULL,NULL,465,NULL,'{\"demo\":true}'),
(358,'f6ff2473-a995-4fb5-aa25-28f25514cbd1','2026-10-07 21:09:47',NULL,1,'resident',20,NULL,NULL,'Орлова Ольга Андреевич','20','own','open','cabinet','success',NULL,NULL,'192.168.1.134',NULL,NULL,265,NULL,'{\"demo\":true}'),
(359,'e05d6844-5e3b-469c-bb93-709d7de83d15','2026-10-07 21:38:37',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','telegram','success',NULL,NULL,'192.168.1.161',NULL,NULL,527,NULL,'{\"demo\":true}'),
(360,'42065e0f-cb04-41ed-ad59-2774dee67d35','2026-10-07 07:22:32',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','own','open','admin','success',NULL,NULL,'192.168.1.178',NULL,NULL,640,NULL,'{\"demo\":true}'),
(361,'f7fe39d6-bc03-4432-b8a4-15a151ba61c8','2026-10-07 21:42:52',NULL,1,'resident',16,NULL,NULL,'Павлова Юлия Николаевич','16','own','open','web','success',NULL,NULL,'192.168.1.37',NULL,NULL,208,NULL,'{\"demo\":true}'),
(362,'8cc274b0-9cbc-43b6-af0b-7e5f184c2d59','2026-10-07 12:20:53',NULL,1,'resident',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','own','open','web','success',NULL,NULL,'192.168.1.191',NULL,NULL,747,NULL,'{\"demo\":true}'),
(363,'7cdc457b-8f87-4ef0-9ccc-a01ded74dc86','2026-10-07 21:08:10',NULL,1,'guest',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','guest','open','telegram','success',NULL,NULL,'192.168.1.166',NULL,NULL,866,NULL,'{\"demo\":true}'),
(364,'c73539fa-3455-48f0-b2cf-a01251fa432e','2026-10-07 18:50:21',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','api','success',NULL,NULL,'192.168.1.214',NULL,NULL,818,NULL,'{\"demo\":true}'),
(365,'6480b40d-cb85-4c91-bdc8-9cb5b1746e40','2026-10-07 13:33:00',NULL,1,'resident',15,NULL,NULL,'Егоров Виктор Сергеевна','15','own','open','web','success',NULL,NULL,'192.168.1.236',NULL,NULL,725,NULL,'{\"demo\":true}'),
(366,'c7dd8191-ae4e-4108-b381-0d00320bb3d5','2026-10-07 08:03:23',NULL,1,'admin',22,NULL,NULL,'Макарова Анна Петровна','22','manual','open','api','success',NULL,NULL,'192.168.1.28',NULL,NULL,896,NULL,'{\"demo\":true}'),
(367,'a84421de-1dec-460f-b209-a3b7f987bebc','2026-10-07 13:50:47',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','own','open','api','success',NULL,NULL,'192.168.1.135',NULL,NULL,410,NULL,'{\"demo\":true}'),
(368,'71c16978-9884-4403-a284-7e8266a262c3','2026-10-07 17:00:52',NULL,1,'guest',19,NULL,NULL,'Николаев Алексей Сергеевич','19','guest','open','api','success',NULL,NULL,'192.168.1.239',NULL,NULL,144,NULL,'{\"demo\":true}'),
(369,'75eeb8d6-947a-44f7-bdfd-bae75fa32674','2026-10-07 14:54:34',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','admin','success',NULL,NULL,'192.168.1.185',NULL,NULL,859,NULL,'{\"demo\":true}'),
(370,'4cd6b050-95c5-4489-b394-41be251f8805','2026-10-07 10:14:53',NULL,1,'resident',20,NULL,NULL,'Орлова Ольга Андреевич','20','own','open','cabinet','success',NULL,NULL,'192.168.1.90',NULL,NULL,686,NULL,'{\"demo\":true}'),
(371,'68012d53-50a3-4243-8279-14b75fd5cfb8','2026-10-07 08:46:10',NULL,1,'admin',9,NULL,NULL,'Фёдоров Андрей Иванович','9','manual','denied','web','denied','Доступ приостановлен',NULL,'192.168.1.63',NULL,NULL,363,NULL,'{\"demo\":true}'),
(372,'e12eee2f-9a3a-43c7-bae6-ac9817a81835','2026-10-07 06:12:57',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','plate','open','web','success',NULL,NULL,'192.168.1.33',NULL,NULL,549,NULL,'{\"demo\":true}'),
(373,'048844da-5ae5-4823-a37e-b01487a4bf1b','2026-10-07 18:24:10',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','own','open','admin','success',NULL,NULL,'192.168.1.154',NULL,NULL,250,NULL,'{\"demo\":true}'),
(374,'c9fbf866-9427-4baf-b213-c19beaf00a64','2026-10-08 14:37:59',NULL,1,'admin',7,NULL,NULL,'Соколов Сергей Сергеевна','7','manual','open','telegram','success',NULL,NULL,'192.168.1.133',NULL,NULL,809,NULL,'{\"demo\":true}'),
(375,'f5c625a7-b9f9-4245-b79a-f6683771c6b9','2026-10-08 12:01:36',NULL,1,'admin',23,NULL,NULL,'Захаров Сергей Сергеевна','23','manual','open','telegram','success',NULL,NULL,'192.168.1.118',NULL,NULL,853,NULL,'{\"demo\":true}'),
(376,'ba8f30eb-c38b-49c3-a53b-527f1054a725','2026-10-08 11:25:00',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','own','open','web','success',NULL,NULL,'192.168.1.117',NULL,NULL,124,NULL,'{\"demo\":true}'),
(377,'0e9692d4-8c84-480e-8035-6d80ad86e28e','2026-10-08 09:50:16',NULL,1,'admin',19,NULL,NULL,'Николаев Алексей Сергеевич','19','manual','open','admin','success',NULL,NULL,'192.168.1.32',NULL,NULL,622,NULL,'{\"demo\":true}'),
(378,'14deab7b-1427-436a-a4c5-4f034eca058e','2026-10-08 19:27:12',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','own','open','web','success',NULL,NULL,'192.168.1.108',NULL,NULL,596,NULL,'{\"demo\":true}'),
(379,'f8cef180-68b6-44b8-abf1-10d70905cd36','2026-10-08 08:09:32',NULL,1,'admin',17,NULL,NULL,'Козлов Иван Иванович','17','manual','open','api','success',NULL,NULL,'192.168.1.246',NULL,NULL,299,NULL,'{\"demo\":true}'),
(380,'2922da85-3303-474e-bcde-ab96b0f2d58e','2026-10-08 07:31:07',NULL,1,'guest',19,NULL,NULL,'Николаев Алексей Сергеевич','19','guest','denied','telegram','denied','Превышен лимит открытий',NULL,'192.168.1.134',NULL,NULL,484,NULL,'{\"demo\":true}'),
(381,'8989a1b8-bc7f-4f81-9d6e-6b5257cc15a6','2026-10-08 06:45:19',NULL,1,'resident',1,NULL,NULL,'Иванов Иван Иванович','1','plate','open','telegram','success',NULL,NULL,'192.168.1.33',NULL,NULL,534,NULL,'{\"demo\":true}'),
(382,'8aa9ba36-de21-48d9-9632-780f70ce929f','2026-10-08 11:23:58',NULL,1,'guest',23,NULL,NULL,'Захаров Сергей Сергеевна','23','guest','open','web','success',NULL,NULL,'192.168.1.87',NULL,NULL,206,NULL,'{\"demo\":true}'),
(383,'a1016849-dfce-40cc-9ee3-0a39d1755a1a','2026-10-08 07:05:26',NULL,1,'guest',19,NULL,NULL,'Николаев Алексей Сергеевич','19','guest','open','web','success',NULL,NULL,'192.168.1.90',NULL,NULL,300,NULL,'{\"demo\":true}'),
(384,'8612b7f2-f651-4bd0-9811-21d0afedd84d','2026-10-08 23:56:30',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','open','cabinet','success',NULL,NULL,'192.168.1.104',NULL,NULL,190,NULL,'{\"demo\":true}'),
(385,'281ef522-1fd6-43ac-87dc-b8e3ee0597b1','2026-10-08 12:26:25',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','own','open','cabinet','success',NULL,NULL,'192.168.1.186',NULL,NULL,364,NULL,'{\"demo\":true}'),
(386,'53f749a0-46cb-403a-871a-df189fb99eab','2026-10-08 13:33:47',NULL,1,'guest',7,NULL,NULL,'Соколов Сергей Сергеевна','7','guest','open','web','success',NULL,NULL,'192.168.1.245',NULL,NULL,247,NULL,'{\"demo\":true}'),
(387,'b6ff3092-9da1-406a-be36-d0687aa6f216','2026-10-08 11:02:52',NULL,1,'resident',15,NULL,NULL,'Егоров Виктор Сергеевна','15','own','open','api','success',NULL,NULL,'192.168.1.214',NULL,NULL,791,NULL,'{\"demo\":true}'),
(388,'812314db-c2fb-497f-963f-61c6477a776d','2026-10-08 12:17:27',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','open','telegram','success',NULL,NULL,'192.168.1.93',NULL,NULL,691,NULL,'{\"demo\":true}'),
(389,'f758f243-2db0-40cb-9565-0521c7aa60c0','2026-10-09 18:47:01',NULL,1,'guest',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','guest','open','admin','success',NULL,NULL,'192.168.1.93',NULL,NULL,202,NULL,'{\"demo\":true}'),
(390,'49e5afbf-19fb-4e0c-86c5-bebee4240477','2026-10-09 15:54:47',NULL,1,'resident',14,NULL,NULL,'Семёнова Татьяна Петровна','14','own','open','cabinet','success',NULL,NULL,'192.168.1.142',NULL,NULL,236,NULL,'{\"demo\":true}'),
(391,'c237c57d-b1f2-448b-b1ee-6ec2f901fc87','2026-10-09 11:13:53',NULL,1,'admin',2,NULL,NULL,'Петрова Мария Петрович','2','manual','open','cabinet','success',NULL,NULL,'192.168.1.25',NULL,NULL,624,NULL,'{\"demo\":true}'),
(392,'d0aa31b5-4578-46e2-a71f-7b221ad4664d','2026-10-09 09:56:55',NULL,1,'resident',15,NULL,NULL,'Егоров Виктор Сергеевна','15','plate','open','admin','success',NULL,NULL,'192.168.1.125',NULL,NULL,864,NULL,'{\"demo\":true}'),
(393,'48e2aa29-c13e-4352-9df0-7e112a9b35a6','2026-10-09 19:11:18',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','plate','open','web','success',NULL,NULL,'192.168.1.93',NULL,NULL,532,NULL,'{\"demo\":true}'),
(394,'16e6eac1-a017-444b-8ea8-3775eac01ba4','2026-10-09 18:49:08',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','api','success',NULL,NULL,'192.168.1.129',NULL,NULL,743,NULL,'{\"demo\":true}'),
(395,'129e6cba-5b60-4fd5-a6ca-c8b6594aaf13','2026-10-09 15:37:33',NULL,1,'resident',15,NULL,NULL,'Егоров Виктор Сергеевна','15','own','open','telegram','success',NULL,NULL,'192.168.1.217',NULL,NULL,286,NULL,'{\"demo\":true}'),
(396,'566aa761-2586-4c44-8aec-6171ce130e7b','2026-10-09 13:43:18',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','plate','open','api','success',NULL,NULL,'192.168.1.45',NULL,NULL,804,NULL,'{\"demo\":true}'),
(397,'f0fd9f44-4f4b-4db9-882b-47cd419beebd','2026-10-09 09:16:55',NULL,1,'admin',2,NULL,NULL,'Петрова Мария Петрович','2','manual','denied','admin','denied','Превышен лимит открытий',NULL,'192.168.1.80',NULL,NULL,246,NULL,'{\"demo\":true}'),
(398,'994c8df2-ab62-43d9-b9df-8ce258774589','2026-10-09 13:00:13',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','own','open','cabinet','success',NULL,NULL,'192.168.1.155',NULL,NULL,492,NULL,'{\"demo\":true}'),
(399,'e99324f1-6a6c-4d30-ac2c-0392a61c5da8','2026-10-09 22:55:08',NULL,1,'resident',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','own','open','admin','success',NULL,NULL,'192.168.1.23',NULL,NULL,462,NULL,'{\"demo\":true}'),
(400,'7498ed81-a0b8-4817-a7c1-401fa728f498','2026-10-09 19:58:46',NULL,1,'resident',1,NULL,NULL,'Иванов Иван Иванович','1','own','open','cli','success',NULL,NULL,NULL,'cli',NULL,63,NULL,'{\"ok\":true,\"message\":\"Шлагбаум открыт (эмулятор)\"}'),
(401,'fdb60cf8-7e22-4f80-a06b-4bd507dad360','2026-10-09 19:58:46',NULL,1,'guest',1,NULL,7,'Иванов Иван Иванович','1','guest','issued','cli','success','Гостевой доступ issued: 8AYG-6MMX до 2026-10-10 07:58:46',NULL,NULL,NULL,NULL,NULL,NULL,'{\"code\":\"8AYG-6MMX\",\"ttl_hours\":12,\"valid_until\":\"2026-10-10 07:58:46\",\"guest_name\":\"Курьер\"}'),
(402,'7f2b4832-298c-4935-80c6-e3d38bf0ee22','2026-10-09 19:58:46',NULL,1,'guest',1,NULL,7,'Иванов Иван Иванович (гость Курьер)','1','guest','open','web','success',NULL,NULL,NULL,'cli',NULL,61,NULL,'{\"ok\":true,\"message\":\"Шлагбаум открыт (эмулятор)\"}'),
(403,'f5ee92a0-6c3a-4e8a-a6c9-a28c564e54c3','2026-10-09 19:58:46',NULL,1,'guest',1,NULL,7,'Иванов Иван Иванович','1','guest','revoked','cli','success','smoke',NULL,NULL,NULL,NULL,NULL,NULL,'{\"code\":\"8AYG-6MMX\",\"ttl_hours\":12,\"valid_until\":\"2026-10-10 07:58:46\",\"guest_name\":\"Курьер\"}'),
(404,'b432d2dd-64a1-4b1b-b664-382188b05227','2026-10-09 19:58:46',NULL,1,'resident',1,NULL,NULL,'Иванов Иван Иванович','1','own','denied','web','denied','Доступ приостановлен (снята галочка «доступ»).',NULL,NULL,'cli',NULL,NULL,NULL,'{\"code\":\"no_access\"}');
/*!40000 ALTER TABLE `gate_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guest_passes`
--

DROP TABLE IF EXISTS `guest_passes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `guest_passes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `code` varchar(24) NOT NULL DEFAULT '',
  `token_hash` varchar(128) NOT NULL DEFAULT '',
  `pin` varchar(12) DEFAULT NULL,
  `resident_id` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_by_type` varchar(16) NOT NULL DEFAULT 'resident',
  `guest_name` varchar(190) DEFAULT NULL,
  `guest_phone` varchar(32) DEFAULT NULL,
  `car_plate` varchar(32) DEFAULT NULL,
  `car_plate_normalized` varchar(32) DEFAULT NULL,
  `purpose` varchar(190) DEFAULT NULL,
  `max_guests` int(11) NOT NULL DEFAULT 1,
  `valid_from` datetime DEFAULT NULL,
  `valid_until` datetime DEFAULT NULL,
  `ttl_hours` int(11) NOT NULL DEFAULT 12,
  `max_uses` int(11) NOT NULL DEFAULT 0,
  `used_count` int(11) NOT NULL DEFAULT 0,
  `last_used_at` datetime DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'active',
  `revoked_at` datetime DEFAULT NULL,
  `revoked_by` bigint(20) unsigned DEFAULT NULL,
  `revoke_reason` varchar(190) DEFAULT NULL,
  `ip_created` varchar(45) DEFAULT NULL,
  `ip_last_used` varchar(45) DEFAULT NULL,
  `notify_on_use` tinyint(1) NOT NULL DEFAULT 0,
  `meta` longtext DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `guest_passes_uuid_unique` (`uuid`),
  UNIQUE KEY `guest_passes_code_unique` (`code`),
  UNIQUE KEY `guest_passes_token_hash_unique` (`token_hash`),
  KEY `guest_passes_resident_id_status_index` (`resident_id`,`status`),
  KEY `guest_passes_status_valid_until_index` (`status`,`valid_until`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guest_passes`
--

LOCK TABLES `guest_passes` WRITE;
/*!40000 ALTER TABLE `guest_passes` DISABLE KEYS */;
INSERT INTO `guest_passes` VALUES
(1,'2a521d10-a461-40b4-87a4-963b0825a9be','5F7J-M5GJ','hash:sha256:fa6866ce547067a31f36f4a000615b15f676bde081ac21e1649f3835f571bd90','811206',7,NULL,'resident','Курьер Яндекс',NULL,NULL,NULL,'Клининг',1,'2026-10-09 11:58:38','2026-10-09 23:58:38',12,0,3,'2026-10-09 12:58:38','active',NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-10-09 11:58:38','2026-10-09 11:58:38'),
(2,'e9535f50-cd03-472c-a27b-ee7252071afc','EU7P-RMFC','hash:sha256:01d6ea7824ad340ccc75111fe160cd7712c5e628d101b10aab77c12f9f9e862b','103510',6,NULL,'resident','Гость',NULL,NULL,NULL,'Ремонт',1,'2026-10-09 16:58:38','2026-10-10 04:58:38',12,0,1,'2026-10-09 17:58:38','active',NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-10-09 16:58:38','2026-10-09 16:58:38'),
(3,'076bcc8f-a092-4f1d-9b9f-88ab603c5953','YKL5-RZEY','hash:sha256:0130ad9f597e5c13577b151a104900b0587d286f30b94a4e17c64c9215740173','313732',2,NULL,'resident','Доставка',NULL,NULL,NULL,'Ремонт',1,'2026-10-09 18:58:38','2026-10-10 06:58:38',12,0,1,'2026-10-09 19:58:38','active',NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-10-09 18:58:38','2026-10-09 18:58:38'),
(4,'79ed3357-529c-4d7d-8dde-5d0377bb93da','Z2Y4-9SK5','hash:sha256:014ac69332d8a1c1acf0a053e8b93d9aabfc8370480641903e36f293d3d82541','749237',6,NULL,'resident','Мастер по ремонту',NULL,NULL,NULL,'Родственники',1,'2026-10-09 16:58:38','2026-10-10 04:58:38',12,0,3,'2026-10-09 17:58:38','active',NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-10-09 16:58:38','2026-10-09 16:58:38'),
(5,'c5986c6a-2586-4634-8c99-a51044dde76b','5NXW-MWHG','hash:sha256:420508776c7845dc9b53643f84eadee6f8497fd683fe263d065db3e2e5c79003','964503',4,NULL,'resident','Курьер Яндекс',NULL,NULL,NULL,'Курьер',1,'2026-10-09 00:58:38','2026-10-09 12:58:38',12,0,3,'2026-10-09 01:58:38','expired',NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-10-09 00:58:38','2026-10-09 00:58:38'),
(6,'dea55ce1-116d-4926-88d1-4275485e443a','G5DG-WWJ3','hash:sha256:8b5ff408bd27d1b6d755f29d3c4978794f65e48a3749b9de4305c5c2b99dc311','959885',7,NULL,'resident','Гость',NULL,NULL,NULL,'Гости',1,'2026-10-09 01:58:38','2026-10-09 13:58:38',12,0,2,'2026-10-09 02:58:38','expired',NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-10-09 01:58:38','2026-10-09 01:58:38'),
(7,'3b511ea2-211d-4fe4-861f-a0fce4bc7fbb','8AYG-6MMX','hash:sha256:3b77c18349fc7a702e2f54bab7c4e31ac1d73a56f78137a9ae6c74c3af1ea590','691191',1,1,'resident','Курьер',NULL,NULL,NULL,NULL,1,'2026-10-09 19:58:46','2026-10-10 07:58:46',12,0,1,'2026-10-09 19:58:46','revoked','2026-10-09 19:58:46',NULL,'smoke',NULL,NULL,0,NULL,'2026-10-09 19:58:46','2026-10-09 19:58:46');
/*!40000 ALTER TABLE `guest_passes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `import_jobs`
--

DROP TABLE IF EXISTS `import_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `import_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `kind` varchar(24) NOT NULL DEFAULT 'residents',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `format` varchar(12) NOT NULL DEFAULT 'csv',
  `mode` varchar(16) NOT NULL DEFAULT 'upsert',
  `rows_total` int(11) NOT NULL DEFAULT 0,
  `rows_imported` int(11) NOT NULL DEFAULT 0,
  `rows_skipped` int(11) NOT NULL DEFAULT 0,
  `rows_failed` int(11) NOT NULL DEFAULT 0,
  `errors` longtext DEFAULT NULL,
  `mapping` longtext DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'running',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `finished_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `import_jobs_uuid_unique` (`uuid`),
  KEY `import_jobs_kind_started_at_index` (`kind`,`started_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `import_jobs`
--

LOCK TABLES `import_jobs` WRITE;
/*!40000 ALTER TABLE `import_jobs` DISABLE KEYS */;
INSERT INTO `import_jobs` VALUES
(1,'20d7ff20-2815-4cd7-9a52-6c34f44e3e93','residents','upload','csv','dry-run',24,24,0,0,'[]',NULL,'done',NULL,'2026-10-09 19:58:46','2026-10-09 19:58:46');
/*!40000 ALTER TABLE `import_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `number` varchar(48) NOT NULL DEFAULT '',
  `charge_id` bigint(20) unsigned DEFAULT NULL,
  `resident_id` bigint(20) unsigned NOT NULL,
  `parent_invoice_id` bigint(20) unsigned DEFAULT NULL,
  `kind` varchar(16) NOT NULL DEFAULT 'regular',
  `amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `balance` decimal(14,2) NOT NULL DEFAULT 0.00,
  `period_start` date DEFAULT NULL,
  `period_end` date DEFAULT NULL,
  `period_label` varchar(64) NOT NULL DEFAULT '',
  `due_date` date DEFAULT NULL,
  `issued_date` date DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'pending',
  `pay_link` varchar(512) DEFAULT NULL,
  `note` longtext DEFAULT NULL,
  `recalc_reason` varchar(255) DEFAULT NULL,
  `issued_at` datetime DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `voided_at` datetime DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoices_uuid_unique` (`uuid`),
  KEY `invoices_resident_id_status_index` (`resident_id`,`status`),
  KEY `invoices_charge_id_index` (`charge_id`),
  KEY `invoices_status_due_date_index` (`status`,`due_date`),
  KEY `invoices_period_start_index` (`period_start`),
  CONSTRAINT `invoices_resident_id_fk` FOREIGN KEY (`resident_id`) REFERENCES `residents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES
(1,'31940ccb-1899-4492-8c70-b9770800341b','СЧ-2026-00001',1,1,NULL,'regular',750.00,750.00,0.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','paid','https://pay.example.com/barrier?apt=1&amount=750.00',NULL,NULL,'2026-09-30 00:00:00','2026-10-02 00:00:00',NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:58:38'),
(2,'bebbf2ac-1ca4-4d29-aff0-eb1b68970a5f','СЧ-2026-00002',1,2,NULL,'regular',750.00,750.00,0.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','paid','https://pay.example.com/barrier?apt=2&amount=750.00',NULL,NULL,'2026-09-30 00:00:00','2026-10-23 00:00:00',NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:58:38'),
(3,'cf39b0eb-d62b-4e93-ad9f-56f924bdb306','СЧ-2026-00003',1,3,NULL,'regular',750.00,375.00,375.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','partial','https://pay.example.com/barrier?apt=3&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:58:38'),
(4,'c5690323-37c6-41dc-9512-d91404808483','СЧ-2026-00004',1,5,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','pending','https://pay.example.com/barrier?apt=5&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:58:38'),
(5,'772e7c45-efed-4937-9297-26796e44298e','СЧ-2026-00005',1,6,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','pending','https://pay.example.com/barrier?apt=6&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:58:38'),
(6,'05c1ae5f-9080-416c-83a3-3f5c91f034ad','СЧ-2026-00006',1,7,NULL,'regular',750.00,750.00,0.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','paid','https://pay.example.com/barrier?apt=7&amount=750.00',NULL,NULL,'2026-09-30 00:00:00','2026-10-02 00:00:00',NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:58:38'),
(7,'426553d2-9c5a-4fd3-8858-9bf01c09ea87','СЧ-2026-00007',1,9,NULL,'regular',750.00,750.00,0.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','paid','https://pay.example.com/barrier?apt=9&amount=750.00',NULL,NULL,'2026-09-30 00:00:00','2026-10-03 00:00:00',NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:58:38'),
(8,'673b62bd-21c1-4fdd-9037-566168f0a3a8','СЧ-2026-00008',1,10,NULL,'regular',750.00,375.00,375.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','partial','https://pay.example.com/barrier?apt=10&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:58:38'),
(9,'04c8088d-1a50-491d-a8d5-106cb1f132c1','СЧ-2026-00009',1,11,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','pending','https://pay.example.com/barrier?apt=11&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:58:38'),
(10,'a6f1a803-ddcc-4edd-8459-0d15fb9a490a','СЧ-2026-00010',1,12,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','pending','https://pay.example.com/barrier?apt=12&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:58:38'),
(11,'db3611bf-ec83-4625-a0a4-57b9a9f4fbe8','СЧ-2026-00011',1,13,NULL,'regular',750.00,750.00,0.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','paid','https://pay.example.com/barrier?apt=13&amount=750.00',NULL,NULL,'2026-09-30 00:00:00','2026-10-18 00:00:00',NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:58:38'),
(12,'b31fc326-777e-45d3-a08d-5ce3dd825b20','СЧ-2026-00012',1,14,NULL,'regular',750.00,750.00,0.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','paid','https://pay.example.com/barrier?apt=14&amount=750.00',NULL,NULL,'2026-09-30 00:00:00','2026-10-17 00:00:00',NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:58:38'),
(13,'9975d268-d257-4acb-92d4-63473bd75cf8','СЧ-2026-00013',1,15,NULL,'regular',750.00,375.00,375.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','partial','https://pay.example.com/barrier?apt=15&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:58:38'),
(14,'3b6fce37-fc66-4bab-9d7c-0e5a14276c43','СЧ-2026-00014',1,16,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','pending','https://pay.example.com/barrier?apt=16&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:58:38'),
(15,'73011aee-0589-4c17-adc0-7346a936ab17','СЧ-2026-00015',1,18,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','pending','https://pay.example.com/barrier?apt=18&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:58:38'),
(16,'677a4ba5-0c5e-4947-986c-fcbcd47d7935','СЧ-2026-00016',1,20,NULL,'regular',750.00,750.00,0.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','paid','https://pay.example.com/barrier?apt=20&amount=750.00',NULL,NULL,'2026-09-30 00:00:00','2026-10-20 00:00:00',NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:58:38'),
(17,'c3472372-d7ca-406f-9d4d-e7187d2c081a','СЧ-2026-00017',1,21,NULL,'regular',750.00,750.00,0.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','paid','https://pay.example.com/barrier?apt=21&amount=750.00',NULL,NULL,'2026-09-30 00:00:00','2026-10-07 00:00:00',NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:58:38'),
(18,'25b51fa5-51c4-4dee-bc56-7b8655d885a8','СЧ-2026-00018',1,22,NULL,'regular',750.00,375.00,375.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','partial','https://pay.example.com/barrier?apt=22&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:58:38'),
(19,'a5b6feb7-6833-4f91-be4a-2a0b82d08358','СЧ-2026-00019',1,23,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','pending','https://pay.example.com/barrier?apt=23&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:58:38'),
(20,'8d4d93d0-8206-4e06-8076-419514233783','СЧ-2026-00020',1,24,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','pending','https://pay.example.com/barrier?apt=24&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:58:38'),
(21,'784473b6-0e00-442c-b4e2-fcf0168c8885','СЧ-2026-90001-Д',1,1,1,'adjustment',150.00,0.00,150.00,NULL,NULL,'Сентябрь 2026','2026-10-09','2026-10-09','pending',NULL,'Перерасчёт: увеличение стоимости ТО привода','Перерасчёт: сумма 15 000 → 15 150','2026-10-09 19:58:38',NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(22,'b2835293-d15f-4387-b20a-410430e30ab4','СЧ-2026-90002-С',1,2,2,'credit',-100.00,0.00,-100.00,NULL,NULL,'Сентябрь 2026','2026-10-09','2026-10-09','pending',NULL,'Сторно: отсутствие в период обслуживания',NULL,'2026-10-09 19:58:38',NULL,NULL,NULL,'2026-10-09 19:58:38','2026-10-09 19:58:38'),
(23,'4a49e090-1454-4994-bb60-e8f075e7e336','INV-2026-00001',2,1,NULL,'regular',750.00,750.00,0.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','paid',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 00:00:00',NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(24,'8ed7b372-1ba1-4a7e-988f-fdcbe1da951a','INV-2026-00002',2,2,NULL,'regular',750.00,750.00,0.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','paid',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 00:00:00',NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(25,'160ecfa6-e875-4099-afb1-5976e460f20d','INV-2026-00003',2,3,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(26,'e046fd6d-96a1-4d3f-8816-b9228c6963df','INV-2026-00004',2,5,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(27,'4d70cc05-1eb6-45f3-8722-e417bc9d9aa1','INV-2026-00005',2,6,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(28,'24261ee5-3706-4179-9ec9-33be54379621','INV-2026-00006',2,7,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(29,'27a23d29-51bc-4b1d-9e65-7e0989d2c141','INV-2026-00007',2,9,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(30,'77432119-1298-4aef-8bc3-0618d36fc86f','INV-2026-00008',2,10,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(31,'07789206-a569-4623-9da8-99a8ed1936c6','INV-2026-00009',2,11,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(32,'642a27e9-41d6-4d2b-b31c-391d8f2bc4af','INV-2026-00010',2,12,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(33,'2e40294f-a3aa-4e02-af85-91a7a2964f40','INV-2026-00011',2,13,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(34,'0349f1a8-2995-41fc-acdb-d500885e2d98','INV-2026-00012',2,14,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(35,'02a3fd99-d1fc-4a39-87ea-9a3a3ca4bfb2','INV-2026-00013',2,15,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(36,'07b34f8c-9129-4f4f-be34-665dc4734a51','INV-2026-00014',2,16,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(37,'b67f7ec8-881c-43a6-ac67-81ef46d62541','INV-2026-00015',2,18,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(38,'7e97af68-ec46-4f0a-a449-98b2de5c8815','INV-2026-00016',2,20,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(39,'8a6d41ae-d69c-4e5e-941c-7e5e6a49fab1','INV-2026-00017',2,21,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(40,'0d4b0d60-81e6-4acc-b78e-d82cfd6a35d4','INV-2026-00018',2,22,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(41,'a519c403-142f-4880-9da6-0d4ab3f94012','INV-2026-00019',2,23,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(42,'d6d0c0fc-a234-4065-878a-b657a45c7f16','INV-2026-00020',2,24,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(43,'66577cd6-f946-499c-8787-a553f9f57c62','INV-2026-00021-Д',2,1,23,'adjustment',68.19,0.00,68.19,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(44,'ba1d7ee4-b690-4fa4-b071-7c89401a5541','INV-2026-00022-Д',2,2,24,'adjustment',68.19,0.00,68.19,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(45,'d229d2ae-d79f-41c6-8839-4bdd40311da1','INV-2026-00023-Д',2,3,25,'adjustment',68.19,0.00,68.19,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(46,'75dc256b-2be6-4d72-8e31-4f312a5181d7','INV-2026-00024-Д',2,5,26,'adjustment',68.19,0.00,68.19,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(47,'a5ceae84-635e-4cb1-834a-3770fb12adf2','INV-2026-00025-Д',2,6,27,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(48,'aa559f46-e093-48f5-af14-e3d63602e2ac','INV-2026-00026-Д',2,7,28,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(49,'bd68c1d9-b58c-4cc5-b98e-b81704d7fb2c','INV-2026-00027-Д',2,9,29,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(50,'8bbcff17-9114-4309-b915-dc79c2bb6da3','INV-2026-00028-Д',2,10,30,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(51,'895dc556-562f-4d5a-8707-e09e906d6add','INV-2026-00029-Д',2,11,31,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(52,'6db6a13f-743f-487f-943e-7963e20cd994','INV-2026-00030-Д',2,12,32,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(53,'888d9a19-bc66-4099-a49e-a249131b957b','INV-2026-00031-Д',2,13,33,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(54,'be962883-c671-41cf-8814-f6a63f298324','INV-2026-00032-Д',2,14,34,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(55,'bc433fd8-703a-400d-9ce8-01db51174529','INV-2026-00033-Д',2,15,35,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(56,'a68e0e52-d457-4084-a536-60360c8a3439','INV-2026-00034-Д',2,16,36,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(57,'40996a31-06e5-4a84-aec2-7138b4a196a2','INV-2026-00035-Д',2,18,37,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(58,'f5b27dba-69c8-4a7d-a1fd-8cfe92c61c31','INV-2026-00036-Д',2,20,38,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(59,'b811955c-9188-4de4-a4b6-7f630eb378fa','INV-2026-00037-Д',2,21,39,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(60,'95217cc9-f470-47fd-8e82-cb5e6de2acc2','INV-2026-00038-Д',2,22,40,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(61,'b1242137-fd18-47e6-868d-110d2f489fb9','INV-2026-00039-Д',2,23,41,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(62,'2be4cb42-6cfe-41e6-88be-367debf3ce48','INV-2026-00040-Д',2,24,42,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(63,'f76a11f2-a4d0-470c-b6ef-11bf00be096d','INV-2026-00041',2,8,NULL,'regular',818.18,0.00,818.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(64,'57d73992-47c9-40f5-aa23-710ca5407976','INV-2026-00042',2,19,NULL,'regular',818.18,0.00,818.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:58:40',NULL,NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40');
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_attempts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(190) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(512) DEFAULT NULL,
  `successful` tinyint(1) NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `reason` varchar(64) DEFAULT NULL,
  `method` varchar(16) NOT NULL DEFAULT 'password',
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `login_attempts_ip_created_at_index` (`ip`,`created_at`),
  KEY `login_attempts_identifier_created_at_index` (`identifier`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--

LOCK TABLES `login_attempts` WRITE;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(190) NOT NULL DEFAULT '',
  `batch` int(11) NOT NULL DEFAULT 0,
  `checksum` varchar(64) DEFAULT NULL,
  `duration_ms` int(11) DEFAULT NULL,
  `executed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `migrations_migration_unique` (`migration`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'2026_01_01_000100_create_core_tables.php',1,'0d4480174cb41027f47e659dfa94b3f3b28ce8b360b8fe050ffa2eb0310ea5cd',6,'2026-10-09 19:58:38'),
(2,'2026_01_01_000200_create_residents_tables.php',1,'efc3f0db2311618f169f894271425521046f451ca0b33563a2e521c22148fd8e',6,'2026-10-09 19:58:38'),
(3,'2026_01_01_000300_create_billing_tables.php',1,'7ba60ffa9c016cfd94f930b78a1f45de15c0773b2763c035399387f3499bcaf4',5,'2026-10-09 19:58:38'),
(4,'2026_01_01_000400_create_gate_tables.php',1,'a19e5b98bf79ec7567acfa446c52894cb00c1357405a84cf9e03666d98c3906d',3,'2026-10-09 19:58:38'),
(5,'2026_01_01_000500_create_messaging_tables.php',1,'15f0152efb8f32af6bc5566e05eb336400c65dbe95300953d52dfd3fc54b8a7f',6,'2026-10-09 19:58:38');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_batches`
--

DROP TABLE IF EXISTS `notification_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_batches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `name` varchar(190) NOT NULL DEFAULT '',
  `template` varchar(64) NOT NULL DEFAULT 'custom',
  `subject` varchar(255) DEFAULT NULL,
  `message` longtext DEFAULT NULL,
  `pay_link` longtext DEFAULT NULL,
  `charge_id` bigint(20) unsigned DEFAULT NULL,
  `channels` longtext DEFAULT NULL,
  `audience` longtext DEFAULT NULL,
  `recipients` int(11) NOT NULL DEFAULT 0,
  `sent` int(11) NOT NULL DEFAULT 0,
  `failed` int(11) NOT NULL DEFAULT 0,
  `skipped` int(11) NOT NULL DEFAULT 0,
  `status` varchar(16) NOT NULL DEFAULT 'queued',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `finished_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `notification_batches_uuid_unique` (`uuid`),
  KEY `notification_batches_status_index` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_batches`
--

LOCK TABLES `notification_batches` WRITE;
/*!40000 ALTER TABLE `notification_batches` DISABLE KEYS */;
INSERT INTO `notification_batches` VALUES
(1,'e66c7256-18b9-4439-b1ac-9f57c348b1eb','Рассылка по начислению CHG-2026-0001','payment_new',NULL,NULL,NULL,2,'[\"log\"]',NULL,38,38,0,0,'done',NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40','2026-10-09 19:58:46');
/*!40000 ALTER TABLE `notification_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `outbox`
--

DROP TABLE IF EXISTS `outbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `outbox` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `batch_id` bigint(20) unsigned DEFAULT NULL,
  `channel` varchar(24) NOT NULL DEFAULT 'log',
  `resident_id` bigint(20) unsigned DEFAULT NULL,
  `recipient` varchar(255) NOT NULL DEFAULT '',
  `subject` varchar(255) DEFAULT NULL,
  `body` longtext DEFAULT NULL,
  `template` varchar(64) DEFAULT NULL,
  `context` longtext DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'pending',
  `attempts` int(11) NOT NULL DEFAULT 0,
  `max_attempts` int(11) NOT NULL DEFAULT 5,
  `last_error` longtext DEFAULT NULL,
  `provider_id` varchar(128) DEFAULT NULL,
  `scheduled_at` datetime DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `outbox_uuid_unique` (`uuid`),
  KEY `outbox_status_scheduled_at_index` (`status`,`scheduled_at`),
  KEY `outbox_batch_id_index` (`batch_id`),
  KEY `outbox_resident_id_index` (`resident_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `outbox`
--

LOCK TABLES `outbox` WRITE;
/*!40000 ALTER TABLE `outbox` DISABLE KEYS */;
INSERT INTO `outbox` VALUES
(1,'b7665c36-cb23-4313-a223-90c10db1978a',1,'log',23,'Zaharov.s23@example.com','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Иванов И. И.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 1.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Иванов И. И.\",\"full_name\":\"Иванов Иван Иванович\",\"apartment\":\"1\",\"building\":\"1\",\"address\":\"корп. 1, кв. 1\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00001\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-218,19 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:8dfa07ddf049','2026-10-09 19:58:40','2026-10-09 19:58:40','2026-10-09 19:58:40'),
(2,'00c4779f-83c7-4245-8efe-12ccf39c3f5b',1,'log',43,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Иванов И. И.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,19 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 1.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Иванов И. И.\",\"full_name\":\"Иванов Иван Иванович\",\"apartment\":\"1\",\"building\":\"1\",\"address\":\"корп. 1, кв. 1\",\"amount\":\"68,19 ₽\",\"amount_raw\":68.19,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00021-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-218,19 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:5b04b4908014','2026-10-09 19:58:40','2026-10-09 19:58:40','2026-10-09 19:58:40'),
(3,'874b4ccf-1130-409e-95e5-e575d7c65d3b',1,'log',24,'Zayceva.e24@example.com','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Петрова М. П.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 2.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Петрова М. П.\",\"full_name\":\"Петрова Мария Петрович\",\"apartment\":\"2\",\"building\":\"1\",\"address\":\"корп. 1, кв. 2\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00002\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"31,81 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:25f4ebb7ad63','2026-10-09 19:58:40','2026-10-09 19:58:40','2026-10-09 19:58:40'),
(4,'eec0eeea-cb27-4fad-8ff2-b5a2d6094e80',1,'log',44,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Петрова М. П.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,19 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 2.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Петрова М. П.\",\"full_name\":\"Петрова Мария Петрович\",\"apartment\":\"2\",\"building\":\"1\",\"address\":\"корп. 1, кв. 2\",\"amount\":\"68,19 ₽\",\"amount_raw\":68.19,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00022-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"31,81 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:c127ecde00e9','2026-10-09 19:58:40','2026-10-09 19:58:41','2026-10-09 19:58:40'),
(5,'0891260e-a2b1-4d05-82bd-dbd02c18bb4a',1,'log',25,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Сидоров А. С.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 3.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Сидоров А. С.\",\"full_name\":\"Сидоров Алексей Сергеевич\",\"apartment\":\"3\",\"building\":\"1\",\"address\":\"корп. 1, кв. 3\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00003\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 193,19 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:bf161d6e40f8','2026-10-09 19:58:40','2026-10-09 19:58:41','2026-10-09 19:58:40'),
(6,'e3d7b805-3bac-4da2-828a-3d8f6cbc2eaf',1,'log',45,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Сидоров А. С.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,19 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 3.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Сидоров А. С.\",\"full_name\":\"Сидоров Алексей Сергеевич\",\"apartment\":\"3\",\"building\":\"1\",\"address\":\"корп. 1, кв. 3\",\"amount\":\"68,19 ₽\",\"amount_raw\":68.19,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00023-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 193,19 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:72a8f276d4b1','2026-10-09 19:58:40','2026-10-09 19:58:41','2026-10-09 19:58:40'),
(7,'084fa3cb-3297-4fa8-944a-e363c5442333',1,'log',26,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Смирнов Д. И.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 5.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Смирнов Д. И.\",\"full_name\":\"Смирнов Дмитрий Ивановна\",\"apartment\":\"5\",\"building\":\"1\",\"address\":\"корп. 1, кв. 5\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00004\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,19 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:4b11da693bad','2026-10-09 19:58:40','2026-10-09 19:58:41','2026-10-09 19:58:40'),
(8,'45cffe51-a0cd-4cdf-ae72-cd89f2b468e3',1,'log',46,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Смирнов Д. И.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,19 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 5.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Смирнов Д. И.\",\"full_name\":\"Смирнов Дмитрий Ивановна\",\"apartment\":\"5\",\"building\":\"1\",\"address\":\"корп. 1, кв. 5\",\"amount\":\"68,19 ₽\",\"amount_raw\":68.19,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00024-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,19 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:80862af90713','2026-10-09 19:58:40','2026-10-09 19:58:41','2026-10-09 19:58:40'),
(9,'5894bf13-097f-4281-908e-6abd2c236ab0',1,'log',27,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Васильева А. П.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 6.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Васильева А. П.\",\"full_name\":\"Васильева Анна Петровна\",\"apartment\":\"6\",\"building\":\"1\",\"address\":\"корп. 1, кв. 6\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00005\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:9825be0da173','2026-10-09 19:58:40','2026-10-09 19:58:41','2026-10-09 19:58:40'),
(10,'11fc8c92-65ef-4f57-82e9-1bdb972c92d5',1,'log',47,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Васильева А. П.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 6.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Васильева А. П.\",\"full_name\":\"Васильева Анна Петровна\",\"apartment\":\"6\",\"building\":\"1\",\"address\":\"корп. 1, кв. 6\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00025-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:84153ef460a1','2026-10-09 19:58:40','2026-10-09 19:58:41','2026-10-09 19:58:40'),
(11,'47efcb66-0ee7-443c-827f-dce763506d6f',1,'log',28,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Соколов С. С.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 7.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Соколов С. С.\",\"full_name\":\"Соколов Сергей Сергеевна\",\"apartment\":\"7\",\"building\":\"1\",\"address\":\"корп. 1, кв. 7\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00006\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:02ef00e3a5cf','2026-10-09 19:58:40','2026-10-09 19:58:42','2026-10-09 19:58:40'),
(12,'49ddddec-8252-45db-b551-c62fa0060150',1,'log',48,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Соколов С. С.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 7.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Соколов С. С.\",\"full_name\":\"Соколов Сергей Сергеевна\",\"apartment\":\"7\",\"building\":\"1\",\"address\":\"корп. 1, кв. 7\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00026-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:85e4ea26e8e5','2026-10-09 19:58:40','2026-10-09 19:58:42','2026-10-09 19:58:40'),
(13,'473b983f-2628-40fc-9335-ea8d3fa78337',1,'log',63,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Михайлова Е. Н.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 818,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 8.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Михайлова Е. Н.\",\"full_name\":\"Михайлова Елена Николаевич\",\"apartment\":\"8\",\"building\":\"1\",\"address\":\"корп. 1, кв. 8\",\"amount\":\"818,18 ₽\",\"amount_raw\":818.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00041\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:fca52b8561d4','2026-10-09 19:58:40','2026-10-09 19:58:42','2026-10-09 19:58:40'),
(14,'d79c3ca8-a60e-4976-81f4-2124279f5561',1,'log',30,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Морозова Н. П.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 10.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Морозова Н. П.\",\"full_name\":\"Морозова Наталья Петрович\",\"apartment\":\"10\",\"building\":\"1\",\"address\":\"корп. 1, кв. 10\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00008\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 193,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:1ad1f5c82b7a','2026-10-09 19:58:40','2026-10-09 19:58:42','2026-10-09 19:58:40'),
(15,'76cae2da-ee46-45d3-96a8-e7225447c824',1,'log',50,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Морозова Н. П.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 10.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Морозова Н. П.\",\"full_name\":\"Морозова Наталья Петрович\",\"apartment\":\"10\",\"building\":\"1\",\"address\":\"корп. 1, кв. 10\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00028-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 193,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:0f2eef3988c8','2026-10-09 19:58:40','2026-10-09 19:58:42','2026-10-09 19:58:40'),
(16,'a82e2775-2b9c-4743-bff2-7d94414247ed',1,'log',31,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Волков П. С.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 11.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Волков П. С.\",\"full_name\":\"Волков Павел Сергеевич\",\"apartment\":\"11\",\"building\":\"1\",\"address\":\"корп. 1, кв. 11\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00009\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:10a299184d09','2026-10-09 19:58:40','2026-10-09 19:58:42','2026-10-09 19:58:40'),
(17,'a700ad9c-f20a-49d0-a483-459ab91579a8',1,'log',51,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Волков П. С.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 11.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Волков П. С.\",\"full_name\":\"Волков Павел Сергеевич\",\"apartment\":\"11\",\"building\":\"1\",\"address\":\"корп. 1, кв. 11\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00029-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:3bf4b5f06a68','2026-10-09 19:58:40','2026-10-09 19:58:43','2026-10-09 19:58:40'),
(18,'91b3743e-24f7-46ab-934f-0af2a2cdd1f0',1,'log',32,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Алексеева Е. А.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 12.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Алексеева Е. А.\",\"full_name\":\"Алексеева Екатерина Андреевич\",\"apartment\":\"12\",\"building\":\"1\",\"address\":\"корп. 1, кв. 12\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00010\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:a7c30d8d556d','2026-10-09 19:58:40','2026-10-09 19:58:43','2026-10-09 19:58:40'),
(19,'bad5055f-2bd2-4ae4-a7cd-34d09d7030f4',1,'log',52,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Алексеева Е. А.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 12.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Алексеева Е. А.\",\"full_name\":\"Алексеева Екатерина Андреевич\",\"apartment\":\"12\",\"building\":\"1\",\"address\":\"корп. 1, кв. 12\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00030-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:5a5cf797e531','2026-10-09 19:58:40','2026-10-09 19:58:43','2026-10-09 19:58:40'),
(20,'8fae8b6b-5945-49ba-a21b-36e00a752447',1,'log',33,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Лебедев Н. И.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 13.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Лебедев Н. И.\",\"full_name\":\"Лебедев Николай Ивановна\",\"apartment\":\"13\",\"building\":\"2\",\"address\":\"корп. 2, кв. 13\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00011\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:bdd28d57a087','2026-10-09 19:58:40','2026-10-09 19:58:43','2026-10-09 19:58:40'),
(21,'ee3aa517-8c97-45b9-a2e2-a5f6d1409f8c',1,'log',53,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Лебедев Н. И.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 13.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Лебедев Н. И.\",\"full_name\":\"Лебедев Николай Ивановна\",\"apartment\":\"13\",\"building\":\"2\",\"address\":\"корп. 2, кв. 13\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00031-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:8f25933b28da','2026-10-09 19:58:40','2026-10-09 19:58:43','2026-10-09 19:58:40'),
(22,'a738569f-3b04-4a85-836a-057b4504db63',1,'log',34,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Семёнова Т. П.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 14.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Семёнова Т. П.\",\"full_name\":\"Семёнова Татьяна Петровна\",\"apartment\":\"14\",\"building\":\"2\",\"address\":\"корп. 2, кв. 14\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00012\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:824e4dde7368','2026-10-09 19:58:40','2026-10-09 19:58:43','2026-10-09 19:58:40'),
(23,'647b947a-61ca-44c9-96e7-62c8452c3865',1,'log',54,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Семёнова Т. П.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 14.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Семёнова Т. П.\",\"full_name\":\"Семёнова Татьяна Петровна\",\"apartment\":\"14\",\"building\":\"2\",\"address\":\"корп. 2, кв. 14\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00032-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:b96a1c570cb3','2026-10-09 19:58:40','2026-10-09 19:58:43','2026-10-09 19:58:40'),
(24,'47f304b9-6dc6-42da-ad77-b973918d297f',1,'log',35,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Егоров В. С.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 15.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Егоров В. С.\",\"full_name\":\"Егоров Виктор Сергеевна\",\"apartment\":\"15\",\"building\":\"2\",\"address\":\"корп. 2, кв. 15\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00013\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 193,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:69531e9e0577','2026-10-09 19:58:40','2026-10-09 19:58:44','2026-10-09 19:58:40'),
(25,'27a59654-f047-47b5-9ea2-c2e73e4089f2',1,'log',55,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Егоров В. С.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 15.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Егоров В. С.\",\"full_name\":\"Егоров Виктор Сергеевна\",\"apartment\":\"15\",\"building\":\"2\",\"address\":\"корп. 2, кв. 15\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00033-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 193,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:5d750d2dc7e6','2026-10-09 19:58:40','2026-10-09 19:58:44','2026-10-09 19:58:40'),
(26,'8e7d4097-2da8-4690-9787-8bc4f1bc5eac',1,'log',36,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Павлова Ю. Н.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 16.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Павлова Ю. Н.\",\"full_name\":\"Павлова Юлия Николаевич\",\"apartment\":\"16\",\"building\":\"2\",\"address\":\"корп. 2, кв. 16\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00014\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:71a1ffb126e3','2026-10-09 19:58:40','2026-10-09 19:58:44','2026-10-09 19:58:40'),
(27,'62af19cb-d7be-4571-8cda-930c8a875b16',1,'log',56,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Павлова Ю. Н.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 16.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Павлова Ю. Н.\",\"full_name\":\"Павлова Юлия Николаевич\",\"apartment\":\"16\",\"building\":\"2\",\"address\":\"корп. 2, кв. 16\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00034-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:74a3fe847b86','2026-10-09 19:58:40','2026-10-09 19:58:44','2026-10-09 19:58:40'),
(28,'483bf9cd-f5cd-4585-b615-b27514a1143b',1,'log',64,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Николаев А. С.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 818,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 19.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Николаев А. С.\",\"full_name\":\"Николаев Алексей Сергеевич\",\"apartment\":\"19\",\"building\":\"2\",\"address\":\"корп. 2, кв. 19\",\"amount\":\"818,18 ₽\",\"amount_raw\":818.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00042\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:d35b52a4415d','2026-10-09 19:58:40','2026-10-09 19:58:44','2026-10-09 19:58:40'),
(29,'a61a3b58-e50b-4528-91e3-f1a31cb05995',1,'log',38,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Орлова О. А.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 20.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Орлова О. А.\",\"full_name\":\"Орлова Ольга Андреевич\",\"apartment\":\"20\",\"building\":\"2\",\"address\":\"корп. 2, кв. 20\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00016\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:37e531dab379','2026-10-09 19:58:40','2026-10-09 19:58:44','2026-10-09 19:58:40'),
(30,'c9203a53-4aa5-4bac-9732-7012e075113c',1,'log',58,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Орлова О. А.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 20.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Орлова О. А.\",\"full_name\":\"Орлова Ольга Андреевич\",\"apartment\":\"20\",\"building\":\"2\",\"address\":\"корп. 2, кв. 20\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00036-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:533e4df2ed39','2026-10-09 19:58:40','2026-10-09 19:58:45','2026-10-09 19:58:40'),
(31,'f689529b-db12-46ed-b764-8f852328195d',1,'log',39,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Андреев Д. И.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 21.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Андреев Д. И.\",\"full_name\":\"Андреев Дмитрий Ивановна\",\"apartment\":\"21\",\"building\":\"2\",\"address\":\"корп. 2, кв. 21\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00017\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:5dddf6e108ab','2026-10-09 19:58:40','2026-10-09 19:58:45','2026-10-09 19:58:40'),
(32,'448cac1c-b8f6-4c9c-9f32-0160a27a8e03',1,'log',59,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Андреев Д. И.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 21.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Андреев Д. И.\",\"full_name\":\"Андреев Дмитрий Ивановна\",\"apartment\":\"21\",\"building\":\"2\",\"address\":\"корп. 2, кв. 21\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00037-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:782ef9d87f6d','2026-10-09 19:58:40','2026-10-09 19:58:45','2026-10-09 19:58:40'),
(33,'d76d5bfc-86b6-472c-9636-714448e32f94',1,'log',40,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Макарова А. П.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 22.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Макарова А. П.\",\"full_name\":\"Макарова Анна Петровна\",\"apartment\":\"22\",\"building\":\"2\",\"address\":\"корп. 2, кв. 22\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00018\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 193,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:411afd037549','2026-10-09 19:58:40','2026-10-09 19:58:45','2026-10-09 19:58:40'),
(34,'f0819576-b713-4112-a481-39fed8d9c452',1,'log',60,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Макарова А. П.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 22.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Макарова А. П.\",\"full_name\":\"Макарова Анна Петровна\",\"apartment\":\"22\",\"building\":\"2\",\"address\":\"корп. 2, кв. 22\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00038-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 193,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:b7511f06ee6c','2026-10-09 19:58:40','2026-10-09 19:58:45','2026-10-09 19:58:40'),
(35,'7c8dc979-af48-4f3a-8c5b-7baf71a5e63c',1,'log',41,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Захаров С. С.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 23.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Захаров С. С.\",\"full_name\":\"Захаров Сергей Сергеевна\",\"apartment\":\"23\",\"building\":\"2\",\"address\":\"корп. 2, кв. 23\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00019\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:3f3adff7b68d','2026-10-09 19:58:40','2026-10-09 19:58:45','2026-10-09 19:58:40'),
(36,'8c789c21-2e6d-4830-b517-b3d033087dad',1,'log',61,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Захаров С. С.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 23.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Захаров С. С.\",\"full_name\":\"Захаров Сергей Сергеевна\",\"apartment\":\"23\",\"building\":\"2\",\"address\":\"корп. 2, кв. 23\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00039-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:8a9724f55975','2026-10-09 19:58:40','2026-10-09 19:58:45','2026-10-09 19:58:40'),
(37,'def5da4f-c936-4d1b-baae-904d023674ef',1,'log',42,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Зайцева Е. Н.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 24.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Зайцева Е. Н.\",\"full_name\":\"Зайцева Елена Николаевич\",\"apartment\":\"24\",\"building\":\"2\",\"address\":\"корп. 2, кв. 24\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00020\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:444f931672a6','2026-10-09 19:58:40','2026-10-09 19:58:46','2026-10-09 19:58:40'),
(38,'2af6e704-9cb0-415d-994a-e28839054360',1,'log',62,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Зайцева Е. Н.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 24.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Зайцева Е. Н.\",\"full_name\":\"Зайцева Елена Николаевич\",\"apartment\":\"24\",\"building\":\"2\",\"address\":\"корп. 2, кв. 24\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00040-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:e59ac4aa0eb9','2026-10-09 19:58:40','2026-10-09 19:58:46','2026-10-09 19:58:40');
/*!40000 ALTER TABLE `outbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `resident_id` bigint(20) unsigned NOT NULL,
  `invoice_id` bigint(20) unsigned DEFAULT NULL,
  `charge_id` bigint(20) unsigned DEFAULT NULL,
  `amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `paid_at` date DEFAULT NULL,
  `method` varchar(24) NOT NULL DEFAULT 'transfer',
  `reference` varchar(120) DEFAULT NULL,
  `payer_name` varchar(190) DEFAULT NULL,
  `note` longtext DEFAULT NULL,
  `external_id` varchar(96) DEFAULT NULL,
  `is_confirmed` tinyint(1) NOT NULL DEFAULT 1,
  `recorded_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payments_uuid_unique` (`uuid`),
  KEY `payments_resident_id_paid_at_index` (`resident_id`,`paid_at`),
  KEY `payments_invoice_id_index` (`invoice_id`),
  KEY `payments_paid_at_index` (`paid_at`),
  CONSTRAINT `payments_resident_id_fk` FOREIGN KEY (`resident_id`) REFERENCES `residents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES
(1,'74d1a6b3-2b5d-4d99-9daa-8591d8a1a109',1,1,1,750.00,'2026-10-02','transfer','ПЛ-282833','Иванов Иван Иванович','Демо-оплата',NULL,1,NULL,'2026-10-02 00:00:00','2026-10-02 00:00:00'),
(2,'79169b57-1bef-42e7-afa5-8f74df52c11f',2,2,1,750.00,'2026-10-23','card','ПЛ-E4C3FE','Петрова Мария Петрович','Демо-оплата',NULL,1,NULL,'2026-10-23 00:00:00','2026-10-23 00:00:00'),
(3,'8c369663-b573-402c-9efc-3a22b7851591',3,3,1,375.00,'2026-10-14','sbp','ПЛ-5D58E0','Сидоров Алексей Сергеевич','Демо-оплата',NULL,1,NULL,'2026-10-14 00:00:00','2026-10-14 00:00:00'),
(4,'0523200f-6f7f-455a-b7e5-7acbfd4fe94a',7,6,1,750.00,'2026-10-02','transfer','ПЛ-EAEFC5','Соколов Сергей Сергеевна','Демо-оплата',NULL,1,NULL,'2026-10-02 00:00:00','2026-10-02 00:00:00'),
(5,'2f1c2817-9f42-485c-8303-0d98aacf2a22',9,7,1,750.00,'2026-10-03','card','ПЛ-C59AEB','Фёдоров Андрей Иванович','Демо-оплата',NULL,1,NULL,'2026-10-03 00:00:00','2026-10-03 00:00:00'),
(6,'5bb3b162-863c-4422-80d6-833023d98081',10,8,1,375.00,'2026-10-24','sbp','ПЛ-C7DE8C','Морозова Наталья Петрович','Демо-оплата',NULL,1,NULL,'2026-10-24 00:00:00','2026-10-24 00:00:00'),
(7,'36e3fbac-45ee-4078-8e71-ea90b006f179',13,11,1,750.00,'2026-10-18','transfer','ПЛ-73AB80','Лебедев Николай Ивановна','Демо-оплата',NULL,1,NULL,'2026-10-18 00:00:00','2026-10-18 00:00:00'),
(8,'d81b7292-aa8c-4cdc-bb88-f5675f2f8ccc',14,12,1,750.00,'2026-10-17','card','ПЛ-C2C289','Семёнова Татьяна Петровна','Демо-оплата',NULL,1,NULL,'2026-10-17 00:00:00','2026-10-17 00:00:00'),
(9,'4423ee50-7ab5-4519-a0a1-fd3c295cf94d',15,13,1,375.00,'2026-10-09','sbp','ПЛ-210975','Егоров Виктор Сергеевна','Демо-оплата',NULL,1,NULL,'2026-10-09 00:00:00','2026-10-09 00:00:00'),
(10,'677b419a-4036-4bad-8ed6-65eb8efc79f9',20,16,1,750.00,'2026-10-20','transfer','ПЛ-660107','Орлова Ольга Андреевич','Демо-оплата',NULL,1,NULL,'2026-10-20 00:00:00','2026-10-20 00:00:00'),
(11,'edc1e249-fe2a-460a-83cc-0dcb21cea980',21,17,1,750.00,'2026-10-07','card','ПЛ-6F399A','Андреев Дмитрий Ивановна','Демо-оплата',NULL,1,NULL,'2026-10-07 00:00:00','2026-10-07 00:00:00'),
(12,'fa61c2ac-b6a2-4d73-805e-9974a05d9b3a',22,18,1,375.00,'2026-10-02','sbp','ПЛ-545B3C','Макарова Анна Петровна','Демо-оплата',NULL,1,NULL,'2026-10-02 00:00:00','2026-10-02 00:00:00'),
(13,'d005e55e-d4d2-4ab1-8c16-b8802e3f0ee1',1,23,2,750.00,'2026-10-09','cash',NULL,NULL,NULL,NULL,1,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40'),
(14,'70a38643-fa66-4897-b643-36f9527682dd',2,24,2,750.00,'2026-10-09','transfer',NULL,NULL,NULL,NULL,1,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `residents`
--

DROP TABLE IF EXISTS `residents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `residents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `external_id` varchar(64) DEFAULT NULL,
  `last_name` varchar(120) NOT NULL DEFAULT '',
  `first_name` varchar(120) NOT NULL DEFAULT '',
  `patronymic` varchar(120) DEFAULT NULL,
  `full_name` varchar(255) NOT NULL DEFAULT '',
  `search_index` varchar(512) DEFAULT NULL,
  `apartment` varchar(24) NOT NULL DEFAULT '',
  `apartment_no` int(11) DEFAULT NULL,
  `building` varchar(24) DEFAULT NULL,
  `entrance` varchar(16) DEFAULT NULL,
  `floor` int(11) DEFAULT NULL,
  `area` decimal(10,2) NOT NULL DEFAULT 0.00,
  `persons` int(11) NOT NULL DEFAULT 1,
  `share` decimal(10,4) NOT NULL DEFAULT 1.0000,
  `role_in_home` varchar(24) NOT NULL DEFAULT 'owner',
  `phone` varchar(32) DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `access_granted` tinyint(1) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_billed` tinyint(1) NOT NULL DEFAULT 1,
  `allow_guest_pass` tinyint(1) NOT NULL DEFAULT 1,
  `notify_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `notes` longtext DEFAULT NULL,
  `tags` longtext DEFAULT NULL,
  `balance` decimal(12,2) NOT NULL DEFAULT 0.00,
  `last_payment_at` datetime DEFAULT NULL,
  `last_gate_event_at` datetime DEFAULT NULL,
  `avatar_path` varchar(255) DEFAULT NULL,
  `meta` longtext DEFAULT NULL,
  `guest_passes_issued` int(11) NOT NULL DEFAULT 0,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `archived_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `residents_uuid_unique` (`uuid`),
  KEY `residents_is_active_is_billed_index` (`is_active`,`is_billed`),
  KEY `residents_apartment_no_building_index` (`apartment_no`,`building`),
  KEY `residents_last_name_index` (`last_name`),
  KEY `residents_email_index` (`email`),
  KEY `residents_deleted_at_index` (`deleted_at`),
  KEY `residents_access_granted_index` (`access_granted`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `residents`
--

LOCK TABLES `residents` WRITE;
/*!40000 ALTER TABLE `residents` DISABLE KEYS */;
INSERT INTO `residents` VALUES
(1,'5f8b372a-d474-42b1-8add-e9ab585b538b',NULL,'Иванов','Иван','Иванович','Иванов Иван Иванович','иванов иван иванович кв 1 79077593446 ivanov.i1@example.com','1',1,'1','1',1,28.00,1,1.0000,'owner','+79077593446','Ivanov.i1@example.com',1,1,1,1,1,'Просил напоминать об оплате за 3 дня.','[\"староста\",\"актив\"]',-218.19,'2026-10-09 00:00:00','2026-10-09 19:58:46',NULL,NULL,1,NULL,NULL,'2024-04-23 19:58:38','2026-09-12 19:58:38',NULL,NULL),
(2,'3fca2288-f87c-4993-8100-77c537cda2be',NULL,'Петрова','Мария','Петрович','Петрова Мария Петрович','петрова мария петрович кв 2 79079283500 petrova.m2@example.com','2',2,'1','2',2,39.50,2,1.0000,'owner','+79079283500','Petrova.m2@example.com',1,1,1,1,1,NULL,NULL,31.81,'2026-10-09 00:00:00','2026-10-09 11:13:53',NULL,NULL,0,NULL,NULL,'2025-08-18 19:58:38','2026-10-05 19:58:38',NULL,NULL),
(3,'3faf0c1f-0054-4c5d-bb18-625f649e8e6b',NULL,'Сидоров','Алексей','Сергеевич','Сидоров Алексей Сергеевич','сидоров алексей сергеевич кв 3 79071925462 sidorov.a3@example.com','3',3,'1','3',3,51.00,3,1.0000,'owner','+79071925462','Sidorov.a3@example.com',1,1,1,1,1,NULL,NULL,-1193.19,'2026-10-14 00:00:00','2026-10-09 22:55:08',NULL,NULL,0,NULL,NULL,'2026-04-10 19:58:38','2026-09-26 19:58:38',NULL,NULL),
(4,'bf58ce11-3c70-44c0-849c-8e790d463470',NULL,'Кузнецова','Ольга','Андреевич','Кузнецова Ольга Андреевич','кузнецова ольга андреевич кв 4 79055684610 kuznecova.o4@example.com','4',4,'1','4',4,62.50,4,1.0000,'owner','+79055684610','Kuznecova.o4@example.com',1,1,0,1,1,NULL,NULL,0.00,NULL,'2026-10-07 18:24:10',NULL,NULL,0,NULL,NULL,'2025-08-17 19:58:38','2026-09-27 19:58:38',NULL,NULL),
(5,'0379b636-f96d-4d60-8d09-84f6fe583c24',NULL,'Смирнов','Дмитрий','Ивановна','Смирнов Дмитрий Ивановна','смирнов дмитрий ивановна кв 5 79052326473 smirnov.d5@example.com','5',5,'1','1',5,74.00,1,1.0000,'tenant','+79052326473','Smirnov.d5@example.com',1,1,1,1,1,NULL,NULL,-1568.19,NULL,'2026-10-07 21:08:10',NULL,NULL,0,NULL,NULL,'2026-02-03 19:58:38','2026-09-21 19:58:38',NULL,NULL),
(6,'a82f40e9-b9db-4e9b-abd4-3e5990db5fa3',NULL,'Васильева','Анна','Петровна','Васильева Анна Петровна','васильева анна петровна кв 6 79018714791 vasileva.a6@example.com','6',6,'1','2',6,85.50,2,1.0000,'owner','+79018714791','Vasileva.a6@example.com',0,1,1,1,1,NULL,NULL,-1568.18,NULL,'2026-09-26 09:32:07',NULL,NULL,0,NULL,NULL,'2025-12-19 19:58:38','2026-09-11 19:58:38',NULL,NULL),
(7,'d6dc88d3-cc0e-4c1f-a94f-cecabc58b2c8',NULL,'Соколов','Сергей','Сергеевна','Соколов Сергей Сергеевна','соколов сергей сергеевна кв 7 79048639433 sokolov.s7@example.com','7',7,'1','3',7,97.00,3,1.0000,'owner','+79048639433','Sokolov.s7@example.com',1,1,1,1,1,'Просил напоминать об оплате за 3 дня.',NULL,-818.18,'2026-10-02 00:00:00','2026-10-08 14:37:59',NULL,NULL,0,NULL,NULL,'2025-03-27 19:58:38','2026-09-15 19:58:38',NULL,NULL),
(8,'c48e62d7-4c70-4ad8-b4a6-9d011d725475',NULL,'Михайлова','Елена','Николаевич','Михайлова Елена Николаевич','михайлова елена николаевич кв 8 79094656270 mihaylova.e8@example.com','8',8,'1','4',8,28.00,4,1.0000,'owner','+79094656270','Mihaylova.e8@example.com',1,1,1,1,1,NULL,'[\"староста\",\"актив\"]',-818.18,NULL,'2026-10-01 11:58:09',NULL,NULL,0,NULL,NULL,'2025-10-07 19:58:38','2026-09-29 19:58:38',NULL,NULL),
(9,'dde07141-9854-4b95-8732-0c740b9d32b2',NULL,'Фёдоров','Андрей','Иванович','Фёдоров Андрей Иванович','фёдоров андрей иванович кв 9 79062181099 fedorov.a9@example.com','9',9,'1','1',9,39.50,1,1.0000,'owner','+79062181099','Fedorov.a9@example.com',1,1,1,1,0,NULL,NULL,-818.18,'2026-10-03 00:00:00','2026-10-07 08:46:10',NULL,NULL,0,NULL,NULL,'2026-02-13 19:58:38','2026-10-07 19:58:38',NULL,NULL),
(10,'954155dc-537f-461b-8513-b89b53cdaf15',NULL,'Морозова','Наталья','Петрович','Морозова Наталья Петрович','морозова наталья петрович кв 10 79056133849 morozova.n10@example.com','10',10,'1','2',1,51.00,2,1.0000,'tenant','+79056133849','Morozova.n10@example.com',1,1,1,1,1,NULL,NULL,-1193.18,'2026-10-24 00:00:00','2026-10-04 22:18:21',NULL,NULL,0,NULL,NULL,'2024-10-04 19:58:38','2026-09-09 19:58:38',NULL,NULL),
(11,'20b05baa-0284-46e5-ab2b-3e1dcd56fe4f',NULL,'Волков','Павел','Сергеевич','Волков Павел Сергеевич','волков павел сергеевич кв 11 79056592424 volkov.p11@example.com','11',11,'1','3',2,62.50,3,1.0000,'owner','+79056592424','Volkov.p11@example.com',1,1,1,1,1,NULL,NULL,-1568.18,NULL,'2026-10-02 22:17:47',NULL,NULL,0,NULL,NULL,'2024-12-15 19:58:38','2026-10-06 19:58:38',NULL,NULL),
(12,'356a817a-34a8-49a1-983c-e23aabc30620',NULL,'Алексеева','Екатерина','Андреевич','Алексеева Екатерина Андреевич','алексеева екатерина андреевич кв 12 79097998532 alekseeva.e12@example.com','12',12,'1','4',3,74.00,4,1.0000,'owner','+79097998532','Alekseeva.e12@example.com',1,1,1,1,1,NULL,NULL,-1568.18,NULL,'2026-10-07 12:20:53',NULL,NULL,0,NULL,NULL,'2026-04-25 19:58:38','2026-09-28 19:58:38',NULL,NULL),
(13,'f7142d09-1ef7-44ab-a031-29d519b8d078',NULL,'Лебедев','Николай','Ивановна','Лебедев Николай Ивановна','лебедев николай ивановна кв 13 79012985243 lebedev.n13@example.com','13',13,'2','1',4,85.50,1,1.0000,'owner','+79012985243','Lebedev.n13@example.com',1,1,1,1,1,'Просил напоминать об оплате за 3 дня.',NULL,-818.18,'2026-10-18 00:00:00','2026-10-09 19:11:18',NULL,NULL,0,NULL,NULL,'2025-05-02 19:58:38','2026-10-05 19:58:38',NULL,NULL),
(14,'b5f9a7f1-b302-46b7-82c4-286d63f36727',NULL,'Семёнова','Татьяна','Петровна','Семёнова Татьяна Петровна','семёнова татьяна петровна кв 14 79075649845 semenova.t14@example.com','14',14,'2','2',5,97.00,2,1.0000,'owner','+79075649845','Semenova.t14@example.com',1,1,1,1,1,NULL,NULL,-818.18,'2026-10-17 00:00:00','2026-10-09 15:54:47',NULL,NULL,0,NULL,NULL,'2026-05-20 19:58:38','2026-09-26 19:58:38',NULL,NULL),
(15,'1e26047a-f304-4457-b3b7-21d7349fbb5f',NULL,'Егоров','Виктор','Сергеевна','Егоров Виктор Сергеевна','егоров виктор сергеевна кв 15 79060573286 egorov.v15@example.com','15',15,'2','3',6,28.00,3,1.0000,'tenant','+79060573286','Egorov.v15@example.com',1,1,1,1,1,NULL,'[\"староста\",\"актив\"]',-1193.18,'2026-10-09 00:00:00','2026-10-09 15:37:33',NULL,NULL,0,NULL,NULL,'2025-07-31 19:58:38','2026-09-18 19:58:38',NULL,NULL),
(16,'becfb217-3062-443f-87a5-5329e405e794',NULL,'Павлова','Юлия','Николаевич','Павлова Юлия Николаевич','павлова юлия николаевич кв 16 79017894122 pavlova.y16@example.com','16',16,'2','4',7,39.50,4,1.0000,'owner','+79017894122','Pavlova.y16@example.com',1,1,1,1,1,NULL,NULL,-1568.18,NULL,'2026-10-07 22:37:56',NULL,NULL,0,NULL,NULL,'2025-03-30 19:58:38','2026-09-20 19:58:38',NULL,NULL),
(17,'6191e8e9-175d-4897-ab52-6712d62b6d1e',NULL,'Козлов','Иван','Иванович','Козлов Иван Иванович','козлов иван иванович кв 17 79042648978 kozlov.i17@example.com','17',17,'2','1',8,51.00,1,1.0000,'owner','+79042648978','Kozlov.i17@example.com',1,1,0,1,1,NULL,NULL,0.00,NULL,'2026-10-09 18:49:08',NULL,NULL,0,NULL,NULL,'2025-01-04 19:58:38','2026-09-28 19:58:38',NULL,NULL),
(18,'9519b7ac-5193-4c1c-aa63-d453b5861db3',NULL,'Степанова','Мария','Петрович','Степанова Мария Петрович','степанова мария петрович кв 18 79013485844 stepanova.m18@example.com','18',18,'2','2',9,62.50,2,1.0000,'owner','+79013485844','Stepanova.m18@example.com',1,1,1,1,0,NULL,NULL,-1568.18,NULL,'2026-10-06 20:41:13',NULL,NULL,0,NULL,NULL,'2026-05-19 19:58:38','2026-09-17 19:58:38',NULL,NULL),
(19,'4f7a5bf4-c411-47fa-bcdd-8ebed355400c',NULL,'Николаев','Алексей','Сергеевич','Николаев Алексей Сергеевич','николаев алексей сергеевич кв 19 79051837970 nikolaev.a19@example.com','19',19,'2','3',1,74.00,3,1.0000,'owner','+79051837970','Nikolaev.a19@example.com',1,1,1,1,1,'Просил напоминать об оплате за 3 дня.',NULL,-818.18,NULL,'2026-10-08 09:50:16',NULL,NULL,0,NULL,NULL,'2025-08-21 19:58:38','2026-09-27 19:58:38',NULL,NULL),
(20,'4f53f15b-1a2e-44ff-bb33-8b3ff7fc9620',NULL,'Орлова','Ольга','Андреевич','Орлова Ольга Андреевич','орлова ольга андреевич кв 20 79050789102 orlova.o20@example.com','20',20,'2','4',2,85.50,4,1.0000,'tenant','+79050789102','Orlova.o20@example.com',1,1,1,1,1,NULL,NULL,-818.18,'2026-10-20 00:00:00','2026-10-07 21:09:47',NULL,NULL,0,NULL,NULL,'2025-07-28 19:58:38','2026-10-02 19:58:38',NULL,NULL),
(21,'caa6f9c7-5bb3-451d-9a7f-419cafc94599',NULL,'Андреев','Дмитрий','Ивановна','Андреев Дмитрий Ивановна','андреев дмитрий ивановна кв 21 79093707173 andreev.d21@example.com','21',21,'2','1',3,97.00,1,1.0000,'owner','+79093707173','Andreev.d21@example.com',1,1,1,1,1,NULL,NULL,-818.18,'2026-10-07 00:00:00','2026-10-09 18:47:01',NULL,NULL,0,NULL,NULL,'2025-03-18 19:58:38','2026-10-05 19:58:38',NULL,NULL),
(22,'e069091d-6b5d-445d-9fae-12b05d4bb201',NULL,'Макарова','Анна','Петровна','Макарова Анна Петровна','макарова анна петровна кв 22 79063223589 makarova.a22@example.com','22',22,'2','2',4,28.00,2,1.0000,'owner','+79063223589','Makarova.a22@example.com',1,1,1,1,1,NULL,'[\"староста\",\"актив\"]',-1193.18,'2026-10-02 00:00:00','2026-10-07 08:03:23',NULL,NULL,0,NULL,NULL,'2025-06-11 19:58:38','2026-10-01 19:58:38',NULL,NULL),
(23,'053c2fad-78d7-4182-87df-c660c82f161e',NULL,'Захаров','Сергей','Сергеевна','Захаров Сергей Сергеевна','захаров сергей сергеевна кв 23 79022534178 zaharov.s23@example.com','23',23,'2','3',5,39.50,3,1.0000,'owner','+79022534178','Zaharov.s23@example.com',0,1,1,1,1,NULL,NULL,-1568.18,NULL,'2026-10-09 13:00:13',NULL,NULL,0,NULL,NULL,'2024-05-03 19:58:38','2026-09-20 19:58:38',NULL,NULL),
(24,'567360a4-021a-4d4d-8038-f969287cf0d8',NULL,'Зайцева','Елена','Николаевич','Зайцева Елена Николаевич','зайцева елена николаевич кв 24 79069693134 zayceva.e24@example.com','24',24,'2','4',6,51.00,4,1.0000,'owner','+79069693134','Zayceva.e24@example.com',1,1,1,1,1,NULL,NULL,-1568.18,NULL,'2026-10-07 07:22:32',NULL,NULL,0,NULL,NULL,'2024-04-25 19:58:38','2026-10-08 19:58:38',NULL,NULL);
/*!40000 ALTER TABLE `residents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions_meta`
--

DROP TABLE IF EXISTS `sessions_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` varchar(128) NOT NULL DEFAULT '',
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(512) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `last_used_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sessions_meta_session_id_unique` (`session_id`),
  KEY `sessions_meta_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions_meta`
--

LOCK TABLES `sessions_meta` WRITE;
/*!40000 ALTER TABLE `sessions_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `key` varchar(120) NOT NULL,
  `value` longtext DEFAULT NULL,
  `type` varchar(12) NOT NULL DEFAULT 'string',
  `group` varchar(40) NOT NULL DEFAULT 'general',
  `is_secret` tinyint(1) NOT NULL DEFAULT 0,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `updated_by` varchar(64) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`key`),
  KEY `settings_group_index` (`group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES
('billing.charge_counter','1','int','billing',0,0,NULL,'2026-10-09 19:58:40'),
('billing.invoice_counter','42','int','billing',0,0,NULL,'2026-10-09 19:58:40'),
('billing.last_allocation','equal','string','billing',0,0,NULL,'2026-10-09 19:58:40'),
('billing.last_period','Сентябрь 2026','string','billing',0,0,NULL,'2026-10-09 19:58:40'),
('billing.last_total','15000','float','billing',0,0,NULL,'2026-10-09 19:58:40');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `login` varchar(64) NOT NULL DEFAULT '',
  `email` varchar(190) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL DEFAULT '',
  `full_name` varchar(190) NOT NULL DEFAULT '',
  `role` varchar(16) NOT NULL DEFAULT 'resident',
  `resident_id` bigint(20) unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `must_change_password` tinyint(1) NOT NULL DEFAULT 0,
  `remember_token` varchar(100) DEFAULT NULL,
  `totp_secret` varchar(255) DEFAULT NULL,
  `totp_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `recovery_codes` longtext DEFAULT NULL,
  `failed_attempts` int(11) NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `last_login_ip` varchar(45) DEFAULT NULL,
  `password_changed_at` datetime DEFAULT NULL,
  `preferences` longtext DEFAULT NULL,
  `locale` varchar(8) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_login_unique` (`login`),
  KEY `users_role_is_active_index` (`role`,`is_active`),
  KEY `users_resident_id_index` (`resident_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'edcda36a-ea72-4219-a963-8145ab95a6c7','admin','admin@example.com','$argon2id$v=19$m=65536,t=4,p=1$dVpHYVNkVmt3bFhUU0x4Vw$BAWKlDHrly6FmeHEYgsK/3jpiZf+RhzYCRoHgGWP/2I','Smoke Admin','admin',NULL,1,0,NULL,NULL,0,NULL,0,NULL,NULL,NULL,'2026-10-09 19:58:39',NULL,NULL,'2026-10-09 19:58:39','2026-10-09 19:58:39',NULL),
(2,'23ab71b8-eb79-42d5-a15a-bdb8329689e0','dispatcher',NULL,'$argon2id$v=19$m=65536,t=4,p=1$eVpzRDFvQzNJbjY0QVRpaA$HflDARRpgxHQtVbLU50uX/EuWOLO3QwRiFovX5fEzHA','Dispatcher','operator',NULL,1,1,NULL,NULL,0,NULL,0,NULL,NULL,NULL,'2026-10-09 19:58:39',NULL,NULL,'2026-10-09 19:58:39','2026-10-09 19:58:39',NULL),
(3,'c4dd06b4-9334-4a0b-b14b-029f8a020621','resident',NULL,'$argon2id$v=19$m=65536,t=4,p=1$NUZJS1lVVXZJTllGbXJQUw$6FBWFOLZuWaz8GgImZN6L1vz6ebMoqyWIWnixH4o5gc','Resident','resident',1,1,1,NULL,NULL,0,NULL,0,NULL,NULL,NULL,'2026-10-09 19:58:40',NULL,NULL,'2026-10-09 19:58:40','2026-10-09 19:58:40',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'basip_smoke'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-09 16:58:46
