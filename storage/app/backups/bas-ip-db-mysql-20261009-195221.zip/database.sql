/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: basip_smoke
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB-0+deb12u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `access_schedules`
--

DROP TABLE IF EXISTS `access_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_schedules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL DEFAULT '',
  `resident_id` bigint(20) unsigned DEFAULT NULL,
  `days` varchar(32) NOT NULL DEFAULT '1,2,3,4,5,6,7',
  `start_time` varchar(5) NOT NULL DEFAULT '00:00',
  `end_time` varchar(5) NOT NULL DEFAULT '23:59',
  `effect` varchar(16) NOT NULL DEFAULT 'allow',
  `priority` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `notes` longtext DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `access_schedules_resident_id_is_active_index` (`resident_id`,`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_schedules`
--

LOCK TABLES `access_schedules` WRITE;
/*!40000 ALTER TABLE `access_schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `access_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(190) NOT NULL DEFAULT '',
  `body` longtext DEFAULT NULL,
  `level` varchar(16) NOT NULL DEFAULT 'info',
  `audience` varchar(24) NOT NULL DEFAULT 'active',
  `is_published` tinyint(1) NOT NULL DEFAULT 0,
  `pin` tinyint(1) NOT NULL DEFAULT 0,
  `publish_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `views` int(11) NOT NULL DEFAULT 0,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `announcements_is_published_publish_at_index` (`is_published`,`publish_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_tokens`
--

DROP TABLE IF EXISTS `api_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL DEFAULT '',
  `token_hash` varchar(128) NOT NULL DEFAULT '',
  `prefix` varchar(16) DEFAULT NULL,
  `scopes` longtext DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `expires_at` datetime DEFAULT NULL,
  `last_used_at` datetime DEFAULT NULL,
  `last_used_ip` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_tokens_token_hash_unique` (`token_hash`),
  KEY `api_tokens_is_active_index` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_tokens`
--

LOCK TABLES `api_tokens` WRITE;
/*!40000 ALTER TABLE `api_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `api_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_state`
--

DROP TABLE IF EXISTS `app_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_state` (
  `key` varchar(120) NOT NULL,
  `value` longtext DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_state`
--

LOCK TABLES `app_state` WRITE;
/*!40000 ALTER TABLE `app_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_log`
--

DROP TABLE IF EXISTS `audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `occurred_at` datetime DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `actor_name` varchar(120) DEFAULT NULL,
  `actor_role` varchar(24) DEFAULT NULL,
  `action` varchar(48) NOT NULL DEFAULT '',
  `subject_type` varchar(48) DEFAULT NULL,
  `subject_id` varchar(64) DEFAULT NULL,
  `subject_label` varchar(190) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(512) DEFAULT NULL,
  `request_id` varchar(32) DEFAULT NULL,
  `changes` longtext DEFAULT NULL,
  `meta` longtext DEFAULT NULL,
  `is_security` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `audit_log_occurred_at_index` (`occurred_at`),
  KEY `audit_log_user_id_occurred_at_index` (`user_id`,`occurred_at`),
  KEY `audit_log_subject_type_subject_id_index` (`subject_type`,`subject_id`),
  KEY `audit_log_action_index` (`action`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_log`
--

LOCK TABLES `audit_log` WRITE;
/*!40000 ALTER TABLE `audit_log` DISABLE KEYS */;
INSERT INTO `audit_log` VALUES
(1,'2026-10-09 19:52:20',NULL,'system','system','billing.charge.create','charge','1','CHG-2026-0001',NULL,'cli',NULL,NULL,'{\"total\":15000,\"participants\":1,\"per_unit\":15000,\"allocation\":\"equal\",\"period\":\"Сентябрь 2026\"}',0),
(2,'2026-10-09 19:52:20',NULL,'system','system','billing.payment.record','payment','1','Иванов И. И. · 15 000 ₽',NULL,'cli',NULL,NULL,'{\"resident_id\":1,\"amount\":15000,\"allocated\":[{\"invoice_id\":1,\"number\":\"INV-2026-00001\",\"applied\":15000,\"status\":\"paid\"}],\"overpay\":0}',0),
(3,'2026-10-09 19:52:20',NULL,'system','system','billing.charge.recalc','charge','1','CHG-2026-0001',NULL,'cli',NULL,'{\"before\":{\"total\":15000,\"participants\":1,\"per_unit\":15000},\"after\":{\"total\":18000,\"participants\":1,\"per_unit\":18000},\"diff\":{\"total\":{\"from\":15000,\"to\":18000},\"per_unit\":{\"from\":15000,\"to\":18000}}}','{\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽\",\"adjustments\":1,\"new\":0,\"credits\":0}',0),
(4,'2026-10-09 19:52:20',NULL,'system','system','billing.notify','charge','1','CHG-2026-0001',NULL,'cli',NULL,NULL,'{\"queued\":2,\"skipped\":0,\"template\":\"payment_new\",\"batch_id\":1}',0),
(5,'2026-10-09 19:52:21',NULL,'system','system','gate.open','resident','1','Иванов Иван Иванович',NULL,'cli',NULL,NULL,'{\"access_type\":\"own\",\"source\":\"cli\",\"device\":\"main\",\"event_id\":1}',0),
(6,'2026-10-09 19:52:21',NULL,'system','system','guest.create','guest_pass','1','JC8Y-RC5W',NULL,'cli',NULL,NULL,'{\"resident_id\":1,\"resident\":\"Иванов Иван Иванович\",\"ttl_hours\":12,\"valid_until\":\"2026-10-10 07:52:21\",\"guest_name\":\"Курьер\",\"car_plate\":null,\"purpose\":null,\"created_by_type\":\"resident\"}',0),
(7,'2026-10-09 19:52:21',NULL,'system','system','gate.open','resident','1','Иванов Иван Иванович (гость Курьер)',NULL,'cli',NULL,NULL,'{\"access_type\":\"guest\",\"source\":\"web\",\"device\":\"main\",\"event_id\":3}',0),
(8,'2026-10-09 19:52:21',NULL,'system','system','guest.revoke','guest_pass','1','JC8Y-RC5W',NULL,'cli',NULL,NULL,'{\"reason\":\"smoke\",\"resident_id\":1}',1),
(9,'2026-10-09 19:52:21',NULL,'system','system','data.export','export_job','1','residents-20261009-195221.csv',NULL,'cli',NULL,NULL,'{\"rows\":1,\"format\":\"csv\",\"filters\":{\"status\":\"all\"}}',1),
(10,'2026-10-09 19:52:21',NULL,'system','system','data.import','import_job','1','upload',NULL,'cli',NULL,NULL,'{\"format\":\"csv\",\"mode\":\"dry-run\",\"total\":1,\"imported\":0,\"updated\":1,\"failed\":0,\"dry_run\":true}',1),
(11,'2026-10-09 19:52:21',NULL,'system','system','data.export','export_job','2','residents-20261009-195221.json',NULL,'cli',NULL,NULL,'{\"rows\":1,\"format\":\"json\",\"filters\":{\"status\":\"all\"}}',1);
/*!40000 ALTER TABLE `audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backups`
--

DROP TABLE IF EXISTS `backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(512) NOT NULL DEFAULT '',
  `type` varchar(16) NOT NULL DEFAULT 'db',
  `size_bytes` int(11) NOT NULL DEFAULT 0,
  `checksum` varchar(64) DEFAULT NULL,
  `driver` varchar(24) DEFAULT NULL,
  `encrypted` tinyint(1) NOT NULL DEFAULT 0,
  `status` varchar(16) NOT NULL DEFAULT 'done',
  `note` longtext DEFAULT NULL,
  `meta` longtext DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `backups_created_at_index` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backups`
--

LOCK TABLES `backups` WRITE;
/*!40000 ALTER TABLE `backups` DISABLE KEYS */;
/*!40000 ALTER TABLE `backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_history`
--

DROP TABLE IF EXISTS `billing_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `billing_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `occurred_at` datetime DEFAULT NULL,
  `resident_id` bigint(20) unsigned DEFAULT NULL,
  `entity` varchar(24) NOT NULL DEFAULT 'invoice',
  `entity_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(32) NOT NULL DEFAULT '',
  `amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `balance_before` decimal(14,2) NOT NULL DEFAULT 0.00,
  `balance_after` decimal(14,2) NOT NULL DEFAULT 0.00,
  `details` longtext DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `billing_history_resident_id_occurred_at_index` (`resident_id`,`occurred_at`),
  KEY `billing_history_entity_entity_id_index` (`entity`,`entity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_history`
--

LOCK TABLES `billing_history` WRITE;
/*!40000 ALTER TABLE `billing_history` DISABLE KEYS */;
INSERT INTO `billing_history` VALUES
(1,'2026-10-09 19:52:20',1,'invoice',NULL,'issued',15000.00,0.00,0.00,'{\"charge_id\":1,\"number\":\"INV-2026-00001\",\"period\":\"Сентябрь 2026\"}',NULL),
(2,'2026-10-09 19:52:20',1,'payment',1,'paid',15000.00,0.00,0.00,'{\"allocated\":[{\"invoice_id\":1,\"number\":\"INV-2026-00001\",\"applied\":15000,\"status\":\"paid\"}],\"overpay\":0,\"method\":\"cash\"}',NULL),
(3,'2026-10-09 19:52:20',1,'invoice',2,'adjusted',3000.00,0.00,0.00,'{\"charge_id\":1,\"number\":\"INV-2026-00002-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽\"}',NULL);
/*!40000 ALTER TABLE `billing_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cars`
--

DROP TABLE IF EXISTS `cars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cars` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `resident_id` bigint(20) unsigned NOT NULL,
  `plate` varchar(32) NOT NULL DEFAULT '',
  `plate_normalized` varchar(32) NOT NULL DEFAULT '',
  `brand` varchar(64) DEFAULT NULL,
  `model` varchar(64) DEFAULT NULL,
  `color` varchar(32) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `type` varchar(16) NOT NULL DEFAULT 'car',
  `rfid_tag` varchar(64) DEFAULT NULL,
  `sticker` varchar(32) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `valid_from` datetime DEFAULT NULL,
  `valid_until` datetime DEFAULT NULL,
  `notes` longtext DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cars_resident_id_index` (`resident_id`),
  KEY `cars_plate_normalized_index` (`plate_normalized`),
  KEY `cars_is_active_index` (`is_active`),
  CONSTRAINT `cars_resident_id_fk` FOREIGN KEY (`resident_id`) REFERENCES `residents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cars`
--

LOCK TABLES `cars` WRITE;
/*!40000 ALTER TABLE `cars` DISABLE KEYS */;
/*!40000 ALTER TABLE `cars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charges`
--

DROP TABLE IF EXISTS `charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `charges` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `number` varchar(48) NOT NULL DEFAULT '',
  `title` varchar(190) NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `period_start` date DEFAULT NULL,
  `period_end` date DEFAULT NULL,
  `period_label` varchar(64) NOT NULL DEFAULT '',
  `total_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `active_count` int(11) NOT NULL DEFAULT 0,
  `per_unit_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `allocation` varchar(16) NOT NULL DEFAULT 'equal',
  `due_days` int(11) NOT NULL DEFAULT 14,
  `due_date` date DEFAULT NULL,
  `message` longtext DEFAULT NULL,
  `pay_link` longtext DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'draft',
  `recalc_of` bigint(20) unsigned DEFAULT NULL,
  `recalc_reason` varchar(255) DEFAULT NULL,
  `invoices_total` int(11) NOT NULL DEFAULT 0,
  `invoices_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `paid_count` int(11) NOT NULL DEFAULT 0,
  `notes` longtext DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `issued_at` datetime DEFAULT NULL,
  `closed_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `charges_uuid_unique` (`uuid`),
  KEY `charges_status_index` (`status`),
  KEY `charges_period_start_index` (`period_start`),
  KEY `charges_recalc_of_index` (`recalc_of`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charges`
--

LOCK TABLES `charges` WRITE;
/*!40000 ALTER TABLE `charges` DISABLE KEYS */;
INSERT INTO `charges` VALUES
(1,'91da74f5-95f6-4ceb-b6a8-7120870d7329','CHG-2026-0001','Smoke, Сентябрь 2026',NULL,'2026-09-01','2026-09-30','Сентябрь 2026',18000.00,1,18000.00,'equal',14,'2026-10-23',NULL,NULL,'issued',NULL,'Перерасчёт: сумма 15 000 ₽ → 18 000 ₽',2,18000.00,15000.00,1,NULL,NULL,'2026-10-09 19:52:20',NULL,'2026-10-09 19:52:20','2026-10-09 19:52:20');
/*!40000 ALTER TABLE `charges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `resident_id` bigint(20) unsigned NOT NULL,
  `type` varchar(16) NOT NULL DEFAULT 'phone',
  `value` varchar(190) NOT NULL DEFAULT '',
  `value_normalized` varchar(190) DEFAULT NULL,
  `label` varchar(40) DEFAULT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT 0,
  `notify` tinyint(1) NOT NULL DEFAULT 1,
  `verified` tinyint(1) NOT NULL DEFAULT 0,
  `verified_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contacts_resident_id_type_index` (`resident_id`,`type`),
  KEY `contacts_value_normalized_index` (`value_normalized`),
  CONSTRAINT `contacts_resident_id_fk` FOREIGN KEY (`resident_id`) REFERENCES `residents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` VALUES
(1,1,'phone','+79064673708','+79064673708','мобильный',1,1,1,NULL,'2026-10-09 19:52:01'),
(2,1,'phone','+79020491681','+79020491681','второй',0,1,1,NULL,'2026-10-09 19:52:01'),
(3,1,'phone','+74957672572','+74957672572','домашний',0,0,1,NULL,'2026-10-09 19:52:01'),
(4,1,'email','Ivanov.i1@example.com','ivanov.i1@example.com','основная',1,1,1,NULL,'2026-10-09 19:52:01'),
(5,1,'email','work.ivanov@company.example','work.ivanov@company.example','рабочая',0,0,1,NULL,'2026-10-09 19:52:01');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `devices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL DEFAULT '',
  `slug` varchar(64) NOT NULL DEFAULT '',
  `driver` varchar(24) NOT NULL DEFAULT 'basip',
  `base_url` varchar(255) DEFAULT NULL,
  `login` varchar(120) DEFAULT NULL,
  `password_enc` longtext DEFAULT NULL,
  `channel` int(11) NOT NULL DEFAULT 1,
  `location` varchar(190) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `options` longtext DEFAULT NULL,
  `last_seen_at` datetime DEFAULT NULL,
  `last_status` longtext DEFAULT NULL,
  `error_count` int(11) NOT NULL DEFAULT 0,
  `notes` longtext DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `devices_slug_unique` (`slug`),
  KEY `devices_is_active_index` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devices`
--

LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `export_jobs`
--

DROP TABLE IF EXISTS `export_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `export_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `kind` varchar(32) NOT NULL DEFAULT 'residents',
  `format` varchar(12) NOT NULL DEFAULT 'csv',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `rows` int(11) NOT NULL DEFAULT 0,
  `size_bytes` int(11) NOT NULL DEFAULT 0,
  `filters` longtext DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `export_jobs_uuid_unique` (`uuid`),
  KEY `export_jobs_created_at_index` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `export_jobs`
--

LOCK TABLES `export_jobs` WRITE;
/*!40000 ALTER TABLE `export_jobs` DISABLE KEYS */;
INSERT INTO `export_jobs` VALUES
(1,'a5dfdd77-2234-4acf-93d3-13185fa9b380','residents','csv','residents-20261009-195221.csv',1,977,'{\"status\":\"all\"}',NULL,NULL,'2026-10-09 19:52:21','2026-10-10 19:52:21'),
(2,'4c9fa7e0-9ef2-4f01-9f06-839cb63465f0','residents','json','residents-20261009-195221.json',1,3829,'{\"status\":\"all\"}',NULL,NULL,'2026-10-09 19:52:21','2026-10-10 19:52:21');
/*!40000 ALTER TABLE `export_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gate_events`
--

DROP TABLE IF EXISTS `gate_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gate_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `occurred_at` datetime DEFAULT NULL,
  `device_id` bigint(20) unsigned DEFAULT NULL,
  `channel` int(11) NOT NULL DEFAULT 1,
  `actor_type` varchar(24) NOT NULL DEFAULT 'system',
  `resident_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `guest_pass_id` bigint(20) unsigned DEFAULT NULL,
  `actor_name` varchar(190) DEFAULT NULL,
  `apartment` varchar(24) DEFAULT NULL,
  `access_type` varchar(24) NOT NULL DEFAULT 'own',
  `action` varchar(16) NOT NULL DEFAULT 'open',
  `source` varchar(24) NOT NULL DEFAULT 'web',
  `result` varchar(16) NOT NULL DEFAULT 'success',
  `reason` varchar(190) DEFAULT NULL,
  `plate` varchar(32) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(512) DEFAULT NULL,
  `request_id` varchar(32) DEFAULT NULL,
  `duration_ms` int(11) DEFAULT NULL,
  `device_response` longtext DEFAULT NULL,
  `meta` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gate_events_occurred_at_index` (`occurred_at`),
  KEY `gate_events_resident_id_occurred_at_index` (`resident_id`,`occurred_at`),
  KEY `gate_events_access_type_occurred_at_index` (`access_type`,`occurred_at`),
  KEY `gate_events_result_index` (`result`),
  KEY `gate_events_guest_pass_id_index` (`guest_pass_id`),
  KEY `gate_events_device_id_occurred_at_index` (`device_id`,`occurred_at`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gate_events`
--

LOCK TABLES `gate_events` WRITE;
/*!40000 ALTER TABLE `gate_events` DISABLE KEYS */;
INSERT INTO `gate_events` VALUES
(1,'759485c0-9703-499c-8fa1-6284a8cee917','2026-10-09 19:52:21',NULL,1,'resident',1,NULL,NULL,'Иванов Иван Иванович','1','own','open','cli','success',NULL,NULL,NULL,'cli',NULL,63,NULL,'{\"ok\":true,\"message\":\"Шлагбаум открыт (эмулятор)\"}'),
(2,'e618efce-39f5-45f9-aabe-7caea9af954f','2026-10-09 19:52:21',NULL,1,'guest',1,NULL,1,'Иванов Иван Иванович','1','guest','issued','cli','success','Гостевой доступ issued: JC8Y-RC5W до 2026-10-10 07:52:21',NULL,NULL,NULL,NULL,NULL,NULL,'{\"code\":\"JC8Y-RC5W\",\"ttl_hours\":12,\"valid_until\":\"2026-10-10 07:52:21\",\"guest_name\":\"Курьер\"}'),
(3,'3b722278-3117-49b1-86ab-c3aed7567adc','2026-10-09 19:52:21',NULL,1,'guest',1,NULL,1,'Иванов Иван Иванович (гость Курьер)','1','guest','open','web','success',NULL,NULL,NULL,'cli',NULL,61,NULL,'{\"ok\":true,\"message\":\"Шлагбаум открыт (эмулятор)\"}'),
(4,'20d177d6-e5fb-41fa-ba63-0a404cb6dadf','2026-10-09 19:52:21',NULL,1,'guest',1,NULL,1,'Иванов Иван Иванович','1','guest','revoked','cli','success','smoke',NULL,NULL,NULL,NULL,NULL,NULL,'{\"code\":\"JC8Y-RC5W\",\"ttl_hours\":12,\"valid_until\":\"2026-10-10 07:52:21\",\"guest_name\":\"Курьер\"}'),
(5,'b4cc09a3-400e-407f-971d-522c873a18b9','2026-10-09 19:52:21',NULL,1,'resident',1,NULL,NULL,'Иванов Иван Иванович','1','own','denied','web','denied','Доступ приостановлен (снята галочка «доступ»).',NULL,NULL,'cli',NULL,NULL,NULL,'{\"code\":\"no_access\"}');
/*!40000 ALTER TABLE `gate_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guest_passes`
--

DROP TABLE IF EXISTS `guest_passes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `guest_passes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `code` varchar(24) NOT NULL DEFAULT '',
  `token_hash` varchar(128) NOT NULL DEFAULT '',
  `pin` varchar(12) DEFAULT NULL,
  `resident_id` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_by_type` varchar(16) NOT NULL DEFAULT 'resident',
  `guest_name` varchar(190) DEFAULT NULL,
  `guest_phone` varchar(32) DEFAULT NULL,
  `car_plate` varchar(32) DEFAULT NULL,
  `car_plate_normalized` varchar(32) DEFAULT NULL,
  `purpose` varchar(190) DEFAULT NULL,
  `max_guests` int(11) NOT NULL DEFAULT 1,
  `valid_from` datetime DEFAULT NULL,
  `valid_until` datetime DEFAULT NULL,
  `ttl_hours` int(11) NOT NULL DEFAULT 12,
  `max_uses` int(11) NOT NULL DEFAULT 0,
  `used_count` int(11) NOT NULL DEFAULT 0,
  `last_used_at` datetime DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'active',
  `revoked_at` datetime DEFAULT NULL,
  `revoked_by` bigint(20) unsigned DEFAULT NULL,
  `revoke_reason` varchar(190) DEFAULT NULL,
  `ip_created` varchar(45) DEFAULT NULL,
  `ip_last_used` varchar(45) DEFAULT NULL,
  `notify_on_use` tinyint(1) NOT NULL DEFAULT 0,
  `meta` longtext DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `guest_passes_uuid_unique` (`uuid`),
  UNIQUE KEY `guest_passes_code_unique` (`code`),
  UNIQUE KEY `guest_passes_token_hash_unique` (`token_hash`),
  KEY `guest_passes_resident_id_status_index` (`resident_id`,`status`),
  KEY `guest_passes_status_valid_until_index` (`status`,`valid_until`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guest_passes`
--

LOCK TABLES `guest_passes` WRITE;
/*!40000 ALTER TABLE `guest_passes` DISABLE KEYS */;
INSERT INTO `guest_passes` VALUES
(1,'b01e1aa6-c42a-47b2-a269-7de4cddcbe1e','JC8Y-RC5W','hash:sha256:7b402fcab60e4fbca35607db153dba497070e3d0fbebb1fd74336a2101b30725','736777',1,1,'resident','Курьер',NULL,NULL,NULL,NULL,1,'2026-10-09 19:52:21','2026-10-10 07:52:21',12,0,1,'2026-10-09 19:52:21','revoked','2026-10-09 19:52:21',NULL,'smoke',NULL,NULL,0,NULL,'2026-10-09 19:52:21','2026-10-09 19:52:21');
/*!40000 ALTER TABLE `guest_passes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `import_jobs`
--

DROP TABLE IF EXISTS `import_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `import_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `kind` varchar(24) NOT NULL DEFAULT 'residents',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `format` varchar(12) NOT NULL DEFAULT 'csv',
  `mode` varchar(16) NOT NULL DEFAULT 'upsert',
  `rows_total` int(11) NOT NULL DEFAULT 0,
  `rows_imported` int(11) NOT NULL DEFAULT 0,
  `rows_skipped` int(11) NOT NULL DEFAULT 0,
  `rows_failed` int(11) NOT NULL DEFAULT 0,
  `errors` longtext DEFAULT NULL,
  `mapping` longtext DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'running',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `finished_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `import_jobs_uuid_unique` (`uuid`),
  KEY `import_jobs_kind_started_at_index` (`kind`,`started_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `import_jobs`
--

LOCK TABLES `import_jobs` WRITE;
/*!40000 ALTER TABLE `import_jobs` DISABLE KEYS */;
INSERT INTO `import_jobs` VALUES
(1,'0881b34b-5a8f-4e33-b6c4-2b66dabb6f81','residents','upload','csv','dry-run',1,1,0,0,'[]',NULL,'done',NULL,'2026-10-09 19:52:21','2026-10-09 19:52:21');
/*!40000 ALTER TABLE `import_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `number` varchar(48) NOT NULL DEFAULT '',
  `charge_id` bigint(20) unsigned DEFAULT NULL,
  `resident_id` bigint(20) unsigned NOT NULL,
  `parent_invoice_id` bigint(20) unsigned DEFAULT NULL,
  `kind` varchar(16) NOT NULL DEFAULT 'regular',
  `amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `balance` decimal(14,2) NOT NULL DEFAULT 0.00,
  `period_start` date DEFAULT NULL,
  `period_end` date DEFAULT NULL,
  `period_label` varchar(64) NOT NULL DEFAULT '',
  `due_date` date DEFAULT NULL,
  `issued_date` date DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'pending',
  `pay_link` varchar(512) DEFAULT NULL,
  `note` longtext DEFAULT NULL,
  `recalc_reason` varchar(255) DEFAULT NULL,
  `issued_at` datetime DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `voided_at` datetime DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoices_uuid_unique` (`uuid`),
  KEY `invoices_resident_id_status_index` (`resident_id`,`status`),
  KEY `invoices_charge_id_index` (`charge_id`),
  KEY `invoices_status_due_date_index` (`status`,`due_date`),
  KEY `invoices_period_start_index` (`period_start`),
  CONSTRAINT `invoices_resident_id_fk` FOREIGN KEY (`resident_id`) REFERENCES `residents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES
(1,'4c111bd6-bc1a-446d-ba11-8193e0f969cf','INV-2026-00001',1,1,NULL,'regular',15000.00,15000.00,0.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','paid',NULL,NULL,NULL,'2026-10-09 19:52:20','2026-10-09 00:00:00',NULL,NULL,'2026-10-09 19:52:20','2026-10-09 19:52:20'),
(2,'d9ce30b8-2a42-4c24-a625-9d414cd894b1','INV-2026-00002-Д',1,1,1,'adjustment',3000.00,0.00,3000.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽','2026-10-09 19:52:20',NULL,NULL,NULL,'2026-10-09 19:52:20','2026-10-09 19:52:20');
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_attempts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(190) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(512) DEFAULT NULL,
  `successful` tinyint(1) NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `reason` varchar(64) DEFAULT NULL,
  `method` varchar(16) NOT NULL DEFAULT 'password',
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `login_attempts_ip_created_at_index` (`ip`,`created_at`),
  KEY `login_attempts_identifier_created_at_index` (`identifier`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--

LOCK TABLES `login_attempts` WRITE;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(190) NOT NULL DEFAULT '',
  `batch` int(11) NOT NULL DEFAULT 0,
  `checksum` varchar(64) DEFAULT NULL,
  `duration_ms` int(11) DEFAULT NULL,
  `executed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `migrations_migration_unique` (`migration`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'2026_01_01_000100_create_core_tables.php',1,'0d4480174cb41027f47e659dfa94b3f3b28ce8b360b8fe050ffa2eb0310ea5cd',7,'2026-10-09 19:52:01'),
(2,'2026_01_01_000200_create_residents_tables.php',1,'efc3f0db2311618f169f894271425521046f451ca0b33563a2e521c22148fd8e',7,'2026-10-09 19:52:01'),
(3,'2026_01_01_000300_create_billing_tables.php',1,'7ba60ffa9c016cfd94f930b78a1f45de15c0773b2763c035399387f3499bcaf4',6,'2026-10-09 19:52:01'),
(4,'2026_01_01_000400_create_gate_tables.php',1,'a19e5b98bf79ec7567acfa446c52894cb00c1357405a84cf9e03666d98c3906d',3,'2026-10-09 19:52:01'),
(5,'2026_01_01_000500_create_messaging_tables.php',1,'15f0152efb8f32af6bc5566e05eb336400c65dbe95300953d52dfd3fc54b8a7f',6,'2026-10-09 19:52:01');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_batches`
--

DROP TABLE IF EXISTS `notification_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_batches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `name` varchar(190) NOT NULL DEFAULT '',
  `template` varchar(64) NOT NULL DEFAULT 'custom',
  `subject` varchar(255) DEFAULT NULL,
  `message` longtext DEFAULT NULL,
  `pay_link` longtext DEFAULT NULL,
  `charge_id` bigint(20) unsigned DEFAULT NULL,
  `channels` longtext DEFAULT NULL,
  `audience` longtext DEFAULT NULL,
  `recipients` int(11) NOT NULL DEFAULT 0,
  `sent` int(11) NOT NULL DEFAULT 0,
  `failed` int(11) NOT NULL DEFAULT 0,
  `skipped` int(11) NOT NULL DEFAULT 0,
  `status` varchar(16) NOT NULL DEFAULT 'queued',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `finished_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `notification_batches_uuid_unique` (`uuid`),
  KEY `notification_batches_status_index` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_batches`
--

LOCK TABLES `notification_batches` WRITE;
/*!40000 ALTER TABLE `notification_batches` DISABLE KEYS */;
INSERT INTO `notification_batches` VALUES
(1,'77b5ed95-01fb-4556-8cbf-9cf47d47b380','Рассылка по начислению CHG-2026-0001','payment_new',NULL,NULL,NULL,1,'[\"log\"]',NULL,2,2,0,0,'done',NULL,'2026-10-09 19:52:20','2026-10-09 19:52:20','2026-10-09 19:52:20');
/*!40000 ALTER TABLE `notification_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `outbox`
--

DROP TABLE IF EXISTS `outbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `outbox` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `batch_id` bigint(20) unsigned DEFAULT NULL,
  `channel` varchar(24) NOT NULL DEFAULT 'log',
  `resident_id` bigint(20) unsigned DEFAULT NULL,
  `recipient` varchar(255) NOT NULL DEFAULT '',
  `subject` varchar(255) DEFAULT NULL,
  `body` longtext DEFAULT NULL,
  `template` varchar(64) DEFAULT NULL,
  `context` longtext DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'pending',
  `attempts` int(11) NOT NULL DEFAULT 0,
  `max_attempts` int(11) NOT NULL DEFAULT 5,
  `last_error` longtext DEFAULT NULL,
  `provider_id` varchar(128) DEFAULT NULL,
  `scheduled_at` datetime DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `outbox_uuid_unique` (`uuid`),
  KEY `outbox_status_scheduled_at_index` (`status`,`scheduled_at`),
  KEY `outbox_batch_id_index` (`batch_id`),
  KEY `outbox_resident_id_index` (`resident_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `outbox`
--

LOCK TABLES `outbox` WRITE;
/*!40000 ALTER TABLE `outbox` DISABLE KEYS */;
INSERT INTO `outbox` VALUES
(1,'609df889-5fa9-4f7e-9d7e-2939f4765cee',1,'log',1,'Ivanov.i1@example.com','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Иванов И. И.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 15 000 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 1.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Иванов И. И.\",\"full_name\":\"Иванов Иван Иванович\",\"apartment\":\"1\",\"building\":\"1\",\"address\":\"корп. 1, кв. 1\",\"amount\":\"15 000 ₽\",\"amount_raw\":15000,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00001\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-3 000 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:f61341a3b7d6','2026-10-09 19:52:20','2026-10-09 19:52:20','2026-10-09 19:52:20'),
(2,'c8950507-2cef-4435-a946-973f6fd9842a',1,'log',2,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Иванов И. И.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 3 000 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 1.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Иванов И. И.\",\"full_name\":\"Иванов Иван Иванович\",\"apartment\":\"1\",\"building\":\"1\",\"address\":\"корп. 1, кв. 1\",\"amount\":\"3 000 ₽\",\"amount_raw\":3000,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00002-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-3 000 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:fdb69bddeef5','2026-10-09 19:52:20','2026-10-09 19:52:20','2026-10-09 19:52:20');
/*!40000 ALTER TABLE `outbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `resident_id` bigint(20) unsigned NOT NULL,
  `invoice_id` bigint(20) unsigned DEFAULT NULL,
  `charge_id` bigint(20) unsigned DEFAULT NULL,
  `amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `paid_at` date DEFAULT NULL,
  `method` varchar(24) NOT NULL DEFAULT 'transfer',
  `reference` varchar(120) DEFAULT NULL,
  `payer_name` varchar(190) DEFAULT NULL,
  `note` longtext DEFAULT NULL,
  `external_id` varchar(96) DEFAULT NULL,
  `is_confirmed` tinyint(1) NOT NULL DEFAULT 1,
  `recorded_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payments_uuid_unique` (`uuid`),
  KEY `payments_resident_id_paid_at_index` (`resident_id`,`paid_at`),
  KEY `payments_invoice_id_index` (`invoice_id`),
  KEY `payments_paid_at_index` (`paid_at`),
  CONSTRAINT `payments_resident_id_fk` FOREIGN KEY (`resident_id`) REFERENCES `residents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES
(1,'b3f66208-d727-471f-8772-da43765e1373',1,1,1,15000.00,'2026-10-09','cash',NULL,NULL,NULL,NULL,1,NULL,'2026-10-09 19:52:20','2026-10-09 19:52:20');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `residents`
--

DROP TABLE IF EXISTS `residents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `residents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `external_id` varchar(64) DEFAULT NULL,
  `last_name` varchar(120) NOT NULL DEFAULT '',
  `first_name` varchar(120) NOT NULL DEFAULT '',
  `patronymic` varchar(120) DEFAULT NULL,
  `full_name` varchar(255) NOT NULL DEFAULT '',
  `search_index` varchar(512) DEFAULT NULL,
  `apartment` varchar(24) NOT NULL DEFAULT '',
  `apartment_no` int(11) DEFAULT NULL,
  `building` varchar(24) DEFAULT NULL,
  `entrance` varchar(16) DEFAULT NULL,
  `floor` int(11) DEFAULT NULL,
  `area` decimal(10,2) NOT NULL DEFAULT 0.00,
  `persons` int(11) NOT NULL DEFAULT 1,
  `share` decimal(10,4) NOT NULL DEFAULT 1.0000,
  `role_in_home` varchar(24) NOT NULL DEFAULT 'owner',
  `phone` varchar(32) DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `access_granted` tinyint(1) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_billed` tinyint(1) NOT NULL DEFAULT 1,
  `allow_guest_pass` tinyint(1) NOT NULL DEFAULT 1,
  `notify_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `notes` longtext DEFAULT NULL,
  `tags` longtext DEFAULT NULL,
  `balance` decimal(12,2) NOT NULL DEFAULT 0.00,
  `last_payment_at` datetime DEFAULT NULL,
  `last_gate_event_at` datetime DEFAULT NULL,
  `avatar_path` varchar(255) DEFAULT NULL,
  `meta` longtext DEFAULT NULL,
  `guest_passes_issued` int(11) NOT NULL DEFAULT 0,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `archived_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `residents_uuid_unique` (`uuid`),
  KEY `residents_is_active_is_billed_index` (`is_active`,`is_billed`),
  KEY `residents_apartment_no_building_index` (`apartment_no`,`building`),
  KEY `residents_last_name_index` (`last_name`),
  KEY `residents_email_index` (`email`),
  KEY `residents_deleted_at_index` (`deleted_at`),
  KEY `residents_access_granted_index` (`access_granted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `residents`
--

LOCK TABLES `residents` WRITE;
/*!40000 ALTER TABLE `residents` DISABLE KEYS */;
INSERT INTO `residents` VALUES
(1,'e6a23b6a-b460-4c51-917d-d1552e695523',NULL,'Иванов','Иван','Иванович','Иванов Иван Иванович','иванов иван иванович кв 1 79064673708 ivanov.i1@example.com','1',1,'1','1',1,28.00,1,1.0000,'owner','+79064673708','Ivanov.i1@example.com',1,1,1,1,1,'Просил напоминать об оплате за 3 дня.','[\"староста\",\"актив\"]',-3000.00,'2026-10-09 00:00:00','2026-10-09 19:52:21',NULL,NULL,1,NULL,NULL,'2026-08-01 19:52:01','2026-09-23 19:52:01',NULL,NULL);
/*!40000 ALTER TABLE `residents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions_meta`
--

DROP TABLE IF EXISTS `sessions_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` varchar(128) NOT NULL DEFAULT '',
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(512) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `last_used_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sessions_meta_session_id_unique` (`session_id`),
  KEY `sessions_meta_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions_meta`
--

LOCK TABLES `sessions_meta` WRITE;
/*!40000 ALTER TABLE `sessions_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `key` varchar(120) NOT NULL,
  `value` longtext DEFAULT NULL,
  `type` varchar(12) NOT NULL DEFAULT 'string',
  `group` varchar(40) NOT NULL DEFAULT 'general',
  `is_secret` tinyint(1) NOT NULL DEFAULT 0,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `updated_by` varchar(64) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`key`),
  KEY `settings_group_index` (`group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES
('billing.charge_counter','1','int','billing',0,0,NULL,'2026-10-09 19:52:20'),
('billing.invoice_counter','2','int','billing',0,0,NULL,'2026-10-09 19:52:20'),
('billing.last_allocation','equal','string','billing',0,0,NULL,'2026-10-09 19:52:20'),
('billing.last_period','Сентябрь 2026','string','billing',0,0,NULL,'2026-10-09 19:52:20'),
('billing.last_total','15000','float','billing',0,0,NULL,'2026-10-09 19:52:20');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `login` varchar(64) NOT NULL DEFAULT '',
  `email` varchar(190) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL DEFAULT '',
  `full_name` varchar(190) NOT NULL DEFAULT '',
  `role` varchar(16) NOT NULL DEFAULT 'resident',
  `resident_id` bigint(20) unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `must_change_password` tinyint(1) NOT NULL DEFAULT 0,
  `remember_token` varchar(100) DEFAULT NULL,
  `totp_secret` varchar(255) DEFAULT NULL,
  `totp_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `recovery_codes` longtext DEFAULT NULL,
  `failed_attempts` int(11) NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `last_login_ip` varchar(45) DEFAULT NULL,
  `password_changed_at` datetime DEFAULT NULL,
  `preferences` longtext DEFAULT NULL,
  `locale` varchar(8) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_login_unique` (`login`),
  KEY `users_role_is_active_index` (`role`,`is_active`),
  KEY `users_resident_id_index` (`resident_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'b7db43c3-1e16-4263-99e3-b327c12bace6','admin','admin@example.com','$argon2id$v=19$m=65536,t=4,p=1$Z0VXSG5XeFY4QkNnVWtNUw$vzTdaA2vY4gSd0sMpYFp02+nJnDW15t3/rWdZV6voOU','Smoke Admin','admin',NULL,1,0,NULL,NULL,0,NULL,0,NULL,NULL,NULL,'2026-10-09 19:52:19',NULL,NULL,'2026-10-09 19:52:19','2026-10-09 19:52:19',NULL),
(2,'1297823e-2f32-47be-a5d0-75eea79dd6a2','dispatcher',NULL,'$argon2id$v=19$m=65536,t=4,p=1$SkkyQi9FOG9vbURWVlE0RA$7DuiJl801oxJoPDQvFrQfIYKksOUNmCjT++U69owAE4','Dispatcher','operator',NULL,1,1,NULL,NULL,0,NULL,0,NULL,NULL,NULL,'2026-10-09 19:52:19',NULL,NULL,'2026-10-09 19:52:19','2026-10-09 19:52:19',NULL),
(3,'62f214e4-3130-4c4e-9be6-9d8b761d7d33','resident',NULL,'$argon2id$v=19$m=65536,t=4,p=1$aXdibUw4azhzLlowc0JSNg$7Lv3hBozobgZgVMhOAWp5KxnrgNBd+DWemWuZLgQr6c','Resident','resident',1,1,1,NULL,NULL,0,NULL,0,NULL,NULL,NULL,'2026-10-09 19:52:20',NULL,NULL,'2026-10-09 19:52:20','2026-10-09 19:52:20',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'basip_smoke'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-09 16:52:21
