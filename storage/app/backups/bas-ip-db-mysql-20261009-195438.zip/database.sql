/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.18-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: basip_smoke
-- ------------------------------------------------------
-- Server version	10.11.18-MariaDB-0+deb12u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `access_schedules`
--

DROP TABLE IF EXISTS `access_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_schedules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL DEFAULT '',
  `resident_id` bigint(20) unsigned DEFAULT NULL,
  `days` varchar(32) NOT NULL DEFAULT '1,2,3,4,5,6,7',
  `start_time` varchar(5) NOT NULL DEFAULT '00:00',
  `end_time` varchar(5) NOT NULL DEFAULT '23:59',
  `effect` varchar(16) NOT NULL DEFAULT 'allow',
  `priority` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `notes` longtext DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `access_schedules_resident_id_is_active_index` (`resident_id`,`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_schedules`
--

LOCK TABLES `access_schedules` WRITE;
/*!40000 ALTER TABLE `access_schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `access_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(190) NOT NULL DEFAULT '',
  `body` longtext DEFAULT NULL,
  `level` varchar(16) NOT NULL DEFAULT 'info',
  `audience` varchar(24) NOT NULL DEFAULT 'active',
  `is_published` tinyint(1) NOT NULL DEFAULT 0,
  `pin` tinyint(1) NOT NULL DEFAULT 0,
  `publish_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `views` int(11) NOT NULL DEFAULT 0,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `announcements_is_published_publish_at_index` (`is_published`,`publish_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
INSERT INTO `announcements` VALUES
(1,'Профилактика шлагбаума','В субботу с 10:00 до 12:00 проведём ТО привода.\nВ это время шлагбаум открывается диспетчером по телефону.\n\nСпасибо за понимание!','warning','active',1,1,'2026-10-09 18:54:30','2026-10-16 19:54:30',0,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30');
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_tokens`
--

DROP TABLE IF EXISTS `api_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL DEFAULT '',
  `token_hash` varchar(128) NOT NULL DEFAULT '',
  `prefix` varchar(16) DEFAULT NULL,
  `scopes` longtext DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `expires_at` datetime DEFAULT NULL,
  `last_used_at` datetime DEFAULT NULL,
  `last_used_ip` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_tokens_token_hash_unique` (`token_hash`),
  KEY `api_tokens_is_active_index` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_tokens`
--

LOCK TABLES `api_tokens` WRITE;
/*!40000 ALTER TABLE `api_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `api_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_state`
--

DROP TABLE IF EXISTS `app_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_state` (
  `key` varchar(120) NOT NULL,
  `value` longtext DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_state`
--

LOCK TABLES `app_state` WRITE;
/*!40000 ALTER TABLE `app_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_log`
--

DROP TABLE IF EXISTS `audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `occurred_at` datetime DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `actor_name` varchar(120) DEFAULT NULL,
  `actor_role` varchar(24) DEFAULT NULL,
  `action` varchar(48) NOT NULL DEFAULT '',
  `subject_type` varchar(48) DEFAULT NULL,
  `subject_id` varchar(64) DEFAULT NULL,
  `subject_label` varchar(190) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(512) DEFAULT NULL,
  `request_id` varchar(32) DEFAULT NULL,
  `changes` longtext DEFAULT NULL,
  `meta` longtext DEFAULT NULL,
  `is_security` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `audit_log_occurred_at_index` (`occurred_at`),
  KEY `audit_log_user_id_occurred_at_index` (`user_id`,`occurred_at`),
  KEY `audit_log_subject_type_subject_id_index` (`subject_type`,`subject_id`),
  KEY `audit_log_action_index` (`action`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_log`
--

LOCK TABLES `audit_log` WRITE;
/*!40000 ALTER TABLE `audit_log` DISABLE KEYS */;
INSERT INTO `audit_log` VALUES
(1,'2026-10-09 19:54:32',NULL,'system','system','billing.charge.create','charge','2','CHG-2026-0001',NULL,'cli',NULL,NULL,'{\"total\":15000,\"participants\":20,\"per_unit\":750,\"allocation\":\"equal\",\"period\":\"Сентябрь 2026\"}',0),
(2,'2026-10-09 19:54:32',NULL,'system','system','billing.payment.record','payment','13','Иванов И. И. · 750 ₽',NULL,'cli',NULL,NULL,'{\"resident_id\":1,\"amount\":750,\"allocated\":[{\"invoice_id\":23,\"number\":\"INV-2026-00001\",\"applied\":750,\"status\":\"paid\"}],\"overpay\":0}',0),
(3,'2026-10-09 19:54:32',NULL,'system','system','billing.payment.record','payment','14','Петрова М. П. · 750 ₽',NULL,'cli',NULL,NULL,'{\"resident_id\":2,\"amount\":750,\"allocated\":[{\"invoice_id\":24,\"number\":\"INV-2026-00002\",\"applied\":750,\"status\":\"paid\"}],\"overpay\":0}',0),
(4,'2026-10-09 19:54:32',NULL,'system','system','billing.charge.recalc','charge','2','CHG-2026-0001',NULL,'cli',NULL,'{\"before\":{\"total\":15000,\"participants\":20,\"per_unit\":750},\"after\":{\"total\":18000,\"participants\":22,\"per_unit\":818.18},\"diff\":{\"total\":{\"from\":15000,\"to\":18000},\"participants\":{\"from\":20,\"to\":22},\"per_unit\":{\"from\":750,\"to\":818.18}}}','{\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\",\"adjustments\":20,\"new\":2,\"credits\":0}',0),
(5,'2026-10-09 19:54:32',NULL,'system','system','billing.notify','charge','2','CHG-2026-0001',NULL,'cli',NULL,NULL,'{\"queued\":38,\"skipped\":4,\"template\":\"payment_new\",\"batch_id\":1}',0),
(6,'2026-10-09 19:54:38',NULL,'system','system','gate.open','resident','1','Иванов Иван Иванович',NULL,'cli',NULL,NULL,'{\"access_type\":\"own\",\"source\":\"cli\",\"device\":\"main\",\"event_id\":425}',0),
(7,'2026-10-09 19:54:38',NULL,'system','system','guest.create','guest_pass','7','F3WU-Z3E6',NULL,'cli',NULL,NULL,'{\"resident_id\":1,\"resident\":\"Иванов Иван Иванович\",\"ttl_hours\":12,\"valid_until\":\"2026-10-10 07:54:38\",\"guest_name\":\"Курьер\",\"car_plate\":null,\"purpose\":null,\"created_by_type\":\"resident\"}',0),
(8,'2026-10-09 19:54:38',NULL,'system','system','gate.open','resident','1','Иванов Иван Иванович (гость Курьер)',NULL,'cli',NULL,NULL,'{\"access_type\":\"guest\",\"source\":\"web\",\"device\":\"main\",\"event_id\":427}',0),
(9,'2026-10-09 19:54:38',NULL,'system','system','guest.revoke','guest_pass','7','F3WU-Z3E6',NULL,'cli',NULL,NULL,'{\"reason\":\"smoke\",\"resident_id\":1}',1),
(10,'2026-10-09 19:54:38',NULL,'system','system','data.export','export_job','1','residents-20261009-195438.csv',NULL,'cli',NULL,NULL,'{\"rows\":24,\"format\":\"csv\",\"filters\":{\"status\":\"all\"}}',1),
(11,'2026-10-09 19:54:38',NULL,'system','system','data.import','import_job','1','upload',NULL,'cli',NULL,NULL,'{\"format\":\"csv\",\"mode\":\"dry-run\",\"total\":24,\"imported\":0,\"updated\":24,\"failed\":0,\"dry_run\":true}',1),
(12,'2026-10-09 19:54:38',NULL,'system','system','data.export','export_job','2','residents-20261009-195438.json',NULL,'cli',NULL,NULL,'{\"rows\":24,\"format\":\"json\",\"filters\":{\"status\":\"all\"}}',1);
/*!40000 ALTER TABLE `audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backups`
--

DROP TABLE IF EXISTS `backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(512) NOT NULL DEFAULT '',
  `type` varchar(16) NOT NULL DEFAULT 'db',
  `size_bytes` int(11) NOT NULL DEFAULT 0,
  `checksum` varchar(64) DEFAULT NULL,
  `driver` varchar(24) DEFAULT NULL,
  `encrypted` tinyint(1) NOT NULL DEFAULT 0,
  `status` varchar(16) NOT NULL DEFAULT 'done',
  `note` longtext DEFAULT NULL,
  `meta` longtext DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `backups_created_at_index` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backups`
--

LOCK TABLES `backups` WRITE;
/*!40000 ALTER TABLE `backups` DISABLE KEYS */;
/*!40000 ALTER TABLE `backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing_history`
--

DROP TABLE IF EXISTS `billing_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `billing_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `occurred_at` datetime DEFAULT NULL,
  `resident_id` bigint(20) unsigned DEFAULT NULL,
  `entity` varchar(24) NOT NULL DEFAULT 'invoice',
  `entity_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(32) NOT NULL DEFAULT '',
  `amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `balance_before` decimal(14,2) NOT NULL DEFAULT 0.00,
  `balance_after` decimal(14,2) NOT NULL DEFAULT 0.00,
  `details` longtext DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `billing_history_resident_id_occurred_at_index` (`resident_id`,`occurred_at`),
  KEY `billing_history_entity_entity_id_index` (`entity`,`entity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_history`
--

LOCK TABLES `billing_history` WRITE;
/*!40000 ALTER TABLE `billing_history` DISABLE KEYS */;
INSERT INTO `billing_history` VALUES
(1,'2026-10-23 00:00:00',1,'payment',1,'paid',750.00,0.00,0.00,'{\"demo\":true}',NULL),
(2,'2026-10-24 00:00:00',2,'payment',2,'paid',750.00,0.00,0.00,'{\"demo\":true}',NULL),
(3,'2026-10-21 00:00:00',3,'payment',3,'paid',375.00,0.00,0.00,'{\"demo\":true}',NULL),
(4,'2026-10-01 00:00:00',7,'payment',4,'paid',750.00,0.00,0.00,'{\"demo\":true}',NULL),
(5,'2026-10-12 00:00:00',9,'payment',5,'paid',750.00,0.00,0.00,'{\"demo\":true}',NULL),
(6,'2026-10-25 00:00:00',10,'payment',6,'paid',375.00,0.00,0.00,'{\"demo\":true}',NULL),
(7,'2026-10-19 00:00:00',13,'payment',7,'paid',750.00,0.00,0.00,'{\"demo\":true}',NULL),
(8,'2026-10-25 00:00:00',14,'payment',8,'paid',750.00,0.00,0.00,'{\"demo\":true}',NULL),
(9,'2026-10-16 00:00:00',15,'payment',9,'paid',375.00,0.00,0.00,'{\"demo\":true}',NULL),
(10,'2026-10-25 00:00:00',20,'payment',10,'paid',750.00,0.00,0.00,'{\"demo\":true}',NULL),
(11,'2026-10-09 00:00:00',21,'payment',11,'paid',750.00,0.00,0.00,'{\"demo\":true}',NULL),
(12,'2026-10-23 00:00:00',22,'payment',12,'paid',375.00,0.00,0.00,'{\"demo\":true}',NULL),
(13,'2026-10-09 19:54:32',1,'invoice',NULL,'issued',750.00,-150.00,-150.00,'{\"charge_id\":2,\"number\":\"INV-2026-00001\",\"period\":\"Сентябрь 2026\"}',NULL),
(14,'2026-10-09 19:54:32',2,'invoice',NULL,'issued',750.00,100.00,100.00,'{\"charge_id\":2,\"number\":\"INV-2026-00002\",\"period\":\"Сентябрь 2026\"}',NULL),
(15,'2026-10-09 19:54:32',3,'invoice',NULL,'issued',750.00,-375.00,-375.00,'{\"charge_id\":2,\"number\":\"INV-2026-00003\",\"period\":\"Сентябрь 2026\"}',NULL),
(16,'2026-10-09 19:54:32',5,'invoice',NULL,'issued',750.00,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00004\",\"period\":\"Сентябрь 2026\"}',NULL),
(17,'2026-10-09 19:54:32',6,'invoice',NULL,'issued',750.00,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00005\",\"period\":\"Сентябрь 2026\"}',NULL),
(18,'2026-10-09 19:54:32',7,'invoice',NULL,'issued',750.00,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00006\",\"period\":\"Сентябрь 2026\"}',NULL),
(19,'2026-10-09 19:54:32',9,'invoice',NULL,'issued',750.00,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00007\",\"period\":\"Сентябрь 2026\"}',NULL),
(20,'2026-10-09 19:54:32',10,'invoice',NULL,'issued',750.00,-375.00,-375.00,'{\"charge_id\":2,\"number\":\"INV-2026-00008\",\"period\":\"Сентябрь 2026\"}',NULL),
(21,'2026-10-09 19:54:32',11,'invoice',NULL,'issued',750.00,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00009\",\"period\":\"Сентябрь 2026\"}',NULL),
(22,'2026-10-09 19:54:32',12,'invoice',NULL,'issued',750.00,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00010\",\"period\":\"Сентябрь 2026\"}',NULL),
(23,'2026-10-09 19:54:32',13,'invoice',NULL,'issued',750.00,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00011\",\"period\":\"Сентябрь 2026\"}',NULL),
(24,'2026-10-09 19:54:32',14,'invoice',NULL,'issued',750.00,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00012\",\"period\":\"Сентябрь 2026\"}',NULL),
(25,'2026-10-09 19:54:32',15,'invoice',NULL,'issued',750.00,-375.00,-375.00,'{\"charge_id\":2,\"number\":\"INV-2026-00013\",\"period\":\"Сентябрь 2026\"}',NULL),
(26,'2026-10-09 19:54:32',16,'invoice',NULL,'issued',750.00,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00014\",\"period\":\"Сентябрь 2026\"}',NULL),
(27,'2026-10-09 19:54:32',18,'invoice',NULL,'issued',750.00,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00015\",\"period\":\"Сентябрь 2026\"}',NULL),
(28,'2026-10-09 19:54:32',20,'invoice',NULL,'issued',750.00,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00016\",\"period\":\"Сентябрь 2026\"}',NULL),
(29,'2026-10-09 19:54:32',21,'invoice',NULL,'issued',750.00,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00017\",\"period\":\"Сентябрь 2026\"}',NULL),
(30,'2026-10-09 19:54:32',22,'invoice',NULL,'issued',750.00,-375.00,-375.00,'{\"charge_id\":2,\"number\":\"INV-2026-00018\",\"period\":\"Сентябрь 2026\"}',NULL),
(31,'2026-10-09 19:54:32',23,'invoice',NULL,'issued',750.00,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00019\",\"period\":\"Сентябрь 2026\"}',NULL),
(32,'2026-10-09 19:54:32',24,'invoice',NULL,'issued',750.00,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00020\",\"period\":\"Сентябрь 2026\"}',NULL),
(33,'2026-10-09 19:54:32',1,'payment',13,'paid',750.00,-150.00,-150.00,'{\"allocated\":[{\"invoice_id\":23,\"number\":\"INV-2026-00001\",\"applied\":750,\"status\":\"paid\"}],\"overpay\":0,\"method\":\"cash\"}',NULL),
(34,'2026-10-09 19:54:32',2,'payment',14,'paid',750.00,100.00,100.00,'{\"allocated\":[{\"invoice_id\":24,\"number\":\"INV-2026-00002\",\"applied\":750,\"status\":\"paid\"}],\"overpay\":0,\"method\":\"transfer\"}',NULL),
(35,'2026-10-09 19:54:32',1,'invoice',43,'adjusted',68.19,-150.00,-150.00,'{\"charge_id\":2,\"number\":\"INV-2026-00021-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(36,'2026-10-09 19:54:32',2,'invoice',44,'adjusted',68.19,100.00,100.00,'{\"charge_id\":2,\"number\":\"INV-2026-00022-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(37,'2026-10-09 19:54:32',3,'invoice',45,'adjusted',68.19,-375.00,-375.00,'{\"charge_id\":2,\"number\":\"INV-2026-00023-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(38,'2026-10-09 19:54:32',5,'invoice',46,'adjusted',68.19,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00024-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(39,'2026-10-09 19:54:32',6,'invoice',47,'adjusted',68.18,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00025-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(40,'2026-10-09 19:54:32',7,'invoice',48,'adjusted',68.18,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00026-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(41,'2026-10-09 19:54:32',9,'invoice',49,'adjusted',68.18,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00027-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(42,'2026-10-09 19:54:32',10,'invoice',50,'adjusted',68.18,-375.00,-375.00,'{\"charge_id\":2,\"number\":\"INV-2026-00028-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(43,'2026-10-09 19:54:32',11,'invoice',51,'adjusted',68.18,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00029-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(44,'2026-10-09 19:54:32',12,'invoice',52,'adjusted',68.18,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00030-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(45,'2026-10-09 19:54:32',13,'invoice',53,'adjusted',68.18,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00031-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(46,'2026-10-09 19:54:32',14,'invoice',54,'adjusted',68.18,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00032-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(47,'2026-10-09 19:54:32',15,'invoice',55,'adjusted',68.18,-375.00,-375.00,'{\"charge_id\":2,\"number\":\"INV-2026-00033-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(48,'2026-10-09 19:54:32',16,'invoice',56,'adjusted',68.18,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00034-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(49,'2026-10-09 19:54:32',18,'invoice',57,'adjusted',68.18,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00035-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(50,'2026-10-09 19:54:32',20,'invoice',58,'adjusted',68.18,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00036-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(51,'2026-10-09 19:54:32',21,'invoice',59,'adjusted',68.18,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00037-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(52,'2026-10-09 19:54:32',22,'invoice',60,'adjusted',68.18,-375.00,-375.00,'{\"charge_id\":2,\"number\":\"INV-2026-00038-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(53,'2026-10-09 19:54:32',23,'invoice',61,'adjusted',68.18,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00039-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(54,'2026-10-09 19:54:32',24,'invoice',62,'adjusted',68.18,-750.00,-750.00,'{\"charge_id\":2,\"number\":\"INV-2026-00040-Д\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(55,'2026-10-09 19:54:32',8,'invoice',63,'adjusted',818.18,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00041\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL),
(56,'2026-10-09 19:54:32',19,'invoice',64,'adjusted',818.18,0.00,0.00,'{\"charge_id\":2,\"number\":\"INV-2026-00042\",\"reason\":\"Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22\"}',NULL);
/*!40000 ALTER TABLE `billing_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cars`
--

DROP TABLE IF EXISTS `cars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cars` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `resident_id` bigint(20) unsigned NOT NULL,
  `plate` varchar(32) NOT NULL DEFAULT '',
  `plate_normalized` varchar(32) NOT NULL DEFAULT '',
  `brand` varchar(64) DEFAULT NULL,
  `model` varchar(64) DEFAULT NULL,
  `color` varchar(32) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `type` varchar(16) NOT NULL DEFAULT 'car',
  `rfid_tag` varchar(64) DEFAULT NULL,
  `sticker` varchar(32) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `valid_from` datetime DEFAULT NULL,
  `valid_until` datetime DEFAULT NULL,
  `notes` longtext DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cars_resident_id_index` (`resident_id`),
  KEY `cars_plate_normalized_index` (`plate_normalized`),
  KEY `cars_is_active_index` (`is_active`),
  CONSTRAINT `cars_resident_id_fk` FOREIGN KEY (`resident_id`) REFERENCES `residents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cars`
--

LOCK TABLES `cars` WRITE;
/*!40000 ALTER TABLE `cars` DISABLE KEYS */;
INSERT INTO `cars` VALUES
(1,1,'Х101НМ187','H101NM187','Nissan','Qashqai','серый',2019,'car','RFID-F35F1BD6',NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(2,2,'К997УА19','K997UA19','Renault','Duster','серебристый',2020,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(3,2,'О905ХВ120','O905HV120','Geely','Coolray','серебристый',2012,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(4,3,'К678ОН76','K678ON76','Chery','Tiggo 7','белый',2022,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(5,3,'С591ХМ173','S591HM173','Geely','Coolray','красный',2016,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(6,3,'У848РК196','U848RK196','Kia','Rio','красный',2022,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(7,4,'С234РХ158','S234RH158','Renault','Duster','серебристый',2019,'car','RFID-9FD7B426',NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(8,5,'Н140УК93','N140UK93','Hyundai','Solaris','серебристый',2012,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(9,5,'Е053ХХ190','E053HH190','Lada','Vesta','серебристый',2019,'car',NULL,NULL,0,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(10,6,'Т518КС152','T518KS152','Lada','Vesta','серый',2018,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(11,6,'В136УС41','V136US41','Hyundai','Solaris','белый',2022,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(12,6,'Т341ВК117','T341VK117','Skoda','Octavia','белый',2023,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(13,7,'У964ТЕ141','U964TE141','Renault','Duster','чёрный',2022,'car','RFID-E0853BBB',NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(14,8,'У506РС80','U506RS80','Renault','Duster','синий',2022,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(15,8,'Р033АЕ86','R033AE86','Toyota','Camry','чёрный',2018,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(16,9,'Н791ХА49','N791HA49','Hyundai','Solaris','синий',2016,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(17,9,'Н479СК24','N479SK24','Hyundai','Solaris','серый',2019,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(18,9,'Т467УК165','T467UK165','Haval','Jolion','красный',2012,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(19,10,'О097МН186','O097MN186','Hyundai','Solaris','серый',2013,'car','RFID-B09E4A70',NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(20,11,'М571ММ61','M571MM61','Chery','Tiggo 7','серый',2011,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(21,11,'К071ЕХ149','K071EH149','BMW','X5','синий',2014,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(22,12,'М852УН134','M852UN134','Nissan','Qashqai','чёрный',2025,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(23,12,'С456ЕН143','S456EN143','Toyota','Camry','красный',2010,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(24,12,'В415УК162','V415UK162','BMW','X5','серебристый',2015,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(25,13,'К001ММ121','K001MM121','Haval','Jolion','красный',2015,'car','RFID-BDC2D0DD',NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(26,14,'У614СС148','U614SS148','Toyota','Camry','синий',2011,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(27,14,'У048СВ44','U048SV44','Chery','Tiggo 7','чёрный',2023,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(28,15,'Т879ВН25','T879VN25','BMW','X5','серебристый',2023,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(29,15,'Е182УО192','E182UO192','Kia','Rio','белый',2025,'car',NULL,NULL,0,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(30,15,'О565РУ59','O565RU59','Chery','Tiggo 7','чёрный',2024,'car',NULL,NULL,0,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(31,16,'Т968СЕ53','T968SE53','Skoda','Octavia','синий',2017,'car','RFID-04CEE80E',NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(32,17,'М748СО121','M748SO121','Toyota','Camry','красный',2023,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(33,17,'М767ХА170','M767HA170','Renault','Duster','серебристый',2012,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(34,18,'А683МУ105','A683MU105','Skoda','Octavia','синий',2012,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(35,18,'Х199АВ34','H199AV34','Skoda','Octavia','белый',2020,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(36,18,'Т414СС105','T414SS105','Skoda','Octavia','серый',2020,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(37,19,'Н134РУ19','N134RU19','Hyundai','Solaris','серебристый',2024,'car','RFID-13E0FBAB',NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(38,20,'С629ТР23','S629TR23','Chery','Tiggo 7','серый',2010,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(39,20,'С106ЕТ93','S106ET93','Volkswagen','Polo','серебристый',2021,'car',NULL,NULL,0,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(40,21,'А362СТ135','A362ST135','Kia','Rio','белый',2024,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(41,21,'Х388РН84','H388RN84','Skoda','Octavia','белый',2015,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(42,21,'М410ОХ15','M410OH15','Nissan','Qashqai','серый',2021,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(43,22,'Х481МН55','H481MN55','Hyundai','Solaris','серый',2025,'car','RFID-E888AB48',NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(44,23,'Х055МА145','H055MA145','BMW','X5','серый',2020,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(45,23,'Х627АН65','H627AN65','Geely','Coolray','серебристый',2020,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(46,24,'Х753АУ159','H753AU159','Skoda','Octavia','чёрный',2024,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(47,24,'Н117КУ199','N117KU199','Volkswagen','Polo','синий',2012,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(48,24,'М390ХЕ183','M390HE183','Volkswagen','Polo','чёрный',2014,'car',NULL,NULL,1,NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30');
/*!40000 ALTER TABLE `cars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charges`
--

DROP TABLE IF EXISTS `charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `charges` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `number` varchar(48) NOT NULL DEFAULT '',
  `title` varchar(190) NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `period_start` date DEFAULT NULL,
  `period_end` date DEFAULT NULL,
  `period_label` varchar(64) NOT NULL DEFAULT '',
  `total_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `active_count` int(11) NOT NULL DEFAULT 0,
  `per_unit_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `allocation` varchar(16) NOT NULL DEFAULT 'equal',
  `due_days` int(11) NOT NULL DEFAULT 14,
  `due_date` date DEFAULT NULL,
  `message` longtext DEFAULT NULL,
  `pay_link` longtext DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'draft',
  `recalc_of` bigint(20) unsigned DEFAULT NULL,
  `recalc_reason` varchar(255) DEFAULT NULL,
  `invoices_total` int(11) NOT NULL DEFAULT 0,
  `invoices_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `paid_count` int(11) NOT NULL DEFAULT 0,
  `notes` longtext DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `issued_at` datetime DEFAULT NULL,
  `closed_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `charges_uuid_unique` (`uuid`),
  KEY `charges_status_index` (`status`),
  KEY `charges_period_start_index` (`period_start`),
  KEY `charges_recalc_of_index` (`recalc_of`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charges`
--

LOCK TABLES `charges` WRITE;
/*!40000 ALTER TABLE `charges` DISABLE KEYS */;
INSERT INTO `charges` VALUES
(1,'9e568b0a-47b4-46d1-bb7a-6fa90d975461','НАЧ-2026-09-0001','Обслуживание шлагбаума, Сентябрь 2026','Демо-начисление: обслуживание привода, видеонаблюдение, связь, ТО.','2026-09-01','2026-09-30','Сентябрь 2026',15000.00,20,750.00,'equal',14,'2026-10-14','Здравствуйте, {name}!\n\nНачислена оплата за обслуживание шлагбаума за {period}: {amount}.\nСрок оплаты: {due_date}.\n\nОплатить: {pay_link}','https://pay.example.com/barrier?apt={apartment}&amount={amount}','issued',NULL,NULL,22,15050.00,7500.00,8,NULL,NULL,'2026-09-30 00:00:00',NULL,'2026-09-30 00:00:00','2026-10-09 19:54:32'),
(2,'de0ee6a2-40f8-4e9c-816c-df2a96accf08','CHG-2026-0001','Smoke, Сентябрь 2026',NULL,'2026-09-01','2026-09-30','Сентябрь 2026',18000.00,22,818.18,'equal',14,'2026-10-23',NULL,NULL,'issued',NULL,'Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22',42,18000.00,1500.00,2,NULL,NULL,'2026-10-09 19:54:32',NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32');
/*!40000 ALTER TABLE `charges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `resident_id` bigint(20) unsigned NOT NULL,
  `type` varchar(16) NOT NULL DEFAULT 'phone',
  `value` varchar(190) NOT NULL DEFAULT '',
  `value_normalized` varchar(190) DEFAULT NULL,
  `label` varchar(40) DEFAULT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT 0,
  `notify` tinyint(1) NOT NULL DEFAULT 1,
  `verified` tinyint(1) NOT NULL DEFAULT 0,
  `verified_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contacts_resident_id_type_index` (`resident_id`,`type`),
  KEY `contacts_value_normalized_index` (`value_normalized`),
  CONSTRAINT `contacts_resident_id_fk` FOREIGN KEY (`resident_id`) REFERENCES `residents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` VALUES
(1,1,'phone','+79092335715','+79092335715','мобильный',1,1,1,NULL,'2026-10-09 19:54:30'),
(2,1,'phone','+79081301480','+79081301480','второй',0,1,1,NULL,'2026-10-09 19:54:30'),
(3,1,'phone','+74955242090','+74955242090','домашний',0,0,1,NULL,'2026-10-09 19:54:30'),
(4,1,'email','Ivanov.i1@example.com','ivanov.i1@example.com','основная',1,1,1,NULL,'2026-10-09 19:54:30'),
(5,1,'email','work.ivanov@company.example','work.ivanov@company.example','рабочая',0,0,1,NULL,'2026-10-09 19:54:30'),
(6,2,'phone','+79079136210','+79079136210','мобильный',1,1,0,NULL,'2026-10-09 19:54:30'),
(7,2,'email','Petrova.m2@example.com','petrova.m2@example.com','основная',1,1,0,NULL,'2026-10-09 19:54:30'),
(8,2,'telegram','@petrova2','@petrova2','telegram',1,1,0,NULL,'2026-10-09 19:54:30'),
(9,3,'phone','+79063911526','+79063911526','мобильный',1,1,0,NULL,'2026-10-09 19:54:30'),
(10,3,'phone','+79060590078','+79060590078','второй',0,1,0,NULL,'2026-10-09 19:54:30'),
(11,3,'email','Sidorov.a3@example.com','sidorov.a3@example.com','основная',1,1,0,NULL,'2026-10-09 19:54:30'),
(12,4,'phone','+79038283891','+79038283891','мобильный',1,1,1,NULL,'2026-10-09 19:54:30'),
(13,4,'phone','+74954511360','+74954511360','домашний',0,0,1,NULL,'2026-10-09 19:54:30'),
(14,4,'email','Kuznecova.o4@example.com','kuznecova.o4@example.com','основная',1,1,1,NULL,'2026-10-09 19:54:30'),
(15,4,'telegram','@kuznecova4','@kuznecova4','telegram',1,1,1,NULL,'2026-10-09 19:54:30'),
(16,5,'phone','+79077765350','+79077765350','мобильный',1,1,0,NULL,'2026-10-09 19:54:30'),
(17,5,'phone','+79046466020','+79046466020','второй',0,1,0,NULL,'2026-10-09 19:54:30'),
(18,5,'email','Smirnov.d5@example.com','smirnov.d5@example.com','основная',1,1,0,NULL,'2026-10-09 19:54:30'),
(19,5,'email','work.smirno@company.example','work.smirno@company.example','рабочая',0,0,0,NULL,'2026-10-09 19:54:30'),
(20,6,'phone','+79069345335','+79069345335','мобильный',1,1,0,NULL,'2026-10-09 19:54:30'),
(21,6,'email','Vasileva.a6@example.com','vasileva.a6@example.com','основная',1,1,0,NULL,'2026-10-09 19:54:30'),
(22,6,'telegram','@vasileva6','@vasileva6','telegram',1,1,0,NULL,'2026-10-09 19:54:30'),
(23,7,'phone','+79058386241','+79058386241','мобильный',1,1,1,NULL,'2026-10-09 19:54:30'),
(24,7,'phone','+79049654826','+79049654826','второй',0,1,1,NULL,'2026-10-09 19:54:30'),
(25,7,'phone','+74955694587','+74955694587','домашний',0,0,1,NULL,'2026-10-09 19:54:30'),
(26,7,'email','Sokolov.s7@example.com','sokolov.s7@example.com','основная',1,1,1,NULL,'2026-10-09 19:54:30'),
(27,8,'phone','+79027575380','+79027575380','мобильный',1,1,0,NULL,'2026-10-09 19:54:30'),
(28,8,'email','Mihaylova.e8@example.com','mihaylova.e8@example.com','основная',1,1,0,NULL,'2026-10-09 19:54:30'),
(29,8,'telegram','@mihaylova8','@mihaylova8','telegram',1,1,0,NULL,'2026-10-09 19:54:30'),
(30,9,'phone','+79091052626','+79091052626','мобильный',1,1,0,NULL,'2026-10-09 19:54:30'),
(31,9,'phone','+79065142619','+79065142619','второй',0,1,0,NULL,'2026-10-09 19:54:30'),
(32,9,'email','Fedorov.a9@example.com','fedorov.a9@example.com','основная',1,1,0,NULL,'2026-10-09 19:54:30'),
(33,9,'email','work.fedoro@company.example','work.fedoro@company.example','рабочая',0,0,0,NULL,'2026-10-09 19:54:30'),
(34,10,'phone','+79026889499','+79026889499','мобильный',1,1,1,NULL,'2026-10-09 19:54:30'),
(35,10,'phone','+74952297836','+74952297836','домашний',0,0,1,NULL,'2026-10-09 19:54:30'),
(36,10,'email','Morozova.n10@example.com','morozova.n10@example.com','основная',1,1,1,NULL,'2026-10-09 19:54:30'),
(37,10,'telegram','@morozova10','@morozova10','telegram',1,1,1,NULL,'2026-10-09 19:54:30'),
(38,11,'phone','+79023922895','+79023922895','мобильный',1,1,0,NULL,'2026-10-09 19:54:30'),
(39,11,'phone','+79014809599','+79014809599','второй',0,1,0,NULL,'2026-10-09 19:54:30'),
(40,11,'email','Volkov.p11@example.com','volkov.p11@example.com','основная',1,1,0,NULL,'2026-10-09 19:54:30'),
(41,12,'phone','+79092148503','+79092148503','мобильный',1,1,0,NULL,'2026-10-09 19:54:30'),
(42,12,'email','Alekseeva.e12@example.com','alekseeva.e12@example.com','основная',1,1,0,NULL,'2026-10-09 19:54:30'),
(43,12,'telegram','@alekseeva12','@alekseeva12','telegram',1,1,0,NULL,'2026-10-09 19:54:30'),
(44,13,'phone','+79063514435','+79063514435','мобильный',1,1,1,NULL,'2026-10-09 19:54:30'),
(45,13,'phone','+79041869795','+79041869795','второй',0,1,1,NULL,'2026-10-09 19:54:30'),
(46,13,'phone','+74955688490','+74955688490','домашний',0,0,1,NULL,'2026-10-09 19:54:30'),
(47,13,'email','Lebedev.n13@example.com','lebedev.n13@example.com','основная',1,1,1,NULL,'2026-10-09 19:54:30'),
(48,13,'email','work.lebede@company.example','work.lebede@company.example','рабочая',0,0,1,NULL,'2026-10-09 19:54:30'),
(49,14,'phone','+79082546520','+79082546520','мобильный',1,1,0,NULL,'2026-10-09 19:54:30'),
(50,14,'email','Semenova.t14@example.com','semenova.t14@example.com','основная',1,1,0,NULL,'2026-10-09 19:54:30'),
(51,14,'telegram','@semenova14','@semenova14','telegram',1,1,0,NULL,'2026-10-09 19:54:30'),
(52,15,'phone','+79024787652','+79024787652','мобильный',1,1,0,NULL,'2026-10-09 19:54:30'),
(53,15,'phone','+79065756448','+79065756448','второй',0,1,0,NULL,'2026-10-09 19:54:30'),
(54,15,'email','Egorov.v15@example.com','egorov.v15@example.com','основная',1,1,0,NULL,'2026-10-09 19:54:30'),
(55,16,'phone','+79041217404','+79041217404','мобильный',1,1,1,NULL,'2026-10-09 19:54:30'),
(56,16,'phone','+74957827416','+74957827416','домашний',0,0,1,NULL,'2026-10-09 19:54:30'),
(57,16,'email','Pavlova.y16@example.com','pavlova.y16@example.com','основная',1,1,1,NULL,'2026-10-09 19:54:30'),
(58,16,'telegram','@pavlova16','@pavlova16','telegram',1,1,1,NULL,'2026-10-09 19:54:30'),
(59,17,'phone','+79048484930','+79048484930','мобильный',1,1,0,NULL,'2026-10-09 19:54:30'),
(60,17,'phone','+79076310045','+79076310045','второй',0,1,0,NULL,'2026-10-09 19:54:30'),
(61,17,'email','Kozlov.i17@example.com','kozlov.i17@example.com','основная',1,1,0,NULL,'2026-10-09 19:54:30'),
(62,17,'email','work.kozlov@company.example','work.kozlov@company.example','рабочая',0,0,0,NULL,'2026-10-09 19:54:30'),
(63,18,'phone','+79061339372','+79061339372','мобильный',1,1,0,NULL,'2026-10-09 19:54:30'),
(64,18,'email','Stepanova.m18@example.com','stepanova.m18@example.com','основная',1,1,0,NULL,'2026-10-09 19:54:30'),
(65,18,'telegram','@stepanova18','@stepanova18','telegram',1,1,0,NULL,'2026-10-09 19:54:30'),
(66,19,'phone','+79049666810','+79049666810','мобильный',1,1,1,NULL,'2026-10-09 19:54:30'),
(67,19,'phone','+79041629918','+79041629918','второй',0,1,1,NULL,'2026-10-09 19:54:30'),
(68,19,'phone','+74956712240','+74956712240','домашний',0,0,1,NULL,'2026-10-09 19:54:30'),
(69,19,'email','Nikolaev.a19@example.com','nikolaev.a19@example.com','основная',1,1,1,NULL,'2026-10-09 19:54:30'),
(70,20,'phone','+79078834953','+79078834953','мобильный',1,1,0,NULL,'2026-10-09 19:54:30'),
(71,20,'email','Orlova.o20@example.com','orlova.o20@example.com','основная',1,1,0,NULL,'2026-10-09 19:54:30'),
(72,20,'telegram','@orlova20','@orlova20','telegram',1,1,0,NULL,'2026-10-09 19:54:30'),
(73,21,'phone','+79072541424','+79072541424','мобильный',1,1,0,NULL,'2026-10-09 19:54:30'),
(74,21,'phone','+79032618485','+79032618485','второй',0,1,0,NULL,'2026-10-09 19:54:30'),
(75,21,'email','Andreev.d21@example.com','andreev.d21@example.com','основная',1,1,0,NULL,'2026-10-09 19:54:30'),
(76,21,'email','work.andree@company.example','work.andree@company.example','рабочая',0,0,0,NULL,'2026-10-09 19:54:30'),
(77,22,'phone','+79075481733','+79075481733','мобильный',1,1,1,NULL,'2026-10-09 19:54:30'),
(78,22,'phone','+74955847255','+74955847255','домашний',0,0,1,NULL,'2026-10-09 19:54:30'),
(79,22,'email','Makarova.a22@example.com','makarova.a22@example.com','основная',1,1,1,NULL,'2026-10-09 19:54:30'),
(80,22,'telegram','@makarova22','@makarova22','telegram',1,1,1,NULL,'2026-10-09 19:54:30'),
(81,23,'phone','+79072570629','+79072570629','мобильный',1,1,0,NULL,'2026-10-09 19:54:30'),
(82,23,'phone','+79092122208','+79092122208','второй',0,1,0,NULL,'2026-10-09 19:54:30'),
(83,23,'email','Zaharov.s23@example.com','zaharov.s23@example.com','основная',1,1,0,NULL,'2026-10-09 19:54:30'),
(84,24,'phone','+79098009940','+79098009940','мобильный',1,1,0,NULL,'2026-10-09 19:54:30'),
(85,24,'email','Zayceva.e24@example.com','zayceva.e24@example.com','основная',1,1,0,NULL,'2026-10-09 19:54:30'),
(86,24,'telegram','@zayceva24','@zayceva24','telegram',1,1,0,NULL,'2026-10-09 19:54:30');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `devices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL DEFAULT '',
  `slug` varchar(64) NOT NULL DEFAULT '',
  `driver` varchar(24) NOT NULL DEFAULT 'basip',
  `base_url` varchar(255) DEFAULT NULL,
  `login` varchar(120) DEFAULT NULL,
  `password_enc` longtext DEFAULT NULL,
  `channel` int(11) NOT NULL DEFAULT 1,
  `location` varchar(190) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `options` longtext DEFAULT NULL,
  `last_seen_at` datetime DEFAULT NULL,
  `last_status` longtext DEFAULT NULL,
  `error_count` int(11) NOT NULL DEFAULT 0,
  `notes` longtext DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `devices_slug_unique` (`slug`),
  KEY `devices_is_active_index` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devices`
--

LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `export_jobs`
--

DROP TABLE IF EXISTS `export_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `export_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `kind` varchar(32) NOT NULL DEFAULT 'residents',
  `format` varchar(12) NOT NULL DEFAULT 'csv',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `rows` int(11) NOT NULL DEFAULT 0,
  `size_bytes` int(11) NOT NULL DEFAULT 0,
  `filters` longtext DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `export_jobs_uuid_unique` (`uuid`),
  KEY `export_jobs_created_at_index` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `export_jobs`
--

LOCK TABLES `export_jobs` WRITE;
/*!40000 ALTER TABLE `export_jobs` DISABLE KEYS */;
INSERT INTO `export_jobs` VALUES
(1,'563fc842-2bd8-43f0-8c8d-1b011ff20116','residents','csv','residents-20261009-195438.csv',24,9782,'{\"status\":\"all\"}',NULL,NULL,'2026-10-09 19:54:38','2026-10-10 19:54:38'),
(2,'1cfa2df5-d098-488d-9471-1c5368d7db02','residents','json','residents-20261009-195438.json',24,96985,'{\"status\":\"all\"}',NULL,NULL,'2026-10-09 19:54:38','2026-10-10 19:54:38');
/*!40000 ALTER TABLE `export_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gate_events`
--

DROP TABLE IF EXISTS `gate_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gate_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `occurred_at` datetime DEFAULT NULL,
  `device_id` bigint(20) unsigned DEFAULT NULL,
  `channel` int(11) NOT NULL DEFAULT 1,
  `actor_type` varchar(24) NOT NULL DEFAULT 'system',
  `resident_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `guest_pass_id` bigint(20) unsigned DEFAULT NULL,
  `actor_name` varchar(190) DEFAULT NULL,
  `apartment` varchar(24) DEFAULT NULL,
  `access_type` varchar(24) NOT NULL DEFAULT 'own',
  `action` varchar(16) NOT NULL DEFAULT 'open',
  `source` varchar(24) NOT NULL DEFAULT 'web',
  `result` varchar(16) NOT NULL DEFAULT 'success',
  `reason` varchar(190) DEFAULT NULL,
  `plate` varchar(32) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(512) DEFAULT NULL,
  `request_id` varchar(32) DEFAULT NULL,
  `duration_ms` int(11) DEFAULT NULL,
  `device_response` longtext DEFAULT NULL,
  `meta` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gate_events_occurred_at_index` (`occurred_at`),
  KEY `gate_events_resident_id_occurred_at_index` (`resident_id`,`occurred_at`),
  KEY `gate_events_access_type_occurred_at_index` (`access_type`,`occurred_at`),
  KEY `gate_events_result_index` (`result`),
  KEY `gate_events_guest_pass_id_index` (`guest_pass_id`),
  KEY `gate_events_device_id_occurred_at_index` (`device_id`,`occurred_at`)
) ENGINE=InnoDB AUTO_INCREMENT=430 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gate_events`
--

LOCK TABLES `gate_events` WRITE;
/*!40000 ALTER TABLE `gate_events` DISABLE KEYS */;
INSERT INTO `gate_events` VALUES
(1,'9149b6c9-74a0-462e-a0b3-75e2fc53a5c8','2026-09-10 13:40:01',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','own','open','web','success',NULL,NULL,'192.168.1.105',NULL,NULL,673,NULL,'{\"demo\":true}'),
(2,'98b14903-643c-41c7-8f98-44e8a8bf792d','2026-09-10 14:07:20',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','own','open','api','success',NULL,NULL,'192.168.1.85',NULL,NULL,518,NULL,'{\"demo\":true}'),
(3,'713b92a8-16c9-4081-81e3-e1b9d69aabad','2026-09-10 18:10:40',NULL,1,'admin',10,NULL,NULL,'Морозова Наталья Петрович','10','manual','open','cabinet','success',NULL,NULL,'192.168.1.124',NULL,NULL,454,NULL,'{\"demo\":true}'),
(4,'68b1a03c-f6e3-477b-9dd1-1ae7e61b6f41','2026-09-10 06:49:56',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','plate','open','telegram','success',NULL,NULL,'192.168.1.116',NULL,NULL,668,NULL,'{\"demo\":true}'),
(5,'9be77a56-0bdc-43cb-9af0-882d36a59134','2026-09-10 15:17:46',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','own','open','telegram','success',NULL,NULL,'192.168.1.21',NULL,NULL,246,NULL,'{\"demo\":true}'),
(6,'a7eedc68-6aa9-477a-ad48-eb9855b2ecfd','2026-09-10 10:30:46',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','plate','open','telegram','success',NULL,NULL,'192.168.1.209',NULL,NULL,451,NULL,'{\"demo\":true}'),
(7,'5dcdbd3a-5865-4468-bc3b-73c51800a225','2026-09-10 20:35:32',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','own','open','api','success',NULL,NULL,'192.168.1.237',NULL,NULL,196,NULL,'{\"demo\":true}'),
(8,'9ae737f0-6e7c-4f2c-a136-a8a481281aa8','2026-09-10 06:36:46',NULL,1,'admin',17,NULL,NULL,'Козлов Иван Иванович','17','manual','open','admin','success',NULL,NULL,'192.168.1.188',NULL,NULL,716,NULL,'{\"demo\":true}'),
(9,'a51cedb9-2d87-4c13-a830-eed1c792d66f','2026-09-10 21:01:44',NULL,1,'admin',18,NULL,NULL,'Степанова Мария Петрович','18','manual','open','web','success',NULL,NULL,'192.168.1.227',NULL,NULL,164,NULL,'{\"demo\":true}'),
(10,'20853339-f6cf-4122-8bed-391960b0d004','2026-09-11 21:52:37',NULL,1,'admin',1,NULL,NULL,'Иванов Иван Иванович','1','manual','open','web','success',NULL,NULL,'192.168.1.129',NULL,NULL,631,NULL,'{\"demo\":true}'),
(11,'21e36bb7-a9a2-4766-a5e8-db17c2d5b60c','2026-09-11 13:01:51',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','plate','open','web','success',NULL,NULL,'192.168.1.116',NULL,NULL,247,NULL,'{\"demo\":true}'),
(12,'87ded278-9ae8-4b85-b21f-29d68a9ddacc','2026-09-11 12:19:35',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','own','open','web','success',NULL,NULL,'192.168.1.109',NULL,NULL,332,NULL,'{\"demo\":true}'),
(13,'0df3a9a4-2512-432e-a882-a91fe50abec2','2026-09-11 21:33:11',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','own','open','telegram','success',NULL,NULL,'192.168.1.100',NULL,NULL,425,NULL,'{\"demo\":true}'),
(14,'c1454333-1bb3-47a3-8892-a774a9015360','2026-09-12 09:15:29',NULL,1,'resident',14,NULL,NULL,'Семёнова Татьяна Петровна','14','plate','open','web','success',NULL,NULL,'192.168.1.141',NULL,NULL,683,NULL,'{\"demo\":true}'),
(15,'61df33fb-c794-405f-b616-7aedef89b38e','2026-09-12 22:17:22',NULL,1,'resident',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','own','open','api','success',NULL,NULL,'192.168.1.109',NULL,NULL,719,NULL,'{\"demo\":true}'),
(16,'c08fd46d-4bb4-450d-a434-e14431392731','2026-09-12 15:41:29',NULL,1,'guest',6,NULL,NULL,'Васильева Анна Петровна','6','guest','open','api','success',NULL,NULL,'192.168.1.62',NULL,NULL,617,NULL,'{\"demo\":true}'),
(17,'e327b392-ef3f-494b-bcd1-90f1cfe022a9','2026-09-12 19:24:21',NULL,1,'resident',15,NULL,NULL,'Егоров Виктор Сергеевна','15','plate','open','web','success',NULL,NULL,'192.168.1.179',NULL,NULL,164,NULL,'{\"demo\":true}'),
(18,'af29fadf-815e-433a-9afa-4de2ca1d7760','2026-09-12 07:44:46',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','own','open','cabinet','success',NULL,NULL,'192.168.1.146',NULL,NULL,185,NULL,'{\"demo\":true}'),
(19,'cdb3628b-ef85-4b62-a073-83f82b641d0f','2026-09-12 23:30:35',NULL,1,'admin',14,NULL,NULL,'Семёнова Татьяна Петровна','14','manual','open','api','success',NULL,NULL,'192.168.1.125',NULL,NULL,762,NULL,'{\"demo\":true}'),
(20,'9eb96a58-04fd-4e70-928a-ccdf6902c2d9','2026-09-12 14:13:44',NULL,1,'admin',7,NULL,NULL,'Соколов Сергей Сергеевна','7','manual','open','telegram','success',NULL,NULL,'192.168.1.175',NULL,NULL,258,NULL,'{\"demo\":true}'),
(21,'067a42d4-88ee-4200-9322-67f4ab13a335','2026-09-12 12:41:16',NULL,1,'guest',10,NULL,NULL,'Морозова Наталья Петрович','10','guest','open','web','success',NULL,NULL,'192.168.1.192',NULL,NULL,499,NULL,'{\"demo\":true}'),
(22,'e9403617-5109-45b9-b100-09a394a6b3b3','2026-09-12 07:58:17',NULL,1,'resident',20,NULL,NULL,'Орлова Ольга Андреевич','20','own','open','web','success',NULL,NULL,'192.168.1.146',NULL,NULL,309,NULL,'{\"demo\":true}'),
(23,'c05093ae-fe6d-4113-963b-ec0fb3f8e0f6','2026-09-12 07:46:30',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','own','open','cabinet','success',NULL,NULL,'192.168.1.175',NULL,NULL,392,NULL,'{\"demo\":true}'),
(24,'11afb2d9-ff7f-462b-ab82-215b9ad56c5a','2026-09-12 14:13:42',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','own','open','telegram','success',NULL,NULL,'192.168.1.164',NULL,NULL,850,NULL,'{\"demo\":true}'),
(25,'ee0b08b5-8425-48b5-a45d-7cf0d8b04446','2026-09-12 17:22:05',NULL,1,'guest',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','guest','open','cabinet','success',NULL,NULL,'192.168.1.221',NULL,NULL,609,NULL,'{\"demo\":true}'),
(26,'ca5b2098-a346-43dc-8e79-35318b0c1b73','2026-09-12 22:13:42',NULL,1,'resident',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','own','open','admin','success',NULL,NULL,'192.168.1.143',NULL,NULL,383,NULL,'{\"demo\":true}'),
(27,'11fe1026-da1d-4b77-a705-b958573218a4','2026-09-12 19:44:43',NULL,1,'resident',11,NULL,NULL,'Волков Павел Сергеевич','11','own','open','cabinet','success',NULL,NULL,'192.168.1.219',NULL,NULL,332,NULL,'{\"demo\":true}'),
(28,'cad03fb4-c55a-4988-aec8-664b409b792c','2026-09-12 11:18:54',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','plate','open','web','success',NULL,NULL,'192.168.1.245',NULL,NULL,233,NULL,'{\"demo\":true}'),
(29,'69fdf058-29dd-4b77-aae1-917808ad6c8b','2026-09-13 23:10:39',NULL,1,'admin',19,NULL,NULL,'Николаев Алексей Сергеевич','19','manual','denied','telegram','denied','Превышен лимит открытий',NULL,'192.168.1.31',NULL,NULL,457,NULL,'{\"demo\":true}'),
(30,'49e4c9b6-4e5f-496f-a2ca-d72bf65753f0','2026-09-13 13:05:48',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','own','open','web','success',NULL,NULL,'192.168.1.83',NULL,NULL,196,NULL,'{\"demo\":true}'),
(31,'54ddba40-c8fd-44d4-8dc9-686978f3161f','2026-09-13 10:18:11',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','own','open','web','success',NULL,NULL,'192.168.1.110',NULL,NULL,856,NULL,'{\"demo\":true}'),
(32,'8307bc55-a55b-4fa4-ab3c-9cfce3ba814d','2026-09-13 09:15:01',NULL,1,'admin',18,NULL,NULL,'Степанова Мария Петрович','18','manual','open','api','success',NULL,NULL,'192.168.1.212',NULL,NULL,623,NULL,'{\"demo\":true}'),
(33,'536331a1-3f68-4465-a221-5d9e5da34378','2026-09-13 10:40:19',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','web','success',NULL,NULL,'192.168.1.167',NULL,NULL,673,NULL,'{\"demo\":true}'),
(34,'21874189-992f-43b3-8d53-ec95e029fd69','2026-09-13 20:08:02',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','own','open','admin','success',NULL,NULL,'192.168.1.216',NULL,NULL,271,NULL,'{\"demo\":true}'),
(35,'da289692-3811-4559-af19-9a67156fc55c','2026-09-13 15:41:44',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','own','open','api','success',NULL,NULL,'192.168.1.197',NULL,NULL,733,NULL,'{\"demo\":true}'),
(36,'d3fc9447-6d7d-4593-b3c6-dd54b2defbd2','2026-09-13 06:56:33',NULL,1,'resident',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','plate','open','admin','success',NULL,NULL,'192.168.1.245',NULL,NULL,356,NULL,'{\"demo\":true}'),
(37,'125ece3a-4973-4c0d-97b8-7d8de97cc4fe','2026-09-13 18:59:44',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','own','open','cabinet','success',NULL,NULL,'192.168.1.74',NULL,NULL,167,NULL,'{\"demo\":true}'),
(38,'659993aa-86dd-4af8-8e9b-413c811f3c6a','2026-09-13 09:18:33',NULL,1,'resident',6,NULL,NULL,'Васильева Анна Петровна','6','plate','open','telegram','success',NULL,NULL,'192.168.1.91',NULL,NULL,895,NULL,'{\"demo\":true}'),
(39,'17315dd8-6ff0-4f9f-8743-d0f153cfafa6','2026-09-13 19:09:12',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','own','open','api','success',NULL,NULL,'192.168.1.211',NULL,NULL,247,NULL,'{\"demo\":true}'),
(40,'87997516-4d58-411b-a303-f02e38069468','2026-09-13 19:02:00',NULL,1,'resident',6,NULL,NULL,'Васильева Анна Петровна','6','own','open','web','success',NULL,NULL,'192.168.1.20',NULL,NULL,462,NULL,'{\"demo\":true}'),
(41,'0dd934f7-8181-46ca-ab50-2372053e0d6f','2026-09-13 14:08:34',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','telegram','success',NULL,NULL,'192.168.1.191',NULL,NULL,141,NULL,'{\"demo\":true}'),
(42,'6606a9dc-e441-4cef-a68b-3d9a24d72b09','2026-09-13 21:13:06',NULL,1,'resident',22,NULL,NULL,'Макарова Анна Петровна','22','own','open','telegram','success',NULL,NULL,'192.168.1.38',NULL,NULL,165,NULL,'{\"demo\":true}'),
(43,'291d255a-971d-466b-a769-ab8d30403cac','2026-09-13 06:26:53',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','plate','open','cabinet','success',NULL,NULL,'192.168.1.132',NULL,NULL,763,NULL,'{\"demo\":true}'),
(44,'af533e39-d309-46bc-9209-844966510a65','2026-09-13 20:59:43',NULL,1,'guest',2,NULL,NULL,'Петрова Мария Петрович','2','guest','denied','cabinet','denied','Доступ приостановлен',NULL,'192.168.1.50',NULL,NULL,758,NULL,'{\"demo\":true}'),
(45,'16713334-c4db-4909-86ea-8c9ccebd64e3','2026-09-13 16:11:14',NULL,1,'resident',8,NULL,NULL,'Михайлова Елена Николаевич','8','plate','denied','telegram','denied','Доступ приостановлен',NULL,'192.168.1.147',NULL,NULL,123,NULL,'{\"demo\":true}'),
(46,'2255f382-5617-4809-80c5-d01929b77551','2026-09-13 17:56:48',NULL,1,'resident',6,NULL,NULL,'Васильева Анна Петровна','6','plate','open','api','success',NULL,NULL,'192.168.1.181',NULL,NULL,728,NULL,'{\"demo\":true}'),
(47,'ba8c4642-f421-4eaf-a300-4a8c6c414a34','2026-09-13 11:52:51',NULL,1,'guest',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','guest','open','api','success',NULL,NULL,'192.168.1.86',NULL,NULL,303,NULL,'{\"demo\":true}'),
(48,'a02a4098-c667-4532-b50d-7ccfe2109608','2026-09-13 21:44:32',NULL,1,'guest',8,NULL,NULL,'Михайлова Елена Николаевич','8','guest','open','admin','success',NULL,NULL,'192.168.1.34',NULL,NULL,412,NULL,'{\"demo\":true}'),
(49,'5f5bb391-a2e1-4ae3-84c0-168ce9eb5028','2026-09-13 07:59:35',NULL,1,'resident',8,NULL,NULL,'Михайлова Елена Николаевич','8','own','open','api','success',NULL,NULL,'192.168.1.176',NULL,NULL,478,NULL,'{\"demo\":true}'),
(50,'19198a77-ba1d-4f04-b1a6-c5eb5888aa4f','2026-09-13 11:45:10',NULL,1,'resident',1,NULL,NULL,'Иванов Иван Иванович','1','plate','open','admin','success',NULL,NULL,'192.168.1.138',NULL,NULL,205,NULL,'{\"demo\":true}'),
(51,'4461b0a2-9f98-47d0-8174-c4566bdc3c4f','2026-09-14 19:51:49',NULL,1,'admin',6,NULL,NULL,'Васильева Анна Петровна','6','manual','open','api','success',NULL,NULL,'192.168.1.165',NULL,NULL,868,NULL,'{\"demo\":true}'),
(52,'f1f6495a-c49e-4210-8d00-cfd76c185c87','2026-09-14 18:57:36',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','own','open','telegram','success',NULL,NULL,'192.168.1.65',NULL,NULL,639,NULL,'{\"demo\":true}'),
(53,'2ebc77b8-1859-4829-a2c3-889d1a353448','2026-09-14 10:01:41',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','plate','open','cabinet','success',NULL,NULL,'192.168.1.99',NULL,NULL,477,NULL,'{\"demo\":true}'),
(54,'a75700e9-1d4a-42e2-857b-b7f8da91578a','2026-09-14 13:28:32',NULL,1,'resident',15,NULL,NULL,'Егоров Виктор Сергеевна','15','plate','open','admin','success',NULL,NULL,'192.168.1.174',NULL,NULL,732,NULL,'{\"demo\":true}'),
(55,'675753fa-480d-426f-ae33-d3c18ac1ece8','2026-09-14 21:28:21',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','own','open','web','success',NULL,NULL,'192.168.1.159',NULL,NULL,551,NULL,'{\"demo\":true}'),
(56,'3710a2ec-38af-497b-ad47-9a36563db300','2026-09-14 18:41:06',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','admin','success',NULL,NULL,'192.168.1.180',NULL,NULL,839,NULL,'{\"demo\":true}'),
(57,'13364207-1549-422a-a341-cdf2b53034c6','2026-09-14 18:54:07',NULL,1,'guest',6,NULL,NULL,'Васильева Анна Петровна','6','guest','open','admin','success',NULL,NULL,'192.168.1.240',NULL,NULL,481,NULL,'{\"demo\":true}'),
(58,'bc97f873-12de-4222-97e1-b6d4fcf7431f','2026-09-14 08:52:16',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','plate','open','api','success',NULL,NULL,'192.168.1.36',NULL,NULL,719,NULL,'{\"demo\":true}'),
(59,'3e5de57f-ef76-4004-a0a4-25a7f955c8c7','2026-09-14 09:44:12',NULL,1,'guest',23,NULL,NULL,'Захаров Сергей Сергеевна','23','guest','open','telegram','success',NULL,NULL,'192.168.1.227',NULL,NULL,739,NULL,'{\"demo\":true}'),
(60,'ef26d859-d1fd-4109-b7a6-2dac924c2679','2026-09-14 15:10:58',NULL,1,'admin',9,NULL,NULL,'Фёдоров Андрей Иванович','9','manual','open','admin','success',NULL,NULL,'192.168.1.228',NULL,NULL,424,NULL,'{\"demo\":true}'),
(61,'f2183c40-2ae8-4fca-a642-afd2bb112ee6','2026-09-14 11:30:52',NULL,1,'resident',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','own','open','api','success',NULL,NULL,'192.168.1.57',NULL,NULL,351,NULL,'{\"demo\":true}'),
(62,'91135c40-a7e0-4193-8285-401b07c5ae52','2026-09-14 22:51:05',NULL,1,'admin',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','manual','open','admin','success',NULL,NULL,'192.168.1.156',NULL,NULL,162,NULL,'{\"demo\":true}'),
(63,'ff74b723-13fc-4ba2-a492-3a1a25322315','2026-09-15 23:23:50',NULL,1,'resident',8,NULL,NULL,'Михайлова Елена Николаевич','8','own','open','admin','success',NULL,NULL,'192.168.1.241',NULL,NULL,246,NULL,'{\"demo\":true}'),
(64,'860ecf0e-1f20-4578-8c01-d07b9b5101de','2026-09-15 23:18:15',NULL,1,'resident',1,NULL,NULL,'Иванов Иван Иванович','1','own','denied','admin','denied','Тихие часы',NULL,'192.168.1.101',NULL,NULL,175,NULL,'{\"demo\":true}'),
(65,'a869684f-4fc1-4ce7-adaf-a528f3503ad4','2026-09-15 22:05:51',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','denied','api','denied','Тихие часы',NULL,'192.168.1.160',NULL,NULL,163,NULL,'{\"demo\":true}'),
(66,'c1d278ff-950a-4615-af54-ec593a1abe1b','2026-09-15 08:40:27',NULL,1,'admin',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','manual','open','cabinet','success',NULL,NULL,'192.168.1.187',NULL,NULL,644,NULL,'{\"demo\":true}'),
(67,'5fd64e86-ea8d-471b-a416-0a17d5b6e7f7','2026-09-15 12:10:06',NULL,1,'resident',8,NULL,NULL,'Михайлова Елена Николаевич','8','own','open','cabinet','success',NULL,NULL,'192.168.1.158',NULL,NULL,440,NULL,'{\"demo\":true}'),
(68,'19aa31c8-1179-4b6f-bd45-6a192d1c1dc0','2026-09-15 06:01:21',NULL,1,'guest',16,NULL,NULL,'Павлова Юлия Николаевич','16','guest','open','admin','success',NULL,NULL,'192.168.1.105',NULL,NULL,247,NULL,'{\"demo\":true}'),
(69,'fdfd97ac-5485-43ad-9b33-0d00dbf5360d','2026-09-15 15:10:07',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','own','open','api','success',NULL,NULL,'192.168.1.20',NULL,NULL,797,NULL,'{\"demo\":true}'),
(70,'f4ca7e03-e1ac-4b0e-932d-65c5154e8109','2026-09-15 07:41:03',NULL,1,'admin',11,NULL,NULL,'Волков Павел Сергеевич','11','manual','open','api','success',NULL,NULL,'192.168.1.23',NULL,NULL,250,NULL,'{\"demo\":true}'),
(71,'3991106c-cfaf-447a-aa4b-e1ff15c38679','2026-09-15 12:24:44',NULL,1,'admin',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','manual','open','web','success',NULL,NULL,'192.168.1.230',NULL,NULL,689,NULL,'{\"demo\":true}'),
(72,'2b27776c-0140-4a3b-bcaf-76ea3a426fdf','2026-09-15 17:34:17',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','cabinet','success',NULL,NULL,'192.168.1.193',NULL,NULL,288,NULL,'{\"demo\":true}'),
(73,'81c926a3-86ca-40df-8e0b-dcd8e625883d','2026-09-15 08:16:41',NULL,1,'guest',9,NULL,NULL,'Фёдоров Андрей Иванович','9','guest','open','admin','success',NULL,NULL,'192.168.1.163',NULL,NULL,140,NULL,'{\"demo\":true}'),
(74,'d02b2969-7d28-4f56-be9e-e6ea71ab26f7','2026-09-15 10:34:22',NULL,1,'resident',8,NULL,NULL,'Михайлова Елена Николаевич','8','own','open','admin','success',NULL,NULL,'192.168.1.101',NULL,NULL,242,NULL,'{\"demo\":true}'),
(75,'9bc5fdb8-8051-49f4-b3bc-b2baffcca06c','2026-09-15 23:30:26',NULL,1,'resident',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','plate','open','api','success',NULL,NULL,'192.168.1.236',NULL,NULL,794,NULL,'{\"demo\":true}'),
(76,'6806cb87-3638-4e71-998d-5e3a03d398cd','2026-09-16 21:52:28',NULL,1,'guest',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','guest','open','web','success',NULL,NULL,'192.168.1.123',NULL,NULL,315,NULL,'{\"demo\":true}'),
(77,'db9b5d03-123f-41f5-bc23-bc3e4f7dd4c8','2026-09-16 12:53:40',NULL,1,'admin',9,NULL,NULL,'Фёдоров Андрей Иванович','9','manual','open','api','success',NULL,NULL,'192.168.1.161',NULL,NULL,553,NULL,'{\"demo\":true}'),
(78,'b4263d10-19e7-45c5-9f34-3d11e92ddfb3','2026-09-16 14:41:30',NULL,1,'resident',15,NULL,NULL,'Егоров Виктор Сергеевна','15','plate','open','api','success',NULL,NULL,'192.168.1.155',NULL,NULL,220,NULL,'{\"demo\":true}'),
(79,'f8a30d1a-5125-485a-9922-527330096f73','2026-09-16 10:26:01',NULL,1,'resident',20,NULL,NULL,'Орлова Ольга Андреевич','20','own','open','cabinet','success',NULL,NULL,'192.168.1.28',NULL,NULL,894,NULL,'{\"demo\":true}'),
(80,'1beb4422-5b48-43f6-a82a-687604255ec3','2026-09-16 10:58:57',NULL,1,'resident',14,NULL,NULL,'Семёнова Татьяна Петровна','14','own','open','cabinet','success',NULL,NULL,'192.168.1.175',NULL,NULL,779,NULL,'{\"demo\":true}'),
(81,'5e08809b-f709-4233-b21f-7f2ddfe8bc8c','2026-09-16 12:34:13',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','plate','open','web','success',NULL,NULL,'192.168.1.54',NULL,NULL,652,NULL,'{\"demo\":true}'),
(82,'104a4500-6eff-4131-87f1-7f22314137ba','2026-09-16 13:18:22',NULL,1,'guest',19,NULL,NULL,'Николаев Алексей Сергеевич','19','guest','open','cabinet','success',NULL,NULL,'192.168.1.123',NULL,NULL,489,NULL,'{\"demo\":true}'),
(83,'43e7645b-ff9a-4c0a-b914-f4c1a24f84db','2026-09-16 17:58:34',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','own','open','web','success',NULL,NULL,'192.168.1.71',NULL,NULL,563,NULL,'{\"demo\":true}'),
(84,'2d84227d-68aa-4c36-8339-f3daaeef60ac','2026-09-16 23:14:55',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','cabinet','success',NULL,NULL,'192.168.1.237',NULL,NULL,770,NULL,'{\"demo\":true}'),
(85,'b7fb954c-d1d8-4943-8526-b8f65fbb38b4','2026-09-16 20:34:09',NULL,1,'resident',11,NULL,NULL,'Волков Павел Сергеевич','11','own','open','api','success',NULL,NULL,'192.168.1.103',NULL,NULL,849,NULL,'{\"demo\":true}'),
(86,'1b227702-7b94-4a2d-abdb-881b42ea161d','2026-09-16 16:23:50',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','own','open','api','success',NULL,NULL,'192.168.1.32',NULL,NULL,680,NULL,'{\"demo\":true}'),
(87,'10835d55-f25c-4a4e-9560-1f0e6a7a34c3','2026-09-16 11:15:41',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','own','open','telegram','success',NULL,NULL,'192.168.1.68',NULL,NULL,183,NULL,'{\"demo\":true}'),
(88,'179182eb-8299-446c-b2bb-9e2e47eb1dc3','2026-09-16 13:15:39',NULL,1,'resident',22,NULL,NULL,'Макарова Анна Петровна','22','own','open','telegram','success',NULL,NULL,'192.168.1.103',NULL,NULL,327,NULL,'{\"demo\":true}'),
(89,'ceee9dfa-8585-4a95-9357-18cf409578a3','2026-09-16 13:47:44',NULL,1,'guest',24,NULL,NULL,'Зайцева Елена Николаевич','24','guest','open','cabinet','success',NULL,NULL,'192.168.1.79',NULL,NULL,726,NULL,'{\"demo\":true}'),
(90,'196e624a-57cd-4bb8-8790-735caa7bcae9','2026-09-16 07:50:04',NULL,1,'guest',15,NULL,NULL,'Егоров Виктор Сергеевна','15','guest','open','web','success',NULL,NULL,'192.168.1.42',NULL,NULL,830,NULL,'{\"demo\":true}'),
(91,'8e730bf3-3cd4-43c6-8005-4515b63a90e4','2026-09-17 12:11:06',NULL,1,'resident',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','plate','denied','cabinet','denied','Превышен лимит открытий',NULL,'192.168.1.244',NULL,NULL,855,NULL,'{\"demo\":true}'),
(92,'8a5247de-3da8-4039-97e3-58f1f9be6fc0','2026-09-17 09:29:44',NULL,1,'guest',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','guest','open','telegram','success',NULL,NULL,'192.168.1.217',NULL,NULL,683,NULL,'{\"demo\":true}'),
(93,'f36f0e77-595b-40ac-8525-cb8a27b8ce2a','2026-09-17 09:06:57',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','own','denied','admin','denied','Доступ приостановлен',NULL,'192.168.1.50',NULL,NULL,760,NULL,'{\"demo\":true}'),
(94,'fe1079ba-d303-4218-b13a-0b81a6576196','2026-09-17 16:37:34',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','open','telegram','success',NULL,NULL,'192.168.1.64',NULL,NULL,505,NULL,'{\"demo\":true}'),
(95,'51f4d4b0-8cbd-446e-8be8-cdb55c342b3d','2026-09-17 14:30:25',NULL,1,'resident',20,NULL,NULL,'Орлова Ольга Андреевич','20','own','open','admin','success',NULL,NULL,'192.168.1.157',NULL,NULL,550,NULL,'{\"demo\":true}'),
(96,'72ce07de-54d5-4033-838e-1500dceac0a4','2026-09-17 10:33:34',NULL,1,'resident',15,NULL,NULL,'Егоров Виктор Сергеевна','15','own','open','api','success',NULL,NULL,'192.168.1.128',NULL,NULL,788,NULL,'{\"demo\":true}'),
(97,'ba5a4c58-23b2-4cde-8221-0424be15dc80','2026-09-17 08:47:51',NULL,1,'admin',15,NULL,NULL,'Егоров Виктор Сергеевна','15','manual','open','telegram','success',NULL,NULL,'192.168.1.177',NULL,NULL,529,NULL,'{\"demo\":true}'),
(98,'da8d7284-f1be-487d-88e6-1a8209295fe6','2026-09-17 10:25:58',NULL,1,'admin',19,NULL,NULL,'Николаев Алексей Сергеевич','19','manual','open','admin','success',NULL,NULL,'192.168.1.76',NULL,NULL,709,NULL,'{\"demo\":true}'),
(99,'a389ae65-e38c-406c-a59f-2e112841ee52','2026-09-17 07:56:12',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','plate','open','telegram','success',NULL,NULL,'192.168.1.231',NULL,NULL,772,NULL,'{\"demo\":true}'),
(100,'ac10e822-d741-4db8-98c0-e4ae03612e7b','2026-09-17 18:08:06',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','own','denied','telegram','denied','Превышен лимит открытий',NULL,'192.168.1.89',NULL,NULL,823,NULL,'{\"demo\":true}'),
(101,'cfd87eb4-b107-4f97-88cf-09f2d8571d73','2026-09-17 11:26:11',NULL,1,'guest',24,NULL,NULL,'Зайцева Елена Николаевич','24','guest','open','cabinet','success',NULL,NULL,'192.168.1.201',NULL,NULL,147,NULL,'{\"demo\":true}'),
(102,'cfd8462e-b787-4fe6-8446-f4b6f9b364eb','2026-09-17 12:57:20',NULL,1,'guest',23,NULL,NULL,'Захаров Сергей Сергеевна','23','guest','open','web','success',NULL,NULL,'192.168.1.230',NULL,NULL,489,NULL,'{\"demo\":true}'),
(103,'84a4fa46-e80f-4e0e-8eb4-6f77ea2aaeaa','2026-09-17 15:06:14',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','own','open','admin','success',NULL,NULL,'192.168.1.149',NULL,NULL,539,NULL,'{\"demo\":true}'),
(104,'2a2d2724-ba6d-4afd-b9f6-903d8941b752','2026-09-17 18:45:37',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','own','open','telegram','success',NULL,NULL,'192.168.1.154',NULL,NULL,691,NULL,'{\"demo\":true}'),
(105,'a50b7db4-eb0f-460f-903a-f15ecb7a25d6','2026-09-17 23:28:23',NULL,1,'admin',16,NULL,NULL,'Павлова Юлия Николаевич','16','manual','open','telegram','success',NULL,NULL,'192.168.1.34',NULL,NULL,246,NULL,'{\"demo\":true}'),
(106,'3d8ea840-8004-41df-8085-a084f7d6e0e9','2026-09-17 22:35:09',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','own','denied','api','denied','Доступ приостановлен',NULL,'192.168.1.220',NULL,NULL,606,NULL,'{\"demo\":true}'),
(107,'16b2a54b-4798-42fe-bf5f-617dbada38d6','2026-09-17 17:47:02',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','plate','open','cabinet','success',NULL,NULL,'192.168.1.37',NULL,NULL,876,NULL,'{\"demo\":true}'),
(108,'6af22950-a68e-4af9-bd47-b913e3a14438','2026-09-17 09:56:55',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','plate','open','api','success',NULL,NULL,'192.168.1.166',NULL,NULL,362,NULL,'{\"demo\":true}'),
(109,'2cfe479e-17bf-4203-9556-0b2350048926','2026-09-18 23:40:59',NULL,1,'resident',8,NULL,NULL,'Михайлова Елена Николаевич','8','own','open','api','success',NULL,NULL,'192.168.1.166',NULL,NULL,203,NULL,'{\"demo\":true}'),
(110,'cc61fc4e-fe81-42a4-bf7d-c4473df0e358','2026-09-18 08:56:34',NULL,1,'admin',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','manual','open','cabinet','success',NULL,NULL,'192.168.1.150',NULL,NULL,424,NULL,'{\"demo\":true}'),
(111,'e1375ea9-d0b5-4944-8360-ac2af2adbcd8','2026-09-18 16:32:58',NULL,1,'resident',11,NULL,NULL,'Волков Павел Сергеевич','11','own','open','admin','success',NULL,NULL,'192.168.1.99',NULL,NULL,385,NULL,'{\"demo\":true}'),
(112,'ce57e023-756a-4143-9e7b-8d08798362f8','2026-09-18 09:53:43',NULL,1,'guest',15,NULL,NULL,'Егоров Виктор Сергеевна','15','guest','open','api','success',NULL,NULL,'192.168.1.57',NULL,NULL,599,NULL,'{\"demo\":true}'),
(113,'2bd2a44a-09fe-4b8b-ba75-e6665c12db56','2026-09-18 10:45:43',NULL,1,'admin',10,NULL,NULL,'Морозова Наталья Петрович','10','manual','open','cabinet','success',NULL,NULL,'192.168.1.97',NULL,NULL,239,NULL,'{\"demo\":true}'),
(114,'5e24b4bb-04e2-435a-a5b2-2825a70e3e76','2026-09-18 21:34:34',NULL,1,'resident',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','own','open','telegram','success',NULL,NULL,'192.168.1.246',NULL,NULL,730,NULL,'{\"demo\":true}'),
(115,'de898a42-0075-41f5-9f8d-dabcf009a172','2026-09-18 10:57:50',NULL,1,'resident',15,NULL,NULL,'Егоров Виктор Сергеевна','15','plate','open','admin','success',NULL,NULL,'192.168.1.162',NULL,NULL,614,NULL,'{\"demo\":true}'),
(116,'5c8529e6-2da4-417a-9658-2de7f21c03b6','2026-09-18 21:13:47',NULL,1,'admin',14,NULL,NULL,'Семёнова Татьяна Петровна','14','manual','open','telegram','success',NULL,NULL,'192.168.1.223',NULL,NULL,808,NULL,'{\"demo\":true}'),
(117,'1b4cf36e-5a71-44f5-ad6e-3f14fdc57ad0','2026-09-18 17:47:12',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','own','open','telegram','success',NULL,NULL,'192.168.1.34',NULL,NULL,655,NULL,'{\"demo\":true}'),
(118,'20219ab4-1b06-4ba8-b6cd-d8972c2de55c','2026-09-18 17:38:58',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','open','cabinet','success',NULL,NULL,'192.168.1.114',NULL,NULL,150,NULL,'{\"demo\":true}'),
(119,'2dd2d08d-9d8d-4f6e-8742-50e9c44903eb','2026-09-18 10:45:46',NULL,1,'resident',6,NULL,NULL,'Васильева Анна Петровна','6','own','open','api','success',NULL,NULL,'192.168.1.139',NULL,NULL,891,NULL,'{\"demo\":true}'),
(120,'0a814d75-bed9-405b-bc24-7e3157aea056','2026-09-18 11:47:59',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','open','web','success',NULL,NULL,'192.168.1.221',NULL,NULL,274,NULL,'{\"demo\":true}'),
(121,'886479d2-795e-4070-8243-07bab06a9cd4','2026-09-18 20:45:47',NULL,1,'guest',8,NULL,NULL,'Михайлова Елена Николаевич','8','guest','open','api','success',NULL,NULL,'192.168.1.56',NULL,NULL,646,NULL,'{\"demo\":true}'),
(122,'1de6804f-e261-4f39-a17c-d1f317305872','2026-09-18 14:58:45',NULL,1,'guest',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','guest','open','cabinet','success',NULL,NULL,'192.168.1.22',NULL,NULL,398,NULL,'{\"demo\":true}'),
(123,'89e4ac67-e0c7-47a4-a629-fdf03eee7aee','2026-09-19 21:42:42',NULL,1,'resident',20,NULL,NULL,'Орлова Ольга Андреевич','20','own','open','web','success',NULL,NULL,'192.168.1.248',NULL,NULL,406,NULL,'{\"demo\":true}'),
(124,'fcc53ca4-15b6-48be-87b5-44ee76de9ead','2026-09-19 18:49:43',NULL,1,'admin',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','manual','open','admin','success',NULL,NULL,'192.168.1.230',NULL,NULL,487,NULL,'{\"demo\":true}'),
(125,'1c2566a4-2e5a-41b8-9d30-0f1c3827b203','2026-09-19 08:17:53',NULL,1,'guest',14,NULL,NULL,'Семёнова Татьяна Петровна','14','guest','open','admin','success',NULL,NULL,'192.168.1.140',NULL,NULL,534,NULL,'{\"demo\":true}'),
(126,'200a4668-3125-43ab-88e3-211a7024c110','2026-09-19 08:56:12',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','own','open','api','success',NULL,NULL,'192.168.1.23',NULL,NULL,783,NULL,'{\"demo\":true}'),
(127,'e201d6a6-f50e-4b16-9ce3-3081eee02507','2026-09-19 14:53:36',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','own','open','cabinet','success',NULL,NULL,'192.168.1.84',NULL,NULL,477,NULL,'{\"demo\":true}'),
(128,'d5c385a2-704d-4cd7-9a3f-228edfe68dd1','2026-09-19 21:38:34',NULL,1,'admin',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','manual','open','web','success',NULL,NULL,'192.168.1.207',NULL,NULL,697,NULL,'{\"demo\":true}'),
(129,'b4a76e32-d2e8-4fb0-8b6c-57c1b05b19f1','2026-09-19 23:44:53',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','own','open','cabinet','success',NULL,NULL,'192.168.1.191',NULL,NULL,807,NULL,'{\"demo\":true}'),
(130,'28d5b272-35db-40d1-93c5-1d265f5bad1e','2026-09-19 06:13:50',NULL,1,'resident',22,NULL,NULL,'Макарова Анна Петровна','22','plate','open','web','success',NULL,NULL,'192.168.1.49',NULL,NULL,887,NULL,'{\"demo\":true}'),
(131,'5ebe3944-7994-478d-afe5-f8ae18ddb40d','2026-09-19 10:40:09',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','plate','open','admin','success',NULL,NULL,'192.168.1.235',NULL,NULL,552,NULL,'{\"demo\":true}'),
(132,'c5272402-36ea-443e-a7be-cc769c741d38','2026-09-19 12:40:53',NULL,1,'resident',22,NULL,NULL,'Макарова Анна Петровна','22','own','open','cabinet','success',NULL,NULL,'192.168.1.155',NULL,NULL,384,NULL,'{\"demo\":true}'),
(133,'d574bd63-d0e9-4440-b7d3-c97838ac2920','2026-09-19 10:12:49',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','web','success',NULL,NULL,'192.168.1.200',NULL,NULL,389,NULL,'{\"demo\":true}'),
(134,'706595e1-f564-4b1d-84d9-a5ca27cbc588','2026-09-19 23:55:47',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','telegram','success',NULL,NULL,'192.168.1.249',NULL,NULL,691,NULL,'{\"demo\":true}'),
(135,'627e78ca-bec7-4e5b-b3a1-f9a2ee27d9d4','2026-09-19 12:24:41',NULL,1,'resident',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','own','open','cabinet','success',NULL,NULL,'192.168.1.221',NULL,NULL,294,NULL,'{\"demo\":true}'),
(136,'48b4d588-bd8d-4176-97f6-1202653f9002','2026-09-19 22:27:31',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','open','telegram','success',NULL,NULL,'192.168.1.137',NULL,NULL,771,NULL,'{\"demo\":true}'),
(137,'f3598ff7-5b11-450f-9781-cfe3147803d6','2026-09-20 21:57:28',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','own','denied','api','denied','Тихие часы',NULL,'192.168.1.237',NULL,NULL,800,NULL,'{\"demo\":true}'),
(138,'610360d6-cd27-439e-8964-6fdf7ccea8b4','2026-09-20 08:43:24',NULL,1,'admin',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','manual','open','cabinet','success',NULL,NULL,'192.168.1.90',NULL,NULL,204,NULL,'{\"demo\":true}'),
(139,'8ac8dd9c-73b6-4488-a538-43dd1d1868ef','2026-09-20 22:13:12',NULL,1,'admin',9,NULL,NULL,'Фёдоров Андрей Иванович','9','manual','open','cabinet','success',NULL,NULL,'192.168.1.91',NULL,NULL,479,NULL,'{\"demo\":true}'),
(140,'8e0a82e7-94e0-4334-a8da-755d035bc841','2026-09-20 16:26:18',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','plate','open','admin','success',NULL,NULL,'192.168.1.61',NULL,NULL,723,NULL,'{\"demo\":true}'),
(141,'23e2b462-08b6-47c3-b78f-d890c7ca2285','2026-09-20 22:10:43',NULL,1,'guest',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','guest','open','admin','success',NULL,NULL,'192.168.1.102',NULL,NULL,352,NULL,'{\"demo\":true}'),
(142,'8a95c047-5849-4e47-8d71-0cb9db3751af','2026-09-20 17:27:58',NULL,1,'resident',8,NULL,NULL,'Михайлова Елена Николаевич','8','own','open','web','success',NULL,NULL,'192.168.1.48',NULL,NULL,302,NULL,'{\"demo\":true}'),
(143,'00f4e4e0-d0d5-44ef-8182-4ab936c431d3','2026-09-20 19:25:53',NULL,1,'admin',6,NULL,NULL,'Васильева Анна Петровна','6','manual','open','admin','success',NULL,NULL,'192.168.1.187',NULL,NULL,261,NULL,'{\"demo\":true}'),
(144,'ad9e860e-c2ca-4432-ad15-6ac771818a68','2026-09-20 14:55:11',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','web','success',NULL,NULL,'192.168.1.232',NULL,NULL,733,NULL,'{\"demo\":true}'),
(145,'755afdbd-5b55-4c9a-8498-253127c88e05','2026-09-20 09:46:00',NULL,1,'resident',11,NULL,NULL,'Волков Павел Сергеевич','11','own','open','admin','success',NULL,NULL,'192.168.1.220',NULL,NULL,661,NULL,'{\"demo\":true}'),
(146,'4f8f0674-622b-45f8-b556-35e41c57ff01','2026-09-20 06:10:41',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','own','open','admin','success',NULL,NULL,'192.168.1.163',NULL,NULL,347,NULL,'{\"demo\":true}'),
(147,'b17e6e6c-a2b4-4c5f-848e-8c697dcc1eac','2026-09-20 20:10:34',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','own','open','telegram','success',NULL,NULL,'192.168.1.224',NULL,NULL,280,NULL,'{\"demo\":true}'),
(148,'c8ce8293-96d5-4392-a95a-8555fc6c79b1','2026-09-20 14:12:56',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','own','open','telegram','success',NULL,NULL,'192.168.1.108',NULL,NULL,486,NULL,'{\"demo\":true}'),
(149,'692dc2f0-fe8c-42a3-bf56-045843e8da16','2026-09-20 22:48:20',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','own','denied','cabinet','denied','Доступ приостановлен',NULL,'192.168.1.74',NULL,NULL,484,NULL,'{\"demo\":true}'),
(150,'51235571-33ff-4dbe-880c-ba9b6bd6bdd9','2026-09-20 11:29:52',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','own','open','admin','success',NULL,NULL,'192.168.1.202',NULL,NULL,172,NULL,'{\"demo\":true}'),
(151,'da435f45-fd83-41ef-9183-c528959eb129','2026-09-20 15:48:17',NULL,1,'resident',16,NULL,NULL,'Павлова Юлия Николаевич','16','own','open','telegram','success',NULL,NULL,'192.168.1.200',NULL,NULL,314,NULL,'{\"demo\":true}'),
(152,'fa687b0c-1d03-4b8f-9402-ac274e681ab4','2026-09-20 19:28:57',NULL,1,'admin',10,NULL,NULL,'Морозова Наталья Петрович','10','manual','open','api','success',NULL,NULL,'192.168.1.26',NULL,NULL,272,NULL,'{\"demo\":true}'),
(153,'8b197e81-ad50-486c-9695-18abc9dec709','2026-09-20 10:49:09',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','plate','open','telegram','success',NULL,NULL,'192.168.1.183',NULL,NULL,900,NULL,'{\"demo\":true}'),
(154,'2ab8afd4-3e17-4729-b638-527d8ef380ea','2026-09-20 21:26:41',NULL,1,'resident',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','own','open','api','success',NULL,NULL,'192.168.1.50',NULL,NULL,738,NULL,'{\"demo\":true}'),
(155,'2766a01a-a22a-4750-9393-5388457aa40a','2026-09-20 15:49:08',NULL,1,'resident',6,NULL,NULL,'Васильева Анна Петровна','6','plate','open','web','success',NULL,NULL,'192.168.1.33',NULL,NULL,417,NULL,'{\"demo\":true}'),
(156,'bab73e98-a305-4c47-a9b3-2b347e4e3bd5','2026-09-20 21:44:01',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','own','open','cabinet','success',NULL,NULL,'192.168.1.151',NULL,NULL,340,NULL,'{\"demo\":true}'),
(157,'d2afefa8-cc25-4799-8b79-0672ab5a5935','2026-09-21 11:24:13',NULL,1,'resident',16,NULL,NULL,'Павлова Юлия Николаевич','16','own','open','admin','success',NULL,NULL,'192.168.1.145',NULL,NULL,402,NULL,'{\"demo\":true}'),
(158,'ec17b6a1-6966-48a6-b23a-1c8e9afe1aec','2026-09-21 12:12:29',NULL,1,'admin',13,NULL,NULL,'Лебедев Николай Ивановна','13','manual','open','admin','success',NULL,NULL,'192.168.1.41',NULL,NULL,701,NULL,'{\"demo\":true}'),
(159,'cdf7c5f7-184c-4597-b7cb-c5ba660028fe','2026-09-21 16:42:29',NULL,1,'admin',24,NULL,NULL,'Зайцева Елена Николаевич','24','manual','denied','web','denied','Тихие часы',NULL,'192.168.1.233',NULL,NULL,576,NULL,'{\"demo\":true}'),
(160,'ef7d3873-f695-4221-8249-824f396302c8','2026-09-21 09:42:03',NULL,1,'admin',24,NULL,NULL,'Зайцева Елена Николаевич','24','manual','open','cabinet','success',NULL,NULL,'192.168.1.48',NULL,NULL,600,NULL,'{\"demo\":true}'),
(161,'854316d7-5d16-4d97-b4a9-e407d0bd3590','2026-09-21 11:43:02',NULL,1,'guest',1,NULL,NULL,'Иванов Иван Иванович','1','guest','open','api','success',NULL,NULL,'192.168.1.20',NULL,NULL,522,NULL,'{\"demo\":true}'),
(162,'9e5bb599-6e97-4463-8fd9-e8c22f62fed1','2026-09-21 10:56:29',NULL,1,'admin',7,NULL,NULL,'Соколов Сергей Сергеевна','7','manual','open','admin','success',NULL,NULL,'192.168.1.221',NULL,NULL,369,NULL,'{\"demo\":true}'),
(163,'064d528b-001e-4e51-a093-df7885e42660','2026-09-21 08:42:51',NULL,1,'guest',7,NULL,NULL,'Соколов Сергей Сергеевна','7','guest','open','cabinet','success',NULL,NULL,'192.168.1.104',NULL,NULL,565,NULL,'{\"demo\":true}'),
(164,'854178f8-bfc1-44ac-8e12-63e16552d1ba','2026-09-21 11:17:47',NULL,1,'guest',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','guest','open','admin','success',NULL,NULL,'192.168.1.171',NULL,NULL,846,NULL,'{\"demo\":true}'),
(165,'2cc0f79c-af45-4aac-96a2-b98b73e603f4','2026-09-21 12:58:34',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','web','success',NULL,NULL,'192.168.1.218',NULL,NULL,300,NULL,'{\"demo\":true}'),
(166,'565eb6ba-17e2-4d49-8093-d2b46e503599','2026-09-21 15:19:38',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','plate','open','admin','success',NULL,NULL,'192.168.1.123',NULL,NULL,499,NULL,'{\"demo\":true}'),
(167,'d100337a-0bbd-4421-9e23-a3c58fcc71fa','2026-09-21 10:26:56',NULL,1,'guest',18,NULL,NULL,'Степанова Мария Петрович','18','guest','denied','telegram','denied','Тихие часы',NULL,'192.168.1.60',NULL,NULL,327,NULL,'{\"demo\":true}'),
(168,'726223cb-7469-410d-8c05-672d5ac767bd','2026-09-21 22:53:42',NULL,1,'resident',11,NULL,NULL,'Волков Павел Сергеевич','11','plate','open','admin','success',NULL,NULL,'192.168.1.85',NULL,NULL,716,NULL,'{\"demo\":true}'),
(169,'8212f937-efd4-41cb-9567-58eaf589f4e6','2026-09-21 07:01:08',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','own','open','admin','success',NULL,NULL,'192.168.1.95',NULL,NULL,366,NULL,'{\"demo\":true}'),
(170,'48060768-cea7-46a5-b539-1f1ca9126dcf','2026-09-21 10:36:34',NULL,1,'guest',17,NULL,NULL,'Козлов Иван Иванович','17','guest','open','api','success',NULL,NULL,'192.168.1.50',NULL,NULL,345,NULL,'{\"demo\":true}'),
(171,'03924a6e-833a-4f42-9e38-6b0e189de821','2026-09-21 23:37:49',NULL,1,'guest',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','guest','open','telegram','success',NULL,NULL,'192.168.1.86',NULL,NULL,131,NULL,'{\"demo\":true}'),
(172,'d7e3996b-ef41-4cbd-9b4d-79a868b72907','2026-09-21 09:26:56',NULL,1,'admin',23,NULL,NULL,'Захаров Сергей Сергеевна','23','manual','open','admin','success',NULL,NULL,'192.168.1.41',NULL,NULL,683,NULL,'{\"demo\":true}'),
(173,'99041ffd-e553-4e60-a28b-9f589d659912','2026-09-22 16:49:37',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','plate','open','cabinet','success',NULL,NULL,'192.168.1.177',NULL,NULL,865,NULL,'{\"demo\":true}'),
(174,'51c765c8-43b2-438e-9c84-93b5f2d4ecb9','2026-09-22 16:00:45',NULL,1,'resident',15,NULL,NULL,'Егоров Виктор Сергеевна','15','plate','open','telegram','success',NULL,NULL,'192.168.1.184',NULL,NULL,828,NULL,'{\"demo\":true}'),
(175,'590dfc30-38f3-43ac-9301-989d52d01392','2026-09-22 11:54:51',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','own','open','admin','success',NULL,NULL,'192.168.1.100',NULL,NULL,530,NULL,'{\"demo\":true}'),
(176,'3fee7038-d49a-40b3-952e-c3e37187dbe4','2026-09-22 16:08:58',NULL,1,'resident',11,NULL,NULL,'Волков Павел Сергеевич','11','own','open','admin','success',NULL,NULL,'192.168.1.90',NULL,NULL,514,NULL,'{\"demo\":true}'),
(177,'e4ea3614-1081-43bb-931f-ae127209c132','2026-09-22 13:01:51',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','open','api','success',NULL,NULL,'192.168.1.86',NULL,NULL,331,NULL,'{\"demo\":true}'),
(178,'cded682e-c335-4472-a609-705f51b3062e','2026-09-22 15:49:41',NULL,1,'admin',6,NULL,NULL,'Васильева Анна Петровна','6','manual','open','telegram','success',NULL,NULL,'192.168.1.114',NULL,NULL,562,NULL,'{\"demo\":true}'),
(179,'e06f7f6c-6462-471a-85de-8cc51584fbca','2026-09-22 22:18:43',NULL,1,'admin',19,NULL,NULL,'Николаев Алексей Сергеевич','19','manual','open','cabinet','success',NULL,NULL,'192.168.1.134',NULL,NULL,546,NULL,'{\"demo\":true}'),
(180,'6f3e83df-caba-4628-9749-6fd4e77056e3','2026-09-22 17:36:53',NULL,1,'guest',8,NULL,NULL,'Михайлова Елена Николаевич','8','guest','open','admin','success',NULL,NULL,'192.168.1.34',NULL,NULL,123,NULL,'{\"demo\":true}'),
(181,'7c7307c6-b36f-409b-9e80-08b7b00cfeb5','2026-09-22 13:35:01',NULL,1,'admin',10,NULL,NULL,'Морозова Наталья Петрович','10','manual','open','cabinet','success',NULL,NULL,'192.168.1.75',NULL,NULL,585,NULL,'{\"demo\":true}'),
(182,'3cc7b4de-729f-40a4-b11c-47a535f530cd','2026-09-22 21:51:29',NULL,1,'guest',14,NULL,NULL,'Семёнова Татьяна Петровна','14','guest','denied','telegram','denied','Доступ приостановлен',NULL,'192.168.1.125',NULL,NULL,704,NULL,'{\"demo\":true}'),
(183,'b686f1b2-d061-4dc7-b443-713df6ebd4ca','2026-09-22 08:18:44',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','own','open','cabinet','success',NULL,NULL,'192.168.1.195',NULL,NULL,751,NULL,'{\"demo\":true}'),
(184,'94e6d834-aece-4443-9b3c-5ce1308d5575','2026-09-23 17:57:02',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','plate','open','telegram','success',NULL,NULL,'192.168.1.152',NULL,NULL,782,NULL,'{\"demo\":true}'),
(185,'b0ef1fc2-bda0-4767-ba20-f475996f792a','2026-09-23 11:26:48',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','plate','open','telegram','success',NULL,NULL,'192.168.1.121',NULL,NULL,620,NULL,'{\"demo\":true}'),
(186,'e9ea660d-3487-40f1-a983-27660ff3a93e','2026-09-23 12:39:49',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','own','open','telegram','success',NULL,NULL,'192.168.1.23',NULL,NULL,283,NULL,'{\"demo\":true}'),
(187,'ccda264c-1231-4486-b8fa-3964d6a4c4e9','2026-09-23 08:03:47',NULL,1,'guest',23,NULL,NULL,'Захаров Сергей Сергеевна','23','guest','open','api','success',NULL,NULL,'192.168.1.195',NULL,NULL,316,NULL,'{\"demo\":true}'),
(188,'575abc7e-2164-43a7-ab10-c70a8124f289','2026-09-23 23:34:07',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','own','open','cabinet','success',NULL,NULL,'192.168.1.242',NULL,NULL,395,NULL,'{\"demo\":true}'),
(189,'dd558547-c420-4a2d-8a33-8cbc4400824c','2026-09-23 11:51:46',NULL,1,'admin',24,NULL,NULL,'Зайцева Елена Николаевич','24','manual','open','cabinet','success',NULL,NULL,'192.168.1.185',NULL,NULL,701,NULL,'{\"demo\":true}'),
(190,'af8aa9eb-453f-44b8-a640-39cd4700fbad','2026-09-23 06:58:57',NULL,1,'resident',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','own','open','admin','success',NULL,NULL,'192.168.1.88',NULL,NULL,303,NULL,'{\"demo\":true}'),
(191,'d2314423-f805-4e43-894d-9d9a516c60c0','2026-09-23 09:37:13',NULL,1,'resident',6,NULL,NULL,'Васильева Анна Петровна','6','own','open','web','success',NULL,NULL,'192.168.1.87',NULL,NULL,405,NULL,'{\"demo\":true}'),
(192,'a37d13f6-d40a-4920-a520-ada3a48a2801','2026-09-23 18:23:10',NULL,1,'resident',16,NULL,NULL,'Павлова Юлия Николаевич','16','own','open','telegram','success',NULL,NULL,'192.168.1.229',NULL,NULL,582,NULL,'{\"demo\":true}'),
(193,'3b16034d-5e84-4d2c-99bf-ce240de632eb','2026-09-23 21:28:56',NULL,1,'resident',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','own','open','admin','success',NULL,NULL,'192.168.1.223',NULL,NULL,142,NULL,'{\"demo\":true}'),
(194,'8c3891cc-16b5-4774-92ce-dc27146727ae','2026-09-23 22:47:32',NULL,1,'admin',2,NULL,NULL,'Петрова Мария Петрович','2','manual','open','admin','success',NULL,NULL,'192.168.1.156',NULL,NULL,152,NULL,'{\"demo\":true}'),
(195,'9b784587-bdd4-41fc-84e2-ac70a0418cb3','2026-09-23 08:37:45',NULL,1,'resident',6,NULL,NULL,'Васильева Анна Петровна','6','plate','open','api','success',NULL,NULL,'192.168.1.193',NULL,NULL,755,NULL,'{\"demo\":true}'),
(196,'6d5f8698-f5ed-4850-8422-2c9606ee7d5e','2026-09-23 14:18:27',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','own','open','cabinet','success',NULL,NULL,'192.168.1.83',NULL,NULL,769,NULL,'{\"demo\":true}'),
(197,'8589f65b-8d6f-4e47-b421-34fe15eeffa4','2026-09-23 20:55:53',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','own','open','cabinet','success',NULL,NULL,'192.168.1.212',NULL,NULL,469,NULL,'{\"demo\":true}'),
(198,'ef3479e3-5345-4efb-94ac-7f03442ae9bd','2026-09-23 11:38:35',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','plate','open','cabinet','success',NULL,NULL,'192.168.1.152',NULL,NULL,637,NULL,'{\"demo\":true}'),
(199,'f9d893df-2ae5-4548-8590-2957315d4e00','2026-09-23 21:32:06',NULL,1,'resident',6,NULL,NULL,'Васильева Анна Петровна','6','own','open','telegram','success',NULL,NULL,'192.168.1.191',NULL,NULL,712,NULL,'{\"demo\":true}'),
(200,'65b47a66-e2e4-4c40-8c48-a61aa903e95a','2026-09-23 07:51:03',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','own','open','telegram','success',NULL,NULL,'192.168.1.191',NULL,NULL,275,NULL,'{\"demo\":true}'),
(201,'9941dcf1-308f-496b-8d2c-678e632f30be','2026-09-23 21:17:07',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','plate','open','admin','success',NULL,NULL,'192.168.1.32',NULL,NULL,778,NULL,'{\"demo\":true}'),
(202,'4abc4749-873f-4b49-b9f3-38c714dc4b0c','2026-09-23 18:42:52',NULL,1,'admin',19,NULL,NULL,'Николаев Алексей Сергеевич','19','manual','open','web','success',NULL,NULL,'192.168.1.44',NULL,NULL,722,NULL,'{\"demo\":true}'),
(203,'040f0df9-dd40-4669-b687-636f11efa542','2026-09-23 22:05:38',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','cabinet','success',NULL,NULL,'192.168.1.20',NULL,NULL,528,NULL,'{\"demo\":true}'),
(204,'8ff319f6-1823-4b8a-83ae-fc3317e9e8c9','2026-09-23 19:35:09',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','api','success',NULL,NULL,'192.168.1.90',NULL,NULL,684,NULL,'{\"demo\":true}'),
(205,'a7c4da43-44be-4c1e-8fd1-f874fa87f58b','2026-09-23 07:22:04',NULL,1,'resident',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','own','open','api','success',NULL,NULL,'192.168.1.82',NULL,NULL,618,NULL,'{\"demo\":true}'),
(206,'8e3a35a5-982e-4ae3-9fdb-b4218cabd6bf','2026-09-24 12:14:00',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','own','open','admin','success',NULL,NULL,'192.168.1.199',NULL,NULL,234,NULL,'{\"demo\":true}'),
(207,'f3ed97ba-3a98-4b81-b730-031a309922de','2026-09-24 18:19:51',NULL,1,'guest',2,NULL,NULL,'Петрова Мария Петрович','2','guest','open','telegram','success',NULL,NULL,'192.168.1.220',NULL,NULL,190,NULL,'{\"demo\":true}'),
(208,'100f2188-fa7c-4751-ab27-2d29bb1e100a','2026-09-24 19:06:08',NULL,1,'admin',17,NULL,NULL,'Козлов Иван Иванович','17','manual','open','api','success',NULL,NULL,'192.168.1.20',NULL,NULL,298,NULL,'{\"demo\":true}'),
(209,'6187eec4-7c05-4ab4-a665-66ffd70ec6bd','2026-09-24 10:22:52',NULL,1,'resident',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','plate','open','web','success',NULL,NULL,'192.168.1.151',NULL,NULL,729,NULL,'{\"demo\":true}'),
(210,'6f84859c-a063-4f4b-932b-675a1769cd25','2026-09-24 09:26:54',NULL,1,'admin',17,NULL,NULL,'Козлов Иван Иванович','17','manual','denied','web','denied','Тихие часы',NULL,'192.168.1.162',NULL,NULL,581,NULL,'{\"demo\":true}'),
(211,'16b282ea-38ff-43bd-a222-2bae4e0f243b','2026-09-24 09:40:20',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','own','denied','admin','denied','Доступ приостановлен',NULL,'192.168.1.65',NULL,NULL,419,NULL,'{\"demo\":true}'),
(212,'55ebd1d1-9a80-4742-a690-48f0ffe595b5','2026-09-24 16:05:54',NULL,1,'admin',23,NULL,NULL,'Захаров Сергей Сергеевна','23','manual','open','web','success',NULL,NULL,'192.168.1.86',NULL,NULL,424,NULL,'{\"demo\":true}'),
(213,'7890e7ff-2319-4438-8e9e-f9bd9b35150b','2026-09-24 12:44:20',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','own','open','cabinet','success',NULL,NULL,'192.168.1.234',NULL,NULL,863,NULL,'{\"demo\":true}'),
(214,'b01dee11-1fc0-4b1f-a563-85e014afc0bb','2026-09-24 22:37:29',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','own','open','web','success',NULL,NULL,'192.168.1.245',NULL,NULL,126,NULL,'{\"demo\":true}'),
(215,'4aa5e1ae-0d64-4c60-82bc-70188af041e1','2026-09-24 10:16:08',NULL,1,'guest',6,NULL,NULL,'Васильева Анна Петровна','6','guest','open','cabinet','success',NULL,NULL,'192.168.1.172',NULL,NULL,531,NULL,'{\"demo\":true}'),
(216,'624e1dde-b465-4198-8eb6-28618ba566f8','2026-09-24 07:20:36',NULL,1,'resident',6,NULL,NULL,'Васильева Анна Петровна','6','own','open','cabinet','success',NULL,NULL,'192.168.1.154',NULL,NULL,153,NULL,'{\"demo\":true}'),
(217,'cdb4625e-9185-4481-83b5-04a9da13e800','2026-09-24 22:34:31',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','own','open','web','success',NULL,NULL,'192.168.1.127',NULL,NULL,773,NULL,'{\"demo\":true}'),
(218,'c23d29e1-624d-4c8d-9733-12700561118e','2026-09-24 15:23:26',NULL,1,'guest',9,NULL,NULL,'Фёдоров Андрей Иванович','9','guest','open','telegram','success',NULL,NULL,'192.168.1.20',NULL,NULL,647,NULL,'{\"demo\":true}'),
(219,'ff396aa8-3c0f-4bcb-8587-6a3735e78a49','2026-09-24 17:26:39',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','own','open','telegram','success',NULL,NULL,'192.168.1.181',NULL,NULL,597,NULL,'{\"demo\":true}'),
(220,'af7cc14c-bc4b-444a-9828-48bfff95bd37','2026-09-24 06:41:43',NULL,1,'guest',6,NULL,NULL,'Васильева Анна Петровна','6','guest','open','web','success',NULL,NULL,'192.168.1.228',NULL,NULL,733,NULL,'{\"demo\":true}'),
(221,'c6ad4c45-fcc8-4e50-9eab-7f6e6b5b1144','2026-09-24 07:20:31',NULL,1,'resident',14,NULL,NULL,'Семёнова Татьяна Петровна','14','plate','open','telegram','success',NULL,NULL,'192.168.1.206',NULL,NULL,485,NULL,'{\"demo\":true}'),
(222,'d96bb8aa-2b70-4a73-ae0c-f0e237a2754a','2026-09-24 15:20:11',NULL,1,'guest',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','guest','open','web','success',NULL,NULL,'192.168.1.101',NULL,NULL,721,NULL,'{\"demo\":true}'),
(223,'c9aa0b94-e03e-4f79-acd6-7627ca89b0cc','2026-09-24 16:51:31',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','open','cabinet','success',NULL,NULL,'192.168.1.20',NULL,NULL,290,NULL,'{\"demo\":true}'),
(224,'64323961-e532-43d8-a27f-a89295459c87','2026-09-24 14:40:14',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','plate','open','api','success',NULL,NULL,'192.168.1.201',NULL,NULL,343,NULL,'{\"demo\":true}'),
(225,'69b85fbf-db50-4a31-a02f-3178b0216919','2026-09-24 09:30:37',NULL,1,'resident',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','plate','open','api','success',NULL,NULL,'192.168.1.77',NULL,NULL,164,NULL,'{\"demo\":true}'),
(226,'443eed0d-6129-4c8f-a90c-7716ab239484','2026-09-24 18:48:01',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','api','success',NULL,NULL,'192.168.1.114',NULL,NULL,398,NULL,'{\"demo\":true}'),
(227,'19abc784-378a-476b-a3d4-3fb6ec9469a6','2026-09-25 09:35:56',NULL,1,'guest',14,NULL,NULL,'Семёнова Татьяна Петровна','14','guest','open','admin','success',NULL,NULL,'192.168.1.36',NULL,NULL,144,NULL,'{\"demo\":true}'),
(228,'961aa9b4-1d06-461e-9b67-99b11cb48958','2026-09-25 17:20:31',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','plate','open','api','success',NULL,NULL,'192.168.1.211',NULL,NULL,295,NULL,'{\"demo\":true}'),
(229,'4ab9507f-7d56-45b5-ba26-5cde47cb2907','2026-09-25 14:12:36',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','own','open','admin','success',NULL,NULL,'192.168.1.127',NULL,NULL,581,NULL,'{\"demo\":true}'),
(230,'61fb8d5f-7210-44bc-92dd-12edcc8c1ad8','2026-09-25 17:48:56',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','plate','open','web','success',NULL,NULL,'192.168.1.50',NULL,NULL,283,NULL,'{\"demo\":true}'),
(231,'877109cb-ea9b-4036-b51e-37b3663ed7f8','2026-09-25 10:22:11',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','admin','success',NULL,NULL,'192.168.1.148',NULL,NULL,652,NULL,'{\"demo\":true}'),
(232,'68fbe8b7-afc9-4041-a75e-4e5e30d159bf','2026-09-25 23:46:11',NULL,1,'admin',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','manual','open','admin','success',NULL,NULL,'192.168.1.186',NULL,NULL,852,NULL,'{\"demo\":true}'),
(233,'6814a289-6757-413e-b334-85c3dc217f07','2026-09-25 19:54:37',NULL,1,'guest',23,NULL,NULL,'Захаров Сергей Сергеевна','23','guest','open','web','success',NULL,NULL,'192.168.1.140',NULL,NULL,384,NULL,'{\"demo\":true}'),
(234,'9c3f7252-bd78-43f2-abf3-06bc182b7a3b','2026-09-25 19:19:22',NULL,1,'guest',18,NULL,NULL,'Степанова Мария Петрович','18','guest','open','api','success',NULL,NULL,'192.168.1.47',NULL,NULL,525,NULL,'{\"demo\":true}'),
(235,'a02d99ec-10c1-401f-9634-cee628588b85','2026-09-25 17:00:38',NULL,1,'resident',20,NULL,NULL,'Орлова Ольга Андреевич','20','own','open','cabinet','success',NULL,NULL,'192.168.1.216',NULL,NULL,641,NULL,'{\"demo\":true}'),
(236,'49818ee8-fe67-4a92-8ef2-e50b2e93efcf','2026-09-26 06:34:07',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','own','open','cabinet','success',NULL,NULL,'192.168.1.144',NULL,NULL,882,NULL,'{\"demo\":true}'),
(237,'86df2e5c-ef4d-4ecd-9af5-11107333f755','2026-09-26 19:52:55',NULL,1,'admin',13,NULL,NULL,'Лебедев Николай Ивановна','13','manual','open','web','success',NULL,NULL,'192.168.1.22',NULL,NULL,459,NULL,'{\"demo\":true}'),
(238,'8050a1a2-2cf1-4145-b08b-4024f9a3f712','2026-09-26 23:58:14',NULL,1,'resident',20,NULL,NULL,'Орлова Ольга Андреевич','20','own','open','web','success',NULL,NULL,'192.168.1.49',NULL,NULL,243,NULL,'{\"demo\":true}'),
(239,'3c0ef0f2-d105-46bc-92a7-a4e06e2c46c9','2026-09-26 14:00:01',NULL,1,'guest',9,NULL,NULL,'Фёдоров Андрей Иванович','9','guest','open','web','success',NULL,NULL,'192.168.1.198',NULL,NULL,883,NULL,'{\"demo\":true}'),
(240,'3324264d-1f3e-4855-8da7-854db203ccc8','2026-09-26 21:19:54',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','open','admin','success',NULL,NULL,'192.168.1.167',NULL,NULL,523,NULL,'{\"demo\":true}'),
(241,'18b00403-9a46-449a-93ac-8455b0ac652a','2026-09-26 16:25:04',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','own','open','admin','success',NULL,NULL,'192.168.1.21',NULL,NULL,780,NULL,'{\"demo\":true}'),
(242,'4aea9c51-dc32-4d5e-9655-801f78feb158','2026-09-26 07:24:44',NULL,1,'resident',1,NULL,NULL,'Иванов Иван Иванович','1','own','open','web','success',NULL,NULL,'192.168.1.68',NULL,NULL,218,NULL,'{\"demo\":true}'),
(243,'4abd5602-a5dc-4596-bd5e-a95798dc6278','2026-09-26 14:58:57',NULL,1,'resident',20,NULL,NULL,'Орлова Ольга Андреевич','20','own','open','cabinet','success',NULL,NULL,'192.168.1.177',NULL,NULL,285,NULL,'{\"demo\":true}'),
(244,'66027d55-b96b-486f-b100-aa876adb31f4','2026-09-26 13:14:37',NULL,1,'resident',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','own','open','cabinet','success',NULL,NULL,'192.168.1.65',NULL,NULL,879,NULL,'{\"demo\":true}'),
(245,'fd378065-796a-4578-bfd4-51b416f05e4e','2026-09-26 08:08:35',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','open','telegram','success',NULL,NULL,'192.168.1.243',NULL,NULL,320,NULL,'{\"demo\":true}'),
(246,'0595e1b4-f586-412b-b6e2-2620612a97d8','2026-09-26 11:29:55',NULL,1,'guest',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','guest','open','cabinet','success',NULL,NULL,'192.168.1.117',NULL,NULL,235,NULL,'{\"demo\":true}'),
(247,'93305086-cebc-48d4-abdf-8af22e327bb2','2026-09-26 22:36:04',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','telegram','success',NULL,NULL,'192.168.1.113',NULL,NULL,507,NULL,'{\"demo\":true}'),
(248,'84822815-aea5-4c98-8a70-8de29596a208','2026-09-26 10:53:35',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','own','open','api','success',NULL,NULL,'192.168.1.136',NULL,NULL,454,NULL,'{\"demo\":true}'),
(249,'2daa3c4d-5a1e-4fcf-ad75-13504c52c45c','2026-09-26 22:56:12',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','own','denied','cabinet','denied','Тихие часы',NULL,'192.168.1.134',NULL,NULL,499,NULL,'{\"demo\":true}'),
(250,'7b3407af-0b4a-49e2-94b4-d4991846c840','2026-09-26 10:01:03',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','open','admin','success',NULL,NULL,'192.168.1.197',NULL,NULL,457,NULL,'{\"demo\":true}'),
(251,'ba213d72-7292-4124-9712-ee95d2296d7e','2026-09-26 14:51:00',NULL,1,'guest',24,NULL,NULL,'Зайцева Елена Николаевич','24','guest','open','admin','success',NULL,NULL,'192.168.1.229',NULL,NULL,143,NULL,'{\"demo\":true}'),
(252,'7528a93e-57c6-4018-aa9e-66418a0f9d62','2026-09-27 14:04:38',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','admin','success',NULL,NULL,'192.168.1.99',NULL,NULL,376,NULL,'{\"demo\":true}'),
(253,'e3897421-dc0b-4b86-af98-46b3f07b57f7','2026-09-27 18:07:19',NULL,1,'guest',23,NULL,NULL,'Захаров Сергей Сергеевна','23','guest','open','telegram','success',NULL,NULL,'192.168.1.53',NULL,NULL,280,NULL,'{\"demo\":true}'),
(254,'633278b1-efb8-452d-a5ae-ffd0d5fca183','2026-09-27 12:32:27',NULL,1,'admin',17,NULL,NULL,'Козлов Иван Иванович','17','manual','open','telegram','success',NULL,NULL,'192.168.1.230',NULL,NULL,727,NULL,'{\"demo\":true}'),
(255,'48beba0b-6b0f-46ba-8555-d88ffbc058bc','2026-09-27 20:11:25',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','own','open','telegram','success',NULL,NULL,'192.168.1.137',NULL,NULL,821,NULL,'{\"demo\":true}'),
(256,'254864ad-571f-4206-b029-52ee8517b05f','2026-09-27 22:44:11',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','api','success',NULL,NULL,'192.168.1.241',NULL,NULL,199,NULL,'{\"demo\":true}'),
(257,'8f24a2e1-9c92-4ab4-950c-d3d85e7eea88','2026-09-27 13:37:44',NULL,1,'resident',14,NULL,NULL,'Семёнова Татьяна Петровна','14','plate','open','web','success',NULL,NULL,'192.168.1.102',NULL,NULL,821,NULL,'{\"demo\":true}'),
(258,'d25e27b7-52c9-43cb-92b0-7e117cc5ad6a','2026-09-27 13:58:12',NULL,1,'resident',6,NULL,NULL,'Васильева Анна Петровна','6','own','open','web','success',NULL,NULL,'192.168.1.225',NULL,NULL,501,NULL,'{\"demo\":true}'),
(259,'cb8c394f-9823-442c-9403-2ec87a84897d','2026-09-27 15:58:57',NULL,1,'admin',14,NULL,NULL,'Семёнова Татьяна Петровна','14','manual','open','web','success',NULL,NULL,'192.168.1.164',NULL,NULL,300,NULL,'{\"demo\":true}'),
(260,'10cdd8e6-4918-4dc4-bf40-dbabed5f5bdd','2026-09-28 18:51:27',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','plate','denied','api','denied','Тихие часы',NULL,'192.168.1.119',NULL,NULL,779,NULL,'{\"demo\":true}'),
(261,'30086f50-8440-46fe-b0f2-64c59fd966f5','2026-09-28 19:17:18',NULL,1,'admin',20,NULL,NULL,'Орлова Ольга Андреевич','20','manual','open','telegram','success',NULL,NULL,'192.168.1.80',NULL,NULL,485,NULL,'{\"demo\":true}'),
(262,'4338bf02-6edc-45a6-b78b-189e8bedb04c','2026-09-28 14:05:02',NULL,1,'admin',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','manual','open','web','success',NULL,NULL,'192.168.1.222',NULL,NULL,226,NULL,'{\"demo\":true}'),
(263,'d69f3ce2-26a1-46e5-83ff-cddf83aecc6c','2026-09-28 11:58:50',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','own','open','telegram','success',NULL,NULL,'192.168.1.87',NULL,NULL,813,NULL,'{\"demo\":true}'),
(264,'d5dcb1a3-9aa5-45e9-ad7b-33aec601bfd5','2026-09-28 20:58:17',NULL,1,'resident',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','plate','open','api','success',NULL,NULL,'192.168.1.48',NULL,NULL,803,NULL,'{\"demo\":true}'),
(265,'4a6596ec-776e-485a-931c-3595a1639ca4','2026-09-29 07:59:41',NULL,1,'admin',17,NULL,NULL,'Козлов Иван Иванович','17','manual','open','telegram','success',NULL,NULL,'192.168.1.31',NULL,NULL,874,NULL,'{\"demo\":true}'),
(266,'dac8c800-e5a4-48fe-a586-a9e2ecb18659','2026-09-29 22:10:46',NULL,1,'guest',2,NULL,NULL,'Петрова Мария Петрович','2','guest','open','telegram','success',NULL,NULL,'192.168.1.51',NULL,NULL,342,NULL,'{\"demo\":true}'),
(267,'90407a3a-5538-440e-a83e-757b506553c7','2026-09-29 22:56:26',NULL,1,'resident',14,NULL,NULL,'Семёнова Татьяна Петровна','14','own','open','web','success',NULL,NULL,'192.168.1.110',NULL,NULL,194,NULL,'{\"demo\":true}'),
(268,'ed1eedc9-1b23-4e37-9219-f23e7f279a94','2026-09-29 23:56:16',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','own','open','telegram','success',NULL,NULL,'192.168.1.122',NULL,NULL,125,NULL,'{\"demo\":true}'),
(269,'ca2e3de8-7a80-4100-9034-0e0b424fdfc7','2026-09-29 23:24:33',NULL,1,'resident',6,NULL,NULL,'Васильева Анна Петровна','6','plate','open','web','success',NULL,NULL,'192.168.1.79',NULL,NULL,893,NULL,'{\"demo\":true}'),
(270,'67dc6680-c78e-4e54-9a5b-47371c937161','2026-09-29 11:36:58',NULL,1,'resident',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','plate','open','admin','success',NULL,NULL,'192.168.1.170',NULL,NULL,401,NULL,'{\"demo\":true}'),
(271,'f9b480d9-e95a-4c60-925d-57462d13c4e2','2026-09-29 15:47:44',NULL,1,'resident',22,NULL,NULL,'Макарова Анна Петровна','22','own','denied','api','denied','Доступ приостановлен',NULL,'192.168.1.156',NULL,NULL,684,NULL,'{\"demo\":true}'),
(272,'27d98527-91e3-46ff-8434-d47628812fd3','2026-09-29 12:44:02',NULL,1,'admin',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','manual','open','web','success',NULL,NULL,'192.168.1.43',NULL,NULL,181,NULL,'{\"demo\":true}'),
(273,'2a6db3fd-3ba7-489c-97bd-1df8247028ae','2026-09-29 10:31:58',NULL,1,'admin',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','manual','open','web','success',NULL,NULL,'192.168.1.100',NULL,NULL,661,NULL,'{\"demo\":true}'),
(274,'69c7585c-0daa-4157-b652-afa09673052b','2026-09-29 13:19:50',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','own','open','telegram','success',NULL,NULL,'192.168.1.122',NULL,NULL,652,NULL,'{\"demo\":true}'),
(275,'b06a8523-325e-4709-908a-0a724e5ca1d8','2026-09-29 20:58:33',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','own','open','api','success',NULL,NULL,'192.168.1.188',NULL,NULL,680,NULL,'{\"demo\":true}'),
(276,'864367ae-10f6-4bc4-a2bc-00f69150ff3a','2026-09-29 15:23:08',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','own','open','api','success',NULL,NULL,'192.168.1.66',NULL,NULL,898,NULL,'{\"demo\":true}'),
(277,'965293fb-ba06-4830-9823-f2ed8e137bab','2026-09-29 11:57:45',NULL,1,'guest',6,NULL,NULL,'Васильева Анна Петровна','6','guest','open','api','success',NULL,NULL,'192.168.1.205',NULL,NULL,730,NULL,'{\"demo\":true}'),
(278,'ed66a2c8-9673-4cc3-8518-124a6faa208b','2026-09-29 10:10:37',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','own','open','api','success',NULL,NULL,'192.168.1.186',NULL,NULL,531,NULL,'{\"demo\":true}'),
(279,'a0ccb3f8-1df8-41bc-ba19-4b625f7644ba','2026-09-29 11:55:53',NULL,1,'resident',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','plate','open','telegram','success',NULL,NULL,'192.168.1.49',NULL,NULL,127,NULL,'{\"demo\":true}'),
(280,'38b1f11e-0f25-4491-abd9-a44b89a2f339','2026-09-29 12:37:14',NULL,1,'resident',1,NULL,NULL,'Иванов Иван Иванович','1','own','open','admin','success',NULL,NULL,'192.168.1.235',NULL,NULL,155,NULL,'{\"demo\":true}'),
(281,'967d1b52-c1ed-43c3-aa76-dc0d6f135e18','2026-09-29 14:55:03',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','own','open','web','success',NULL,NULL,'192.168.1.108',NULL,NULL,330,NULL,'{\"demo\":true}'),
(282,'935c7854-952f-4881-9d05-76512cf20139','2026-09-29 23:48:23',NULL,1,'admin',15,NULL,NULL,'Егоров Виктор Сергеевна','15','manual','open','web','success',NULL,NULL,'192.168.1.201',NULL,NULL,333,NULL,'{\"demo\":true}'),
(283,'149efe2f-a019-485b-a09c-febfb1c38a31','2026-09-30 17:53:26',NULL,1,'resident',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','own','open','cabinet','success',NULL,NULL,'192.168.1.97',NULL,NULL,402,NULL,'{\"demo\":true}'),
(284,'1c4eee11-3991-43b7-8000-3cef0307b5c5','2026-09-30 07:00:46',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','plate','open','cabinet','success',NULL,NULL,'192.168.1.182',NULL,NULL,221,NULL,'{\"demo\":true}'),
(285,'9efa427e-2a2e-4405-9462-7dc4659fd38f','2026-09-30 07:42:48',NULL,1,'guest',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','guest','open','telegram','success',NULL,NULL,'192.168.1.123',NULL,NULL,610,NULL,'{\"demo\":true}'),
(286,'c37723e7-10ae-438c-8ac9-37e8e603a38a','2026-09-30 12:35:40',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','own','open','api','success',NULL,NULL,'192.168.1.55',NULL,NULL,559,NULL,'{\"demo\":true}'),
(287,'5b78a6a7-9f64-459b-816f-0e417a4c0200','2026-09-30 15:06:32',NULL,1,'guest',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','guest','open','admin','success',NULL,NULL,'192.168.1.239',NULL,NULL,308,NULL,'{\"demo\":true}'),
(288,'81331b8d-2131-4579-a994-0cab431dda15','2026-09-30 23:30:21',NULL,1,'resident',15,NULL,NULL,'Егоров Виктор Сергеевна','15','own','open','web','success',NULL,NULL,'192.168.1.248',NULL,NULL,305,NULL,'{\"demo\":true}'),
(289,'4555a105-17c1-465a-b77e-16743274bc8b','2026-09-30 20:20:39',NULL,1,'admin',7,NULL,NULL,'Соколов Сергей Сергеевна','7','manual','open','api','success',NULL,NULL,'192.168.1.141',NULL,NULL,429,NULL,'{\"demo\":true}'),
(290,'dfa20056-a381-419b-956b-82be2f047780','2026-09-30 14:57:59',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','own','open','web','success',NULL,NULL,'192.168.1.201',NULL,NULL,511,NULL,'{\"demo\":true}'),
(291,'00103eba-2bbb-48f4-aeb9-4935066eb34a','2026-09-30 23:20:41',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','own','open','cabinet','success',NULL,NULL,'192.168.1.163',NULL,NULL,204,NULL,'{\"demo\":true}'),
(292,'c7f87194-3df5-4b34-b220-37439d3ff711','2026-09-30 07:52:23',NULL,1,'resident',20,NULL,NULL,'Орлова Ольга Андреевич','20','own','open','telegram','success',NULL,NULL,'192.168.1.82',NULL,NULL,756,NULL,'{\"demo\":true}'),
(293,'60d9df08-4b11-4ab3-8704-7bdb50ff4584','2026-09-30 14:01:15',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','open','api','success',NULL,NULL,'192.168.1.25',NULL,NULL,500,NULL,'{\"demo\":true}'),
(294,'6578b804-87dc-4c81-b94a-77949cb207ac','2026-09-30 22:57:43',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','own','open','web','success',NULL,NULL,'192.168.1.216',NULL,NULL,448,NULL,'{\"demo\":true}'),
(295,'13dd5ba9-b0d2-4713-a90e-c9ce5bd089e8','2026-09-30 15:13:34',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','own','open','api','success',NULL,NULL,'192.168.1.201',NULL,NULL,813,NULL,'{\"demo\":true}'),
(296,'e1e98846-81b0-481b-b81f-ecf2cec821a6','2026-09-30 12:16:00',NULL,1,'resident',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','own','open','web','success',NULL,NULL,'192.168.1.183',NULL,NULL,744,NULL,'{\"demo\":true}'),
(297,'532f8e50-fa7f-49c7-bdcd-c8f74fc2e178','2026-09-30 15:47:00',NULL,1,'resident',6,NULL,NULL,'Васильева Анна Петровна','6','own','open','telegram','success',NULL,NULL,'192.168.1.213',NULL,NULL,462,NULL,'{\"demo\":true}'),
(298,'ec779119-2210-41d9-a4aa-bf13b627b2d8','2026-09-30 23:09:11',NULL,1,'resident',22,NULL,NULL,'Макарова Анна Петровна','22','plate','denied','cabinet','denied','Тихие часы',NULL,'192.168.1.51',NULL,NULL,692,NULL,'{\"demo\":true}'),
(299,'c59d5914-4ed7-463f-9ddf-5f841c9e2205','2026-09-30 23:12:25',NULL,1,'admin',22,NULL,NULL,'Макарова Анна Петровна','22','manual','open','api','success',NULL,NULL,'192.168.1.247',NULL,NULL,754,NULL,'{\"demo\":true}'),
(300,'be235cea-4683-4826-a297-b2648545b211','2026-09-30 09:36:42',NULL,1,'admin',2,NULL,NULL,'Петрова Мария Петрович','2','manual','open','web','success',NULL,NULL,'192.168.1.175',NULL,NULL,587,NULL,'{\"demo\":true}'),
(301,'de6d7b7d-ece7-417b-adb0-ce4bf802e143','2026-09-30 20:53:13',NULL,1,'resident',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','own','open','telegram','success',NULL,NULL,'192.168.1.168',NULL,NULL,565,NULL,'{\"demo\":true}'),
(302,'0f6edaf6-558c-4456-ae33-df67af13e55e','2026-09-30 21:09:48',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','own','open','cabinet','success',NULL,NULL,'192.168.1.250',NULL,NULL,198,NULL,'{\"demo\":true}'),
(303,'f0c43606-793f-41d4-8615-a83e41ea829b','2026-09-30 23:28:53',NULL,1,'resident',11,NULL,NULL,'Волков Павел Сергеевич','11','own','open','web','success',NULL,NULL,'192.168.1.96',NULL,NULL,171,NULL,'{\"demo\":true}'),
(304,'2d88e7af-e789-460f-bfc5-c7b3c0efd9a9','2026-09-30 21:14:43',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','own','open','cabinet','success',NULL,NULL,'192.168.1.79',NULL,NULL,406,NULL,'{\"demo\":true}'),
(305,'badc3c9f-b431-49ed-b7da-40ce25843522','2026-10-01 15:55:33',NULL,1,'admin',11,NULL,NULL,'Волков Павел Сергеевич','11','manual','open','telegram','success',NULL,NULL,'192.168.1.79',NULL,NULL,126,NULL,'{\"demo\":true}'),
(306,'df5be34d-f71f-4d69-b0e5-bb65865a3863','2026-10-01 08:07:03',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','own','open','telegram','success',NULL,NULL,'192.168.1.48',NULL,NULL,722,NULL,'{\"demo\":true}'),
(307,'9999c11e-ceb9-49bd-bb13-50a83da28938','2026-10-01 21:25:05',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','plate','open','admin','success',NULL,NULL,'192.168.1.37',NULL,NULL,555,NULL,'{\"demo\":true}'),
(308,'b819d887-49d5-4a39-99dd-bb3f4ac693b3','2026-10-01 21:42:38',NULL,1,'admin',24,NULL,NULL,'Зайцева Елена Николаевич','24','manual','open','api','success',NULL,NULL,'192.168.1.175',NULL,NULL,154,NULL,'{\"demo\":true}'),
(309,'465a1b08-5ea3-497e-9b6b-5e138688e2a0','2026-10-01 07:18:56',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','web','success',NULL,NULL,'192.168.1.51',NULL,NULL,770,NULL,'{\"demo\":true}'),
(310,'595b2dfc-804b-4e40-8d9c-adfe8664e5ea','2026-10-01 21:36:06',NULL,1,'admin',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','manual','denied','cabinet','denied','Тихие часы',NULL,'192.168.1.191',NULL,NULL,473,NULL,'{\"demo\":true}'),
(311,'1597e42f-72aa-437c-a574-20c52a03efaf','2026-10-01 13:21:18',NULL,1,'admin',7,NULL,NULL,'Соколов Сергей Сергеевна','7','manual','open','telegram','success',NULL,NULL,'192.168.1.133',NULL,NULL,472,NULL,'{\"demo\":true}'),
(312,'0a639f91-54bd-4d40-99e3-4f86352e98b2','2026-10-01 15:10:43',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','own','open','api','success',NULL,NULL,'192.168.1.70',NULL,NULL,611,NULL,'{\"demo\":true}'),
(313,'0faba325-f57c-411e-aee2-3b51cd1e37c8','2026-10-01 14:23:49',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','admin','success',NULL,NULL,'192.168.1.122',NULL,NULL,611,NULL,'{\"demo\":true}'),
(314,'f35cfb98-09fd-49f2-8df6-64107a4f1a92','2026-10-01 18:34:02',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','plate','open','admin','success',NULL,NULL,'192.168.1.172',NULL,NULL,333,NULL,'{\"demo\":true}'),
(315,'11b9ade3-9d52-4ef3-bea9-3d71a06fb92a','2026-10-01 16:56:50',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','open','telegram','success',NULL,NULL,'192.168.1.227',NULL,NULL,241,NULL,'{\"demo\":true}'),
(316,'d3a05bbb-8966-4ba7-bc52-a52163486970','2026-10-01 15:16:51',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','admin','success',NULL,NULL,'192.168.1.203',NULL,NULL,811,NULL,'{\"demo\":true}'),
(317,'2b737b2e-14b5-4366-944b-f6e43f3b9fe1','2026-10-01 22:46:42',NULL,1,'guest',22,NULL,NULL,'Макарова Анна Петровна','22','guest','open','admin','success',NULL,NULL,'192.168.1.150',NULL,NULL,583,NULL,'{\"demo\":true}'),
(318,'03c8e796-9a26-47b7-bf95-93904d789076','2026-10-01 12:15:38',NULL,1,'resident',20,NULL,NULL,'Орлова Ольга Андреевич','20','own','open','cabinet','success',NULL,NULL,'192.168.1.191',NULL,NULL,711,NULL,'{\"demo\":true}'),
(319,'b94e9424-61ce-4f77-a311-a5615d738d13','2026-10-01 22:04:51',NULL,1,'admin',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','manual','denied','web','denied','Тихие часы',NULL,'192.168.1.211',NULL,NULL,591,NULL,'{\"demo\":true}'),
(320,'2b84b3ba-a916-4ca5-9c1e-70e9f8b4c78a','2026-10-01 22:12:16',NULL,1,'admin',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','manual','denied','admin','denied','Доступ приостановлен',NULL,'192.168.1.162',NULL,NULL,502,NULL,'{\"demo\":true}'),
(321,'6a0bf9cd-03d5-4cbc-a97a-c5c3c5de2e0d','2026-10-02 16:27:59',NULL,1,'resident',20,NULL,NULL,'Орлова Ольга Андреевич','20','plate','open','admin','success',NULL,NULL,'192.168.1.97',NULL,NULL,335,NULL,'{\"demo\":true}'),
(322,'15345853-70b7-4650-a0c5-a385d041daa0','2026-10-02 11:56:59',NULL,1,'admin',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','manual','open','api','success',NULL,NULL,'192.168.1.170',NULL,NULL,585,NULL,'{\"demo\":true}'),
(323,'d93e5598-4a81-4219-8174-62320e4b4093','2026-10-02 13:02:34',NULL,1,'guest',10,NULL,NULL,'Морозова Наталья Петрович','10','guest','open','cabinet','success',NULL,NULL,'192.168.1.197',NULL,NULL,621,NULL,'{\"demo\":true}'),
(324,'dcd1c714-8971-4eb6-93a0-413d3ae2bb36','2026-10-02 09:23:14',NULL,1,'admin',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','manual','open','admin','success',NULL,NULL,'192.168.1.216',NULL,NULL,628,NULL,'{\"demo\":true}'),
(325,'e8ba5f52-67d8-4ad5-88cc-c879eb80a9e3','2026-10-02 19:45:31',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','own','open','cabinet','success',NULL,NULL,'192.168.1.206',NULL,NULL,793,NULL,'{\"demo\":true}'),
(326,'a3ae17d5-db39-4def-a328-87cdc175b5fd','2026-10-02 12:29:09',NULL,1,'guest',11,NULL,NULL,'Волков Павел Сергеевич','11','guest','open','web','success',NULL,NULL,'192.168.1.89',NULL,NULL,727,NULL,'{\"demo\":true}'),
(327,'38172434-730a-40c3-829f-7c88caa140c1','2026-10-02 22:18:46',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','plate','open','web','success',NULL,NULL,'192.168.1.243',NULL,NULL,638,NULL,'{\"demo\":true}'),
(328,'e2df4849-8428-40fc-ab4d-573fbfca0291','2026-10-02 06:09:47',NULL,1,'resident',14,NULL,NULL,'Семёнова Татьяна Петровна','14','own','open','web','success',NULL,NULL,'192.168.1.242',NULL,NULL,523,NULL,'{\"demo\":true}'),
(329,'3d80f50a-66ed-4de8-ba40-0285c8d7143d','2026-10-03 11:43:21',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','own','open','api','success',NULL,NULL,'192.168.1.90',NULL,NULL,863,NULL,'{\"demo\":true}'),
(330,'7e9c2279-402b-4638-b676-dcfa443cdaf7','2026-10-03 07:15:12',NULL,1,'resident',20,NULL,NULL,'Орлова Ольга Андреевич','20','own','open','api','success',NULL,NULL,'192.168.1.109',NULL,NULL,302,NULL,'{\"demo\":true}'),
(331,'5706b2ff-2a44-49c4-b6f4-b0fa7e79ee20','2026-10-03 15:32:56',NULL,1,'resident',16,NULL,NULL,'Павлова Юлия Николаевич','16','own','open','api','success',NULL,NULL,'192.168.1.108',NULL,NULL,566,NULL,'{\"demo\":true}'),
(332,'0dd1e7b2-8b39-4ac4-8842-01e1090fe4d7','2026-10-03 20:24:12',NULL,1,'resident',16,NULL,NULL,'Павлова Юлия Николаевич','16','own','denied','web','denied','Превышен лимит открытий',NULL,'192.168.1.146',NULL,NULL,323,NULL,'{\"demo\":true}'),
(333,'fc90ab65-e061-428f-b5d8-1b7af9d5f476','2026-10-03 06:48:56',NULL,1,'resident',1,NULL,NULL,'Иванов Иван Иванович','1','own','open','api','success',NULL,NULL,'192.168.1.145',NULL,NULL,845,NULL,'{\"demo\":true}'),
(334,'98fbf3c1-67f8-4ce7-a05c-1dc87f99825c','2026-10-03 11:51:24',NULL,1,'resident',16,NULL,NULL,'Павлова Юлия Николаевич','16','plate','open','cabinet','success',NULL,NULL,'192.168.1.209',NULL,NULL,853,NULL,'{\"demo\":true}'),
(335,'48381b16-4438-4377-bfac-e6307cf62abf','2026-10-03 16:32:20',NULL,1,'guest',6,NULL,NULL,'Васильева Анна Петровна','6','guest','open','admin','success',NULL,NULL,'192.168.1.54',NULL,NULL,543,NULL,'{\"demo\":true}'),
(336,'6276e15e-b793-46b9-904a-0a16b3a55d77','2026-10-03 19:31:52',NULL,1,'admin',16,NULL,NULL,'Павлова Юлия Николаевич','16','manual','open','telegram','success',NULL,NULL,'192.168.1.128',NULL,NULL,705,NULL,'{\"demo\":true}'),
(337,'4e6b139d-c6fa-4818-9272-1777fd8f3c5e','2026-10-03 21:48:15',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','own','open','web','success',NULL,NULL,'192.168.1.68',NULL,NULL,145,NULL,'{\"demo\":true}'),
(338,'81952a70-b58b-4bae-9e4b-c4004560a3d5','2026-10-03 18:40:55',NULL,1,'guest',23,NULL,NULL,'Захаров Сергей Сергеевна','23','guest','open','admin','success',NULL,NULL,'192.168.1.148',NULL,NULL,433,NULL,'{\"demo\":true}'),
(339,'4a3659e4-f417-4549-b511-e1f37e0c9ba9','2026-10-03 22:38:44',NULL,1,'guest',22,NULL,NULL,'Макарова Анна Петровна','22','guest','open','telegram','success',NULL,NULL,'192.168.1.124',NULL,NULL,821,NULL,'{\"demo\":true}'),
(340,'5a3a393f-c02b-4f2e-a353-a176b0e2aca0','2026-10-03 08:56:35',NULL,1,'resident',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','own','open','api','success',NULL,NULL,'192.168.1.219',NULL,NULL,845,NULL,'{\"demo\":true}'),
(341,'cf49b0b1-f1b3-4206-b28a-de0063bc980d','2026-10-03 17:39:01',NULL,1,'resident',24,NULL,NULL,'Зайцева Елена Николаевич','24','own','open','web','success',NULL,NULL,'192.168.1.105',NULL,NULL,485,NULL,'{\"demo\":true}'),
(342,'5e92b6d0-f090-494d-8a7c-00e7f4157c33','2026-10-03 16:26:56',NULL,1,'admin',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','manual','open','api','success',NULL,NULL,'192.168.1.169',NULL,NULL,465,NULL,'{\"demo\":true}'),
(343,'31f81e56-6bc4-4834-a896-2be767f59c87','2026-10-04 09:53:02',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','api','success',NULL,NULL,'192.168.1.72',NULL,NULL,558,NULL,'{\"demo\":true}'),
(344,'dc875f63-c49c-4a7c-aca6-61668e735b7f','2026-10-04 10:12:39',NULL,1,'resident',22,NULL,NULL,'Макарова Анна Петровна','22','own','open','admin','success',NULL,NULL,'192.168.1.220',NULL,NULL,420,NULL,'{\"demo\":true}'),
(345,'2eef6fe2-b1c7-4e04-a2e1-81aab94fa84d','2026-10-04 20:17:45',NULL,1,'resident',22,NULL,NULL,'Макарова Анна Петровна','22','own','open','api','success',NULL,NULL,'192.168.1.70',NULL,NULL,668,NULL,'{\"demo\":true}'),
(346,'3ad1fd6a-594a-4511-beb5-bc61a0f3754c','2026-10-04 10:52:43',NULL,1,'guest',6,NULL,NULL,'Васильева Анна Петровна','6','guest','open','admin','success',NULL,NULL,'192.168.1.61',NULL,NULL,586,NULL,'{\"demo\":true}'),
(347,'d67df34a-977e-4e2c-92dc-93dc4484bcfd','2026-10-04 14:16:28',NULL,1,'admin',10,NULL,NULL,'Морозова Наталья Петрович','10','manual','open','api','success',NULL,NULL,'192.168.1.150',NULL,NULL,350,NULL,'{\"demo\":true}'),
(348,'9d94ab51-0b3b-408a-a325-c0c5605f2307','2026-10-04 14:58:23',NULL,1,'guest',24,NULL,NULL,'Зайцева Елена Николаевич','24','guest','open','cabinet','success',NULL,NULL,'192.168.1.30',NULL,NULL,689,NULL,'{\"demo\":true}'),
(349,'79038167-b05b-49ba-9091-77c1a450b803','2026-10-04 06:10:29',NULL,1,'guest',16,NULL,NULL,'Павлова Юлия Николаевич','16','guest','open','cabinet','success',NULL,NULL,'192.168.1.90',NULL,NULL,464,NULL,'{\"demo\":true}'),
(350,'c7066d73-bda2-4fa0-916d-407ea51c1412','2026-10-04 09:24:05',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','own','open','cabinet','success',NULL,NULL,'192.168.1.203',NULL,NULL,632,NULL,'{\"demo\":true}'),
(351,'3f0d4ca5-6945-44e4-9cc1-3baf8ce23d5e','2026-10-04 09:00:48',NULL,1,'resident',1,NULL,NULL,'Иванов Иван Иванович','1','plate','open','web','success',NULL,NULL,'192.168.1.242',NULL,NULL,476,NULL,'{\"demo\":true}'),
(352,'70a9f136-2542-4476-9c8b-9b8a6290f58a','2026-10-04 16:41:44',NULL,1,'admin',7,NULL,NULL,'Соколов Сергей Сергеевна','7','manual','open','api','success',NULL,NULL,'192.168.1.92',NULL,NULL,217,NULL,'{\"demo\":true}'),
(353,'3028d6e9-b345-48ad-ac22-72d9b100f331','2026-10-04 22:28:57',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','own','open','telegram','success',NULL,NULL,'192.168.1.127',NULL,NULL,898,NULL,'{\"demo\":true}'),
(354,'62eb3ccc-814f-4b6e-b85d-9cc22d8b8c70','2026-10-05 23:41:59',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','own','open','api','success',NULL,NULL,'192.168.1.194',NULL,NULL,626,NULL,'{\"demo\":true}'),
(355,'c4e09fe0-c37d-4865-b44e-5fec2d5e1d4b','2026-10-05 16:51:34',NULL,1,'resident',1,NULL,NULL,'Иванов Иван Иванович','1','own','open','cabinet','success',NULL,NULL,'192.168.1.168',NULL,NULL,138,NULL,'{\"demo\":true}'),
(356,'b574e241-6884-4c31-b578-e917e28709bc','2026-10-05 17:55:25',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','own','open','api','success',NULL,NULL,'192.168.1.226',NULL,NULL,409,NULL,'{\"demo\":true}'),
(357,'b35dedda-2a5a-4ad0-a9b3-6b2d4061884c','2026-10-05 23:28:28',NULL,1,'admin',14,NULL,NULL,'Семёнова Татьяна Петровна','14','manual','open','web','success',NULL,NULL,'192.168.1.59',NULL,NULL,240,NULL,'{\"demo\":true}'),
(358,'aa488ac1-fef4-4a3c-8d78-c238cae0d9b7','2026-10-05 07:39:21',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','own','open','cabinet','success',NULL,NULL,'192.168.1.216',NULL,NULL,737,NULL,'{\"demo\":true}'),
(359,'d922274f-7121-49a7-9a33-396eb6239eea','2026-10-05 14:34:42',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','own','open','cabinet','success',NULL,NULL,'192.168.1.125',NULL,NULL,586,NULL,'{\"demo\":true}'),
(360,'fdcb2768-cb4a-45f9-98cc-15dfb7abe7f2','2026-10-05 21:11:32',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','own','open','web','success',NULL,NULL,'192.168.1.143',NULL,NULL,290,NULL,'{\"demo\":true}'),
(361,'17a6dc89-092e-474b-a60c-0a99383045da','2026-10-05 10:22:30',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','telegram','success',NULL,NULL,'192.168.1.203',NULL,NULL,160,NULL,'{\"demo\":true}'),
(362,'f97a3829-9983-45da-b7dc-c26c50524654','2026-10-05 12:07:57',NULL,1,'guest',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','guest','open','api','success',NULL,NULL,'192.168.1.152',NULL,NULL,167,NULL,'{\"demo\":true}'),
(363,'47592a0a-cf39-4100-abb6-a1f13a98b991','2026-10-05 14:56:59',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','plate','open','admin','success',NULL,NULL,'192.168.1.162',NULL,NULL,136,NULL,'{\"demo\":true}'),
(364,'0c4fe216-d344-4095-ba4c-88348a852b71','2026-10-05 06:39:53',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','telegram','success',NULL,NULL,'192.168.1.40',NULL,NULL,801,NULL,'{\"demo\":true}'),
(365,'8d0fbe98-2d03-4f1e-aeb1-4e5e9e054cbd','2026-10-05 22:49:41',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','own','open','api','success',NULL,NULL,'192.168.1.233',NULL,NULL,648,NULL,'{\"demo\":true}'),
(366,'3e7ea042-060b-4482-981b-4327219b0853','2026-10-05 18:56:24',NULL,1,'admin',1,NULL,NULL,'Иванов Иван Иванович','1','manual','open','web','success',NULL,NULL,'192.168.1.108',NULL,NULL,297,NULL,'{\"demo\":true}'),
(367,'7f4c3126-320c-47e8-bf3e-e58dac1f02d3','2026-10-05 23:58:59',NULL,1,'admin',18,NULL,NULL,'Степанова Мария Петрович','18','manual','open','cabinet','success',NULL,NULL,'192.168.1.131',NULL,NULL,187,NULL,'{\"demo\":true}'),
(368,'d7a50bb3-4df1-4ce1-b065-d5fa21292568','2026-10-05 09:35:05',NULL,1,'resident',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','own','open','admin','success',NULL,NULL,'192.168.1.92',NULL,NULL,141,NULL,'{\"demo\":true}'),
(369,'64f0aca6-b694-46eb-9db5-ae11ba48d9b0','2026-10-05 22:15:14',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','own','open','cabinet','success',NULL,NULL,'192.168.1.209',NULL,NULL,740,NULL,'{\"demo\":true}'),
(370,'672b6013-23a9-4dda-b848-76e17c7455f5','2026-10-05 09:47:10',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','own','open','web','success',NULL,NULL,'192.168.1.24',NULL,NULL,279,NULL,'{\"demo\":true}'),
(371,'25659532-0122-4faf-b428-3d79cbc44c8a','2026-10-05 20:52:31',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','denied','admin','denied','Превышен лимит открытий',NULL,'192.168.1.184',NULL,NULL,769,NULL,'{\"demo\":true}'),
(372,'522cbd4a-ede6-4382-b1ee-bd9d5038ae45','2026-10-06 22:26:54',NULL,1,'admin',7,NULL,NULL,'Соколов Сергей Сергеевна','7','manual','open','web','success',NULL,NULL,'192.168.1.233',NULL,NULL,379,NULL,'{\"demo\":true}'),
(373,'cef7f67e-2115-46e8-9d09-b6f70f3a23bb','2026-10-06 20:10:43',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','own','open','web','success',NULL,NULL,'192.168.1.70',NULL,NULL,821,NULL,'{\"demo\":true}'),
(374,'3ea87e65-af9e-4209-9b57-c10bcb2ceacc','2026-10-06 11:21:05',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','open','web','success',NULL,NULL,'192.168.1.227',NULL,NULL,798,NULL,'{\"demo\":true}'),
(375,'9a804af7-f47a-402b-9599-b36f85d78be2','2026-10-06 06:30:00',NULL,1,'guest',24,NULL,NULL,'Зайцева Елена Николаевич','24','guest','open','cabinet','success',NULL,NULL,'192.168.1.237',NULL,NULL,589,NULL,'{\"demo\":true}'),
(376,'dac32b98-a220-4a10-9ead-d12152a2a1e0','2026-10-06 16:04:42',NULL,1,'admin',15,NULL,NULL,'Егоров Виктор Сергеевна','15','manual','open','admin','success',NULL,NULL,'192.168.1.236',NULL,NULL,812,NULL,'{\"demo\":true}'),
(377,'92575816-eb7f-4bb7-a68b-9fe25153b99c','2026-10-06 14:44:30',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','plate','denied','cabinet','denied','Доступ приостановлен',NULL,'192.168.1.209',NULL,NULL,286,NULL,'{\"demo\":true}'),
(378,'362f41cb-cb6b-4898-af76-3e970724c48b','2026-10-06 22:40:31',NULL,1,'admin',8,NULL,NULL,'Михайлова Елена Николаевич','8','manual','open','admin','success',NULL,NULL,'192.168.1.145',NULL,NULL,807,NULL,'{\"demo\":true}'),
(379,'d61f84fb-67be-4c08-be73-8cff6a5448e5','2026-10-06 21:23:50',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','cabinet','success',NULL,NULL,'192.168.1.188',NULL,NULL,257,NULL,'{\"demo\":true}'),
(380,'e26cc202-ee0b-4603-87fc-50917fd7c49f','2026-10-06 08:15:32',NULL,1,'resident',23,NULL,NULL,'Захаров Сергей Сергеевна','23','plate','open','api','success',NULL,NULL,'192.168.1.236',NULL,NULL,311,NULL,'{\"demo\":true}'),
(381,'774d5d67-4f07-48d6-a640-36fccc56adde','2026-10-06 15:39:02',NULL,1,'guest',18,NULL,NULL,'Степанова Мария Петрович','18','guest','open','api','success',NULL,NULL,'192.168.1.157',NULL,NULL,353,NULL,'{\"demo\":true}'),
(382,'2cb05ad7-6826-490a-92d5-de2f94a6bca8','2026-10-06 15:00:42',NULL,1,'resident',15,NULL,NULL,'Егоров Виктор Сергеевна','15','own','open','cabinet','success',NULL,NULL,'192.168.1.86',NULL,NULL,557,NULL,'{\"demo\":true}'),
(383,'e23a109e-5ccf-40a7-9ed7-43ac68984e4f','2026-10-06 08:35:44',NULL,1,'guest',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','guest','open','api','success',NULL,NULL,'192.168.1.190',NULL,NULL,786,NULL,'{\"demo\":true}'),
(384,'68dd73c9-5c1d-4e56-9af9-c12bc5ca5a56','2026-10-06 22:01:39',NULL,1,'resident',15,NULL,NULL,'Егоров Виктор Сергеевна','15','own','denied','api','denied','Доступ приостановлен',NULL,'192.168.1.84',NULL,NULL,883,NULL,'{\"demo\":true}'),
(385,'a4a63888-e6b5-4f07-b797-a36a26488d52','2026-10-07 16:21:28',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','plate','open','api','success',NULL,NULL,'192.168.1.80',NULL,NULL,125,NULL,'{\"demo\":true}'),
(386,'7326034c-1a09-4e4f-84fa-cf005e7ef594','2026-10-07 19:34:34',NULL,1,'admin',17,NULL,NULL,'Козлов Иван Иванович','17','manual','open','telegram','success',NULL,NULL,'192.168.1.181',NULL,NULL,573,NULL,'{\"demo\":true}'),
(387,'e73533c3-550b-4b5e-b327-4f731650e36f','2026-10-07 07:11:33',NULL,1,'admin',7,NULL,NULL,'Соколов Сергей Сергеевна','7','manual','open','telegram','success',NULL,NULL,'192.168.1.44',NULL,NULL,799,NULL,'{\"demo\":true}'),
(388,'463b3b5a-c687-47b2-9c76-1bc6f908cd8f','2026-10-07 08:02:17',NULL,1,'admin',9,NULL,NULL,'Фёдоров Андрей Иванович','9','manual','open','telegram','success',NULL,NULL,'192.168.1.38',NULL,NULL,798,NULL,'{\"demo\":true}'),
(389,'f85505aa-e1b8-49f8-9439-16783e70f086','2026-10-07 18:37:44',NULL,1,'admin',2,NULL,NULL,'Петрова Мария Петрович','2','manual','open','api','success',NULL,NULL,'192.168.1.122',NULL,NULL,784,NULL,'{\"demo\":true}'),
(390,'7934409f-74c3-4353-8400-e785bdce8877','2026-10-07 18:25:23',NULL,1,'guest',17,NULL,NULL,'Козлов Иван Иванович','17','guest','open','admin','success',NULL,NULL,'192.168.1.191',NULL,NULL,843,NULL,'{\"demo\":true}'),
(391,'c8fa7b52-4e3c-45b9-a2a8-b399c6a9166d','2026-10-07 10:43:01',NULL,1,'admin',13,NULL,NULL,'Лебедев Николай Ивановна','13','manual','open','api','success',NULL,NULL,'192.168.1.75',NULL,NULL,646,NULL,'{\"demo\":true}'),
(392,'c745961e-43b2-4daf-a6e9-5e79ac1aa130','2026-10-07 23:16:23',NULL,1,'resident',16,NULL,NULL,'Павлова Юлия Николаевич','16','own','open','telegram','success',NULL,NULL,'192.168.1.59',NULL,NULL,538,NULL,'{\"demo\":true}'),
(393,'fe5c9453-920d-4d9a-8414-92d50d94b771','2026-10-07 12:39:20',NULL,1,'guest',11,NULL,NULL,'Волков Павел Сергеевич','11','guest','open','web','success',NULL,NULL,'192.168.1.186',NULL,NULL,692,NULL,'{\"demo\":true}'),
(394,'ab177939-fde4-43e7-860c-9a011433dbed','2026-10-07 12:59:49',NULL,1,'resident',11,NULL,NULL,'Волков Павел Сергеевич','11','own','open','telegram','success',NULL,NULL,'192.168.1.33',NULL,NULL,222,NULL,'{\"demo\":true}'),
(395,'71f95a3f-ef25-4025-acc0-6a18076452f9','2026-10-07 16:33:16',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','own','open','api','success',NULL,NULL,'192.168.1.161',NULL,NULL,590,NULL,'{\"demo\":true}'),
(396,'faec4c61-7022-4732-8324-aa3bc3cb8da0','2026-10-07 17:15:39',NULL,1,'admin',24,NULL,NULL,'Зайцева Елена Николаевич','24','manual','open','cabinet','success',NULL,NULL,'192.168.1.245',NULL,NULL,264,NULL,'{\"demo\":true}'),
(397,'02e205ab-f718-456f-bbed-600eb0956779','2026-10-07 09:06:05',NULL,1,'resident',4,NULL,NULL,'Кузнецова Ольга Андреевич','4','plate','open','admin','success',NULL,NULL,'192.168.1.230',NULL,NULL,865,NULL,'{\"demo\":true}'),
(398,'866a23e5-d9ac-438d-b301-ddd97eabe788','2026-10-07 06:32:34',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','plate','open','admin','success',NULL,NULL,'192.168.1.81',NULL,NULL,763,NULL,'{\"demo\":true}'),
(399,'7e162eb4-cc49-46ac-9233-4aa956b35d63','2026-10-07 15:51:59',NULL,1,'resident',19,NULL,NULL,'Николаев Алексей Сергеевич','19','own','open','telegram','success',NULL,NULL,'192.168.1.31',NULL,NULL,579,NULL,'{\"demo\":true}'),
(400,'1c8b6833-91a1-449c-97b5-59a1f25e96eb','2026-10-07 23:30:34',NULL,1,'guest',5,NULL,NULL,'Смирнов Дмитрий Ивановна','5','guest','open','api','success',NULL,NULL,'192.168.1.76',NULL,NULL,428,NULL,'{\"demo\":true}'),
(401,'c074ba8c-baff-4609-bfe3-e3000c42413d','2026-10-07 20:40:51',NULL,1,'resident',16,NULL,NULL,'Павлова Юлия Николаевич','16','own','open','web','success',NULL,NULL,'192.168.1.187',NULL,NULL,727,NULL,'{\"demo\":true}'),
(402,'bbbc36ef-de95-446f-9996-d7935067a523','2026-10-07 06:16:05',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','own','open','cabinet','success',NULL,NULL,'192.168.1.122',NULL,NULL,779,NULL,'{\"demo\":true}'),
(403,'4fb41f5f-426f-48b5-8bda-380a49e95cb6','2026-10-08 21:31:29',NULL,1,'resident',3,NULL,NULL,'Сидоров Алексей Сергеевич','3','own','open','admin','success',NULL,NULL,'192.168.1.81',NULL,NULL,775,NULL,'{\"demo\":true}'),
(404,'e9617a72-1f97-43e4-a817-eaaee0858446','2026-10-08 15:09:38',NULL,1,'resident',12,NULL,NULL,'Алексеева Екатерина Андреевич','12','plate','open','telegram','success',NULL,NULL,'192.168.1.106',NULL,NULL,774,NULL,'{\"demo\":true}'),
(405,'e9ee091e-0a23-46dd-a76c-bff677e033d5','2026-10-08 06:24:17',NULL,1,'resident',10,NULL,NULL,'Морозова Наталья Петрович','10','plate','denied','api','denied','Тихие часы',NULL,'192.168.1.199',NULL,NULL,768,NULL,'{\"demo\":true}'),
(406,'bd2537b0-8723-47b1-ac72-f3698e30d7e6','2026-10-08 13:09:02',NULL,1,'guest',2,NULL,NULL,'Петрова Мария Петрович','2','guest','open','api','success',NULL,NULL,'192.168.1.171',NULL,NULL,653,NULL,'{\"demo\":true}'),
(407,'197263e0-caa3-4968-b3f1-22f6cbafd9f9','2026-10-08 18:49:34',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','own','open','cabinet','success',NULL,NULL,'192.168.1.163',NULL,NULL,584,NULL,'{\"demo\":true}'),
(408,'8b4482af-6683-4cea-9b33-fd3cfdb7916a','2026-10-08 20:59:50',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','own','open','web','success',NULL,NULL,'192.168.1.24',NULL,NULL,578,NULL,'{\"demo\":true}'),
(409,'44694e23-a8df-4d3f-b7bb-6bd788ed2141','2026-10-08 13:44:59',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','api','success',NULL,NULL,'192.168.1.38',NULL,NULL,337,NULL,'{\"demo\":true}'),
(410,'fb55c26f-f751-4cb3-8eaf-05f073a4db6a','2026-10-09 13:02:05',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','own','open','telegram','success',NULL,NULL,'192.168.1.243',NULL,NULL,621,NULL,'{\"demo\":true}'),
(411,'c712e824-1424-4f6c-96d7-db666ed5c804','2026-10-09 20:20:44',NULL,1,'resident',13,NULL,NULL,'Лебедев Николай Ивановна','13','own','open','admin','success',NULL,NULL,'192.168.1.22',NULL,NULL,209,NULL,'{\"demo\":true}'),
(412,'943b80dd-d2bb-4b52-a8d9-f5b27cff49a3','2026-10-09 14:01:36',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','api','success',NULL,NULL,'192.168.1.217',NULL,NULL,323,NULL,'{\"demo\":true}'),
(413,'dde8cf24-47d0-474f-83f0-1f73560d8598','2026-10-09 19:26:49',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','own','open','cabinet','success',NULL,NULL,'192.168.1.98',NULL,NULL,865,NULL,'{\"demo\":true}'),
(414,'a8cfaecb-5a55-4ae6-8b12-9ae4be6045cd','2026-10-09 23:25:55',NULL,1,'resident',1,NULL,NULL,'Иванов Иван Иванович','1','own','open','web','success',NULL,NULL,'192.168.1.171',NULL,NULL,637,NULL,'{\"demo\":true}'),
(415,'a411a253-1bf1-470d-a392-8d029a0f624f','2026-10-09 06:05:33',NULL,1,'resident',21,NULL,NULL,'Андреев Дмитрий Ивановна','21','own','open','cabinet','success',NULL,NULL,'192.168.1.158',NULL,NULL,854,NULL,'{\"demo\":true}'),
(416,'7b0ec297-8f65-45b5-bd3a-6ca57ae48902','2026-10-09 15:46:47',NULL,1,'resident',20,NULL,NULL,'Орлова Ольга Андреевич','20','own','open','api','success',NULL,NULL,'192.168.1.104',NULL,NULL,900,NULL,'{\"demo\":true}'),
(417,'8dedc2c5-27f0-4ef9-85b5-17cfc857c996','2026-10-09 08:13:53',NULL,1,'resident',9,NULL,NULL,'Фёдоров Андрей Иванович','9','own','open','api','success',NULL,NULL,'192.168.1.225',NULL,NULL,180,NULL,'{\"demo\":true}'),
(418,'b99e917c-19b6-4b1c-bead-723584f881be','2026-10-09 10:41:08',NULL,1,'resident',2,NULL,NULL,'Петрова Мария Петрович','2','plate','open','cabinet','success',NULL,NULL,'192.168.1.198',NULL,NULL,515,NULL,'{\"demo\":true}'),
(419,'c5e122f6-1ab6-4f89-9be7-240516a7dad8','2026-10-09 20:31:03',NULL,1,'guest',20,NULL,NULL,'Орлова Ольга Андреевич','20','guest','open','api','success',NULL,NULL,'192.168.1.136',NULL,NULL,299,NULL,'{\"demo\":true}'),
(420,'097db8d7-b146-4f2a-83d0-c0ce39a2a78f','2026-10-09 09:53:16',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','cabinet','success',NULL,NULL,'192.168.1.25',NULL,NULL,291,NULL,'{\"demo\":true}'),
(421,'cb737964-e607-4fd2-85a4-ea6ff4c0efda','2026-10-09 10:45:13',NULL,1,'resident',18,NULL,NULL,'Степанова Мария Петрович','18','plate','open','cabinet','success',NULL,NULL,'192.168.1.99',NULL,NULL,360,NULL,'{\"demo\":true}'),
(422,'d3b5b536-4e69-46aa-aab1-7900402410b2','2026-10-09 19:16:32',NULL,1,'resident',11,NULL,NULL,'Волков Павел Сергеевич','11','own','open','cabinet','success',NULL,NULL,'192.168.1.141',NULL,NULL,797,NULL,'{\"demo\":true}'),
(423,'f60999a1-7f0a-44b3-a3d9-a0dcabfa24a0','2026-10-09 14:28:37',NULL,1,'resident',17,NULL,NULL,'Козлов Иван Иванович','17','own','open','admin','success',NULL,NULL,'192.168.1.141',NULL,NULL,784,NULL,'{\"demo\":true}'),
(424,'fcc9fd4d-7b94-4492-be2a-9604905cb64e','2026-10-09 20:19:46',NULL,1,'resident',7,NULL,NULL,'Соколов Сергей Сергеевна','7','own','open','admin','success',NULL,NULL,'192.168.1.233',NULL,NULL,716,NULL,'{\"demo\":true}'),
(425,'3d26fd3f-b973-405b-90d2-ff4ad594c929','2026-10-09 19:54:38',NULL,1,'resident',1,NULL,NULL,'Иванов Иван Иванович','1','own','open','cli','success',NULL,NULL,NULL,'cli',NULL,63,NULL,'{\"ok\":true,\"message\":\"Шлагбаум открыт (эмулятор)\"}'),
(426,'7672ea4a-e9c3-4ac9-8985-ce1a881ee404','2026-10-09 19:54:38',NULL,1,'guest',1,NULL,7,'Иванов Иван Иванович','1','guest','issued','cli','success','Гостевой доступ issued: F3WU-Z3E6 до 2026-10-10 07:54:38',NULL,NULL,NULL,NULL,NULL,NULL,'{\"code\":\"F3WU-Z3E6\",\"ttl_hours\":12,\"valid_until\":\"2026-10-10 07:54:38\",\"guest_name\":\"Курьер\"}'),
(427,'6e806817-6dfe-41d9-8e68-d43651a8fdd4','2026-10-09 19:54:38',NULL,1,'guest',1,NULL,7,'Иванов Иван Иванович (гость Курьер)','1','guest','open','web','success',NULL,NULL,NULL,'cli',NULL,61,NULL,'{\"ok\":true,\"message\":\"Шлагбаум открыт (эмулятор)\"}'),
(428,'0fcd2a41-826d-4a23-a494-36fe1b0e543a','2026-10-09 19:54:38',NULL,1,'guest',1,NULL,7,'Иванов Иван Иванович','1','guest','revoked','cli','success','smoke',NULL,NULL,NULL,NULL,NULL,NULL,'{\"code\":\"F3WU-Z3E6\",\"ttl_hours\":12,\"valid_until\":\"2026-10-10 07:54:38\",\"guest_name\":\"Курьер\"}'),
(429,'641cb6f9-e5a9-4253-8ac0-b580c0749e23','2026-10-09 19:54:38',NULL,1,'resident',1,NULL,NULL,'Иванов Иван Иванович','1','own','denied','web','denied','Доступ приостановлен (снята галочка «доступ»).',NULL,NULL,'cli',NULL,NULL,NULL,'{\"code\":\"no_access\"}');
/*!40000 ALTER TABLE `gate_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guest_passes`
--

DROP TABLE IF EXISTS `guest_passes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `guest_passes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `code` varchar(24) NOT NULL DEFAULT '',
  `token_hash` varchar(128) NOT NULL DEFAULT '',
  `pin` varchar(12) DEFAULT NULL,
  `resident_id` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_by_type` varchar(16) NOT NULL DEFAULT 'resident',
  `guest_name` varchar(190) DEFAULT NULL,
  `guest_phone` varchar(32) DEFAULT NULL,
  `car_plate` varchar(32) DEFAULT NULL,
  `car_plate_normalized` varchar(32) DEFAULT NULL,
  `purpose` varchar(190) DEFAULT NULL,
  `max_guests` int(11) NOT NULL DEFAULT 1,
  `valid_from` datetime DEFAULT NULL,
  `valid_until` datetime DEFAULT NULL,
  `ttl_hours` int(11) NOT NULL DEFAULT 12,
  `max_uses` int(11) NOT NULL DEFAULT 0,
  `used_count` int(11) NOT NULL DEFAULT 0,
  `last_used_at` datetime DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'active',
  `revoked_at` datetime DEFAULT NULL,
  `revoked_by` bigint(20) unsigned DEFAULT NULL,
  `revoke_reason` varchar(190) DEFAULT NULL,
  `ip_created` varchar(45) DEFAULT NULL,
  `ip_last_used` varchar(45) DEFAULT NULL,
  `notify_on_use` tinyint(1) NOT NULL DEFAULT 0,
  `meta` longtext DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `guest_passes_uuid_unique` (`uuid`),
  UNIQUE KEY `guest_passes_code_unique` (`code`),
  UNIQUE KEY `guest_passes_token_hash_unique` (`token_hash`),
  KEY `guest_passes_resident_id_status_index` (`resident_id`,`status`),
  KEY `guest_passes_status_valid_until_index` (`status`,`valid_until`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guest_passes`
--

LOCK TABLES `guest_passes` WRITE;
/*!40000 ALTER TABLE `guest_passes` DISABLE KEYS */;
INSERT INTO `guest_passes` VALUES
(1,'4dba866a-fd9e-44cf-8fac-bd3654f463c0','EE8T-5EV7','hash:sha256:0e18b28df295d5ac7a242f5d279b4193e78a67db940d30b56b135498c5bd0625','731317',5,NULL,'resident','Друг семьи',NULL,NULL,NULL,'Клининг',1,'2026-10-09 13:54:30','2026-10-10 01:54:30',12,0,2,'2026-10-09 14:54:30','active',NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-10-09 13:54:30','2026-10-09 13:54:30'),
(2,'4ebc4c69-1d0d-4f09-8fe8-0afda6683ac1','KZ27-3V8H','hash:sha256:9479b5336845c1c977570d8d8df360605c4e9cc52acc78df6ae984711b77ccd2','568802',2,NULL,'resident','Мастер по ремонту',NULL,NULL,NULL,'Родственники',1,'2026-10-09 19:54:30','2026-10-10 07:54:30',12,0,3,'2026-10-09 20:54:30','active',NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(3,'9adf9e5d-7c63-42be-acf7-f3fa557b35f6','KXL2-LH5X','hash:sha256:97fe6abfc4388777dbdf6085eba3333267697462bda006b53afb5b4f9b46e3de','469313',2,NULL,'resident','Друг семьи',NULL,NULL,NULL,'Клининг',1,'2026-10-09 01:54:30','2026-10-09 13:54:30',12,0,1,'2026-10-09 02:54:30','expired',NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-10-09 01:54:30','2026-10-09 01:54:30'),
(4,'806e17ca-81f1-4679-8f6c-9b4199605759','KBME-L6C3','hash:sha256:c45266bcce40d5595d8b83a99c3aca6b05f785bb622e0b28fab8a877954d9465','881885',5,NULL,'resident','Друг семьи',NULL,NULL,NULL,'Курьер',1,'2026-10-09 11:54:30','2026-10-09 23:54:30',12,0,0,'2026-10-09 12:54:30','active',NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-10-09 11:54:30','2026-10-09 11:54:30'),
(5,'e963b2c1-5e3f-4e5a-b83b-5e70a3dd54e0','8BM8-RYK2','hash:sha256:c65e1cf0fc874edb5774fa2d56013ea3b4417929baa725ffc7025638455a4102','904974',7,NULL,'resident','Доставка',NULL,NULL,NULL,'Родственники',1,'2026-10-09 07:54:30','2026-10-09 19:54:30',12,0,0,'2026-10-09 08:54:30','active',NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-10-09 07:54:30','2026-10-09 07:54:30'),
(6,'5254213a-2a9c-4911-b76f-6a52628bb4f3','9E48-UZ6Y','hash:sha256:57bb9a4d1449b94be28676949ee6678014ec02929a9df95a6784d0aa7e93e1cb','871107',3,NULL,'resident','Гость',NULL,NULL,NULL,'Ремонт',1,'2026-10-09 11:54:30','2026-10-09 23:54:30',12,0,2,'2026-10-09 12:54:30','active',NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-10-09 11:54:30','2026-10-09 11:54:30'),
(7,'9114beb5-1963-4da8-ba9d-6f055a5e40fc','F3WU-Z3E6','hash:sha256:748569b2d1da474e7466476ee2f32167ed00a720a03bdd0d1b916f695aa46086','402915',1,1,'resident','Курьер',NULL,NULL,NULL,NULL,1,'2026-10-09 19:54:38','2026-10-10 07:54:38',12,0,1,'2026-10-09 19:54:38','revoked','2026-10-09 19:54:38',NULL,'smoke',NULL,NULL,0,NULL,'2026-10-09 19:54:38','2026-10-09 19:54:38');
/*!40000 ALTER TABLE `guest_passes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `import_jobs`
--

DROP TABLE IF EXISTS `import_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `import_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `kind` varchar(24) NOT NULL DEFAULT 'residents',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `format` varchar(12) NOT NULL DEFAULT 'csv',
  `mode` varchar(16) NOT NULL DEFAULT 'upsert',
  `rows_total` int(11) NOT NULL DEFAULT 0,
  `rows_imported` int(11) NOT NULL DEFAULT 0,
  `rows_skipped` int(11) NOT NULL DEFAULT 0,
  `rows_failed` int(11) NOT NULL DEFAULT 0,
  `errors` longtext DEFAULT NULL,
  `mapping` longtext DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'running',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `finished_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `import_jobs_uuid_unique` (`uuid`),
  KEY `import_jobs_kind_started_at_index` (`kind`,`started_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `import_jobs`
--

LOCK TABLES `import_jobs` WRITE;
/*!40000 ALTER TABLE `import_jobs` DISABLE KEYS */;
INSERT INTO `import_jobs` VALUES
(1,'ee4f7b91-9121-4aa4-812b-750611b64b5e','residents','upload','csv','dry-run',24,24,0,0,'[]',NULL,'done',NULL,'2026-10-09 19:54:38','2026-10-09 19:54:38');
/*!40000 ALTER TABLE `import_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `number` varchar(48) NOT NULL DEFAULT '',
  `charge_id` bigint(20) unsigned DEFAULT NULL,
  `resident_id` bigint(20) unsigned NOT NULL,
  `parent_invoice_id` bigint(20) unsigned DEFAULT NULL,
  `kind` varchar(16) NOT NULL DEFAULT 'regular',
  `amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `balance` decimal(14,2) NOT NULL DEFAULT 0.00,
  `period_start` date DEFAULT NULL,
  `period_end` date DEFAULT NULL,
  `period_label` varchar(64) NOT NULL DEFAULT '',
  `due_date` date DEFAULT NULL,
  `issued_date` date DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'pending',
  `pay_link` varchar(512) DEFAULT NULL,
  `note` longtext DEFAULT NULL,
  `recalc_reason` varchar(255) DEFAULT NULL,
  `issued_at` datetime DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `voided_at` datetime DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoices_uuid_unique` (`uuid`),
  KEY `invoices_resident_id_status_index` (`resident_id`,`status`),
  KEY `invoices_charge_id_index` (`charge_id`),
  KEY `invoices_status_due_date_index` (`status`,`due_date`),
  KEY `invoices_period_start_index` (`period_start`),
  CONSTRAINT `invoices_resident_id_fk` FOREIGN KEY (`resident_id`) REFERENCES `residents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES
(1,'ca0de1b7-2073-436a-9a39-63c184ccb004','СЧ-2026-00001',1,1,NULL,'regular',750.00,750.00,0.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','paid','https://pay.example.com/barrier?apt=1&amount=750.00',NULL,NULL,'2026-09-30 00:00:00','2026-10-23 00:00:00',NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:54:30'),
(2,'5d44b7b4-12c0-427d-a624-94efbb64261d','СЧ-2026-00002',1,2,NULL,'regular',750.00,750.00,0.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','paid','https://pay.example.com/barrier?apt=2&amount=750.00',NULL,NULL,'2026-09-30 00:00:00','2026-10-24 00:00:00',NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:54:30'),
(3,'33b06b46-c16a-4f16-b0b3-a5b4859251b9','СЧ-2026-00003',1,3,NULL,'regular',750.00,375.00,375.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','partial','https://pay.example.com/barrier?apt=3&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:54:30'),
(4,'968a93cd-985a-4cf9-91a9-0bc643a26e5b','СЧ-2026-00004',1,5,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','pending','https://pay.example.com/barrier?apt=5&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:54:30'),
(5,'c6a1ba5a-9795-4008-93f9-dfaeb45913dd','СЧ-2026-00005',1,6,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','pending','https://pay.example.com/barrier?apt=6&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:54:30'),
(6,'437d9409-ff2e-485a-ace8-5d3c99051536','СЧ-2026-00006',1,7,NULL,'regular',750.00,750.00,0.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','paid','https://pay.example.com/barrier?apt=7&amount=750.00',NULL,NULL,'2026-09-30 00:00:00','2026-10-01 00:00:00',NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:54:30'),
(7,'4d5a919d-7438-4e41-b60d-98495aff0a47','СЧ-2026-00007',1,9,NULL,'regular',750.00,750.00,0.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','paid','https://pay.example.com/barrier?apt=9&amount=750.00',NULL,NULL,'2026-09-30 00:00:00','2026-10-12 00:00:00',NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:54:30'),
(8,'c1154db2-0748-4082-96ea-eff1289183d7','СЧ-2026-00008',1,10,NULL,'regular',750.00,375.00,375.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','partial','https://pay.example.com/barrier?apt=10&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:54:30'),
(9,'7ceb272b-79d4-472b-b3d8-825986cce364','СЧ-2026-00009',1,11,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','pending','https://pay.example.com/barrier?apt=11&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:54:30'),
(10,'f30e98ca-d1e1-4ccd-ae46-cb551d70c233','СЧ-2026-00010',1,12,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','pending','https://pay.example.com/barrier?apt=12&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:54:30'),
(11,'58cbc717-c042-4bcb-8455-69438f9d1e81','СЧ-2026-00011',1,13,NULL,'regular',750.00,750.00,0.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','paid','https://pay.example.com/barrier?apt=13&amount=750.00',NULL,NULL,'2026-09-30 00:00:00','2026-10-19 00:00:00',NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:54:30'),
(12,'88b75422-d9a5-4a1a-bf3f-f20f39ddffcb','СЧ-2026-00012',1,14,NULL,'regular',750.00,750.00,0.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','paid','https://pay.example.com/barrier?apt=14&amount=750.00',NULL,NULL,'2026-09-30 00:00:00','2026-10-25 00:00:00',NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:54:30'),
(13,'85ee56cd-22d9-413d-89eb-02a26c3108db','СЧ-2026-00013',1,15,NULL,'regular',750.00,375.00,375.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','partial','https://pay.example.com/barrier?apt=15&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:54:30'),
(14,'01e32d00-72f2-40b8-8387-3b21e58545b6','СЧ-2026-00014',1,16,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','pending','https://pay.example.com/barrier?apt=16&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:54:30'),
(15,'2d2ca0bb-8cbe-42b3-9f28-332edcfd29e8','СЧ-2026-00015',1,18,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','pending','https://pay.example.com/barrier?apt=18&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:54:30'),
(16,'466ec7d2-4b0f-499b-b21c-f441799f936d','СЧ-2026-00016',1,20,NULL,'regular',750.00,750.00,0.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','paid','https://pay.example.com/barrier?apt=20&amount=750.00',NULL,NULL,'2026-09-30 00:00:00','2026-10-25 00:00:00',NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:54:30'),
(17,'f00b9f06-ea2f-49db-9c6f-308f0b431e74','СЧ-2026-00017',1,21,NULL,'regular',750.00,750.00,0.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','paid','https://pay.example.com/barrier?apt=21&amount=750.00',NULL,NULL,'2026-09-30 00:00:00','2026-10-09 00:00:00',NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:54:30'),
(18,'2efadf04-1e85-44ae-be6d-f5ec6c7cf506','СЧ-2026-00018',1,22,NULL,'regular',750.00,375.00,375.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','partial','https://pay.example.com/barrier?apt=22&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:54:30'),
(19,'dd72774b-61fb-4abf-b76b-d06deccccd65','СЧ-2026-00019',1,23,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','pending','https://pay.example.com/barrier?apt=23&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:54:30'),
(20,'8d3929c5-0593-4ef0-8656-c65fdbbda146','СЧ-2026-00020',1,24,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-14','2026-09-30','pending','https://pay.example.com/barrier?apt=24&amount=750.00',NULL,NULL,'2026-09-30 00:00:00',NULL,NULL,NULL,'2026-09-30 00:00:00','2026-10-09 19:54:30'),
(21,'a91e90a1-a68e-4a03-a411-19bcd88a5944','СЧ-2026-90001-Д',1,1,1,'adjustment',150.00,0.00,150.00,NULL,NULL,'Сентябрь 2026','2026-10-09','2026-10-09','pending',NULL,'Перерасчёт: увеличение стоимости ТО привода','Перерасчёт: сумма 15 000 → 15 150','2026-10-09 19:54:30',NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(22,'8633764b-0dbe-488a-a7b2-737bea5e6b55','СЧ-2026-90002-С',1,2,2,'credit',-100.00,0.00,-100.00,NULL,NULL,'Сентябрь 2026','2026-10-09','2026-10-09','pending',NULL,'Сторно: отсутствие в период обслуживания',NULL,'2026-10-09 19:54:30',NULL,NULL,NULL,'2026-10-09 19:54:30','2026-10-09 19:54:30'),
(23,'c53bac17-0add-41fe-a4bb-589bf1f56e23','INV-2026-00001',2,1,NULL,'regular',750.00,750.00,0.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','paid',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 00:00:00',NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(24,'3ba377e4-0cd9-44ad-b217-9a163742f105','INV-2026-00002',2,2,NULL,'regular',750.00,750.00,0.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','paid',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 00:00:00',NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(25,'ae26a890-a36c-4e06-9edb-7063d6990c21','INV-2026-00003',2,3,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(26,'4b284dbb-fe4b-48d6-93b7-0e2da8065ed6','INV-2026-00004',2,5,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(27,'15dc035f-feab-4756-bbfb-dd2070ee5c28','INV-2026-00005',2,6,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(28,'afdec459-ed8d-4b57-9b1c-c23b792f98de','INV-2026-00006',2,7,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(29,'a2e5cd03-53ad-436a-8672-7638bd3add9a','INV-2026-00007',2,9,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(30,'936c9d26-c256-4649-a9c4-224063fe288a','INV-2026-00008',2,10,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(31,'3e146869-588a-4369-8e67-e7cb38348727','INV-2026-00009',2,11,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(32,'49e7371e-38e8-4813-82ff-86ffd2bad394','INV-2026-00010',2,12,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(33,'a94d45e1-7b82-4fb7-a3f8-2461688a43fb','INV-2026-00011',2,13,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(34,'ec6c48b4-e70a-4d72-9579-4f12bbd28920','INV-2026-00012',2,14,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(35,'651627b3-774f-4e41-b150-dc8209e69d16','INV-2026-00013',2,15,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(36,'c71fad2b-297e-4017-9597-f33fd1756823','INV-2026-00014',2,16,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(37,'bc51ad08-b97d-4594-8e2a-8b853f10ac1c','INV-2026-00015',2,18,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(38,'920ce6b7-3f30-45aa-afe1-093dd180bce6','INV-2026-00016',2,20,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(39,'301a38ea-8f80-484e-ab9c-e835131db65b','INV-2026-00017',2,21,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(40,'b53ccca5-cd6c-46ef-adca-a6fe66103aae','INV-2026-00018',2,22,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(41,'37f03a50-ffb7-488b-a358-0997f232ad74','INV-2026-00019',2,23,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(42,'a25d1990-1dbc-493b-9076-de519e73cb41','INV-2026-00020',2,24,NULL,'regular',750.00,0.00,750.00,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,NULL,NULL,'2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(43,'ce17d17a-74b3-46da-82ec-9f466972fff7','INV-2026-00021-Д',2,1,23,'adjustment',68.19,0.00,68.19,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(44,'4f69f0a7-a75c-43ce-ac33-ec43d0b7ea31','INV-2026-00022-Д',2,2,24,'adjustment',68.19,0.00,68.19,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(45,'f4cbfe0c-c977-41ea-ac9a-aee2812c3591','INV-2026-00023-Д',2,3,25,'adjustment',68.19,0.00,68.19,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(46,'f7f571c9-cb17-468d-8c3e-821a30f7778c','INV-2026-00024-Д',2,5,26,'adjustment',68.19,0.00,68.19,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(47,'dee331ac-9167-490d-a1c8-726831035636','INV-2026-00025-Д',2,6,27,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(48,'b2d16e33-2d06-4df0-bfff-af4dee89d7e3','INV-2026-00026-Д',2,7,28,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(49,'b2bcbce9-6e39-4cb8-a06e-f3760733b767','INV-2026-00027-Д',2,9,29,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(50,'5cdd90f0-9fc0-4c71-9d4d-2f2c73f4ece6','INV-2026-00028-Д',2,10,30,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(51,'75feda78-f2fd-4843-8368-053a8d197288','INV-2026-00029-Д',2,11,31,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(52,'0fae5ebc-f3c6-4267-bac7-35a99a5cfcd9','INV-2026-00030-Д',2,12,32,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(53,'96eb35e3-707e-4bc3-b62b-ea668739a59d','INV-2026-00031-Д',2,13,33,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(54,'d35412c3-21ef-4d4b-af3d-618b84685fd7','INV-2026-00032-Д',2,14,34,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(55,'ec199e5c-efe2-4387-af0d-d505121e035b','INV-2026-00033-Д',2,15,35,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(56,'05620514-b66e-4455-ad3c-b05a0b1d3eb9','INV-2026-00034-Д',2,16,36,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(57,'f30ad936-e775-4132-8361-63fd487708b6','INV-2026-00035-Д',2,18,37,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(58,'2797deb9-7caa-4c6e-969a-1708a565ba7c','INV-2026-00036-Д',2,20,38,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(59,'0a5d60fc-fb42-4c4c-a65c-c10a9426d660','INV-2026-00037-Д',2,21,39,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(60,'342194c4-c348-485f-97eb-4f9888f7cb15','INV-2026-00038-Д',2,22,40,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(61,'e74a8aca-ab88-41b2-ac83-512d42f686a3','INV-2026-00039-Д',2,23,41,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(62,'75c415e4-34b6-408c-94c5-5c950ba780e5','INV-2026-00040-Д',2,24,42,'adjustment',68.18,0.00,68.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(63,'a9d5baf4-8942-40a0-9faa-12c3b75bd389','INV-2026-00041',2,8,NULL,'regular',818.18,0.00,818.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(64,'ead95159-f6d1-49c5-a3ae-a4b8ecd12a91','INV-2026-00042',2,19,NULL,'regular',818.18,0.00,818.18,'2026-09-01','2026-09-30','Сентябрь 2026','2026-10-23','2026-10-09','pending',NULL,'Перерасчёт: Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','Перерасчёт: сумма 15 000 ₽ → 18 000 ₽, участников 20 → 22','2026-10-09 19:54:32',NULL,NULL,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32');
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_attempts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(190) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(512) DEFAULT NULL,
  `successful` tinyint(1) NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `reason` varchar(64) DEFAULT NULL,
  `method` varchar(16) NOT NULL DEFAULT 'password',
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `login_attempts_ip_created_at_index` (`ip`,`created_at`),
  KEY `login_attempts_identifier_created_at_index` (`identifier`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--

LOCK TABLES `login_attempts` WRITE;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(190) NOT NULL DEFAULT '',
  `batch` int(11) NOT NULL DEFAULT 0,
  `checksum` varchar(64) DEFAULT NULL,
  `duration_ms` int(11) DEFAULT NULL,
  `executed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `migrations_migration_unique` (`migration`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'2026_01_01_000100_create_core_tables.php',1,'0d4480174cb41027f47e659dfa94b3f3b28ce8b360b8fe050ffa2eb0310ea5cd',7,'2026-10-09 19:54:30'),
(2,'2026_01_01_000200_create_residents_tables.php',1,'efc3f0db2311618f169f894271425521046f451ca0b33563a2e521c22148fd8e',8,'2026-10-09 19:54:30'),
(3,'2026_01_01_000300_create_billing_tables.php',1,'7ba60ffa9c016cfd94f930b78a1f45de15c0773b2763c035399387f3499bcaf4',6,'2026-10-09 19:54:30'),
(4,'2026_01_01_000400_create_gate_tables.php',1,'a19e5b98bf79ec7567acfa446c52894cb00c1357405a84cf9e03666d98c3906d',3,'2026-10-09 19:54:30'),
(5,'2026_01_01_000500_create_messaging_tables.php',1,'15f0152efb8f32af6bc5566e05eb336400c65dbe95300953d52dfd3fc54b8a7f',12,'2026-10-09 19:54:30');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_batches`
--

DROP TABLE IF EXISTS `notification_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_batches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `name` varchar(190) NOT NULL DEFAULT '',
  `template` varchar(64) NOT NULL DEFAULT 'custom',
  `subject` varchar(255) DEFAULT NULL,
  `message` longtext DEFAULT NULL,
  `pay_link` longtext DEFAULT NULL,
  `charge_id` bigint(20) unsigned DEFAULT NULL,
  `channels` longtext DEFAULT NULL,
  `audience` longtext DEFAULT NULL,
  `recipients` int(11) NOT NULL DEFAULT 0,
  `sent` int(11) NOT NULL DEFAULT 0,
  `failed` int(11) NOT NULL DEFAULT 0,
  `skipped` int(11) NOT NULL DEFAULT 0,
  `status` varchar(16) NOT NULL DEFAULT 'queued',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `finished_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `notification_batches_uuid_unique` (`uuid`),
  KEY `notification_batches_status_index` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_batches`
--

LOCK TABLES `notification_batches` WRITE;
/*!40000 ALTER TABLE `notification_batches` DISABLE KEYS */;
INSERT INTO `notification_batches` VALUES
(1,'af4a7025-265b-4cad-9094-33cb5dbc2182','Рассылка по начислению CHG-2026-0001','payment_new',NULL,NULL,NULL,2,'[\"log\"]',NULL,38,38,0,0,'done',NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32','2026-10-09 19:54:38');
/*!40000 ALTER TABLE `notification_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `outbox`
--

DROP TABLE IF EXISTS `outbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `outbox` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `batch_id` bigint(20) unsigned DEFAULT NULL,
  `channel` varchar(24) NOT NULL DEFAULT 'log',
  `resident_id` bigint(20) unsigned DEFAULT NULL,
  `recipient` varchar(255) NOT NULL DEFAULT '',
  `subject` varchar(255) DEFAULT NULL,
  `body` longtext DEFAULT NULL,
  `template` varchar(64) DEFAULT NULL,
  `context` longtext DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'pending',
  `attempts` int(11) NOT NULL DEFAULT 0,
  `max_attempts` int(11) NOT NULL DEFAULT 5,
  `last_error` longtext DEFAULT NULL,
  `provider_id` varchar(128) DEFAULT NULL,
  `scheduled_at` datetime DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `outbox_uuid_unique` (`uuid`),
  KEY `outbox_status_scheduled_at_index` (`status`,`scheduled_at`),
  KEY `outbox_batch_id_index` (`batch_id`),
  KEY `outbox_resident_id_index` (`resident_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `outbox`
--

LOCK TABLES `outbox` WRITE;
/*!40000 ALTER TABLE `outbox` DISABLE KEYS */;
INSERT INTO `outbox` VALUES
(1,'a16dbd7b-2e09-4a6b-ad1f-abe394fd50e5',1,'log',23,'Zaharov.s23@example.com','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Иванов И. И.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 1.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Иванов И. И.\",\"full_name\":\"Иванов Иван Иванович\",\"apartment\":\"1\",\"building\":\"1\",\"address\":\"корп. 1, кв. 1\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00001\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-218,19 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:8dfa07ddf049','2026-10-09 19:54:32','2026-10-09 19:54:32','2026-10-09 19:54:32'),
(2,'b3bd7987-464d-4387-9d30-172dbf182433',1,'log',43,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Иванов И. И.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,19 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 1.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Иванов И. И.\",\"full_name\":\"Иванов Иван Иванович\",\"apartment\":\"1\",\"building\":\"1\",\"address\":\"корп. 1, кв. 1\",\"amount\":\"68,19 ₽\",\"amount_raw\":68.19,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00021-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-218,19 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:5b04b4908014','2026-10-09 19:54:32','2026-10-09 19:54:32','2026-10-09 19:54:32'),
(3,'3ba5e8a3-caf8-4c30-91b1-9c75def159f4',1,'log',24,'Zayceva.e24@example.com','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Петрова М. П.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 2.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Петрова М. П.\",\"full_name\":\"Петрова Мария Петрович\",\"apartment\":\"2\",\"building\":\"1\",\"address\":\"корп. 1, кв. 2\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00002\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"31,81 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:25f4ebb7ad63','2026-10-09 19:54:32','2026-10-09 19:54:32','2026-10-09 19:54:32'),
(4,'f699dfbf-548e-466d-9d62-1f414f0430c2',1,'log',44,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Петрова М. П.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,19 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 2.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Петрова М. П.\",\"full_name\":\"Петрова Мария Петрович\",\"apartment\":\"2\",\"building\":\"1\",\"address\":\"корп. 1, кв. 2\",\"amount\":\"68,19 ₽\",\"amount_raw\":68.19,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00022-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"31,81 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:c127ecde00e9','2026-10-09 19:54:32','2026-10-09 19:54:32','2026-10-09 19:54:32'),
(5,'0fa0d648-dd03-4065-92a2-14af0ec7b414',1,'log',25,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Сидоров А. С.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 3.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Сидоров А. С.\",\"full_name\":\"Сидоров Алексей Сергеевич\",\"apartment\":\"3\",\"building\":\"1\",\"address\":\"корп. 1, кв. 3\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00003\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 193,19 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:bf161d6e40f8','2026-10-09 19:54:32','2026-10-09 19:54:32','2026-10-09 19:54:32'),
(6,'154c48d9-be08-438b-b4a1-bf0763ccf3d8',1,'log',45,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Сидоров А. С.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,19 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 3.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Сидоров А. С.\",\"full_name\":\"Сидоров Алексей Сергеевич\",\"apartment\":\"3\",\"building\":\"1\",\"address\":\"корп. 1, кв. 3\",\"amount\":\"68,19 ₽\",\"amount_raw\":68.19,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00023-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 193,19 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:72a8f276d4b1','2026-10-09 19:54:32','2026-10-09 19:54:33','2026-10-09 19:54:32'),
(7,'0a863da6-76be-45ba-8e5b-48573fad78e1',1,'log',26,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Смирнов Д. И.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 5.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Смирнов Д. И.\",\"full_name\":\"Смирнов Дмитрий Ивановна\",\"apartment\":\"5\",\"building\":\"1\",\"address\":\"корп. 1, кв. 5\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00004\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,19 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:4b11da693bad','2026-10-09 19:54:32','2026-10-09 19:54:33','2026-10-09 19:54:32'),
(8,'f8a9018d-e6b3-4e17-a019-625a1bb15c63',1,'log',46,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Смирнов Д. И.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,19 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 5.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Смирнов Д. И.\",\"full_name\":\"Смирнов Дмитрий Ивановна\",\"apartment\":\"5\",\"building\":\"1\",\"address\":\"корп. 1, кв. 5\",\"amount\":\"68,19 ₽\",\"amount_raw\":68.19,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00024-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,19 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:80862af90713','2026-10-09 19:54:32','2026-10-09 19:54:33','2026-10-09 19:54:32'),
(9,'bdae8dd5-f3eb-464b-bf9e-e103b8a14275',1,'log',27,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Васильева А. П.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 6.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Васильева А. П.\",\"full_name\":\"Васильева Анна Петровна\",\"apartment\":\"6\",\"building\":\"1\",\"address\":\"корп. 1, кв. 6\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00005\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:9825be0da173','2026-10-09 19:54:32','2026-10-09 19:54:33','2026-10-09 19:54:32'),
(10,'17fd395d-f5d1-4e6e-ba21-c678a05dd8d9',1,'log',47,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Васильева А. П.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 6.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Васильева А. П.\",\"full_name\":\"Васильева Анна Петровна\",\"apartment\":\"6\",\"building\":\"1\",\"address\":\"корп. 1, кв. 6\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00025-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:84153ef460a1','2026-10-09 19:54:32','2026-10-09 19:54:33','2026-10-09 19:54:32'),
(11,'098c9b03-7649-458a-bb6c-59dcb5d21f90',1,'log',28,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Соколов С. С.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 7.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Соколов С. С.\",\"full_name\":\"Соколов Сергей Сергеевна\",\"apartment\":\"7\",\"building\":\"1\",\"address\":\"корп. 1, кв. 7\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00006\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:02ef00e3a5cf','2026-10-09 19:54:32','2026-10-09 19:54:33','2026-10-09 19:54:32'),
(12,'392dd342-bc19-4219-b535-00cdc99f6401',1,'log',48,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Соколов С. С.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 7.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Соколов С. С.\",\"full_name\":\"Соколов Сергей Сергеевна\",\"apartment\":\"7\",\"building\":\"1\",\"address\":\"корп. 1, кв. 7\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00026-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:85e4ea26e8e5','2026-10-09 19:54:32','2026-10-09 19:54:34','2026-10-09 19:54:32'),
(13,'0e52fba4-26b5-4496-b10a-52c9c4ebf890',1,'log',63,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Михайлова Е. Н.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 818,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 8.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Михайлова Е. Н.\",\"full_name\":\"Михайлова Елена Николаевич\",\"apartment\":\"8\",\"building\":\"1\",\"address\":\"корп. 1, кв. 8\",\"amount\":\"818,18 ₽\",\"amount_raw\":818.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00041\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:fca52b8561d4','2026-10-09 19:54:32','2026-10-09 19:54:34','2026-10-09 19:54:32'),
(14,'5112443d-f73b-4d43-bf91-8c0b0edd0a4c',1,'log',30,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Морозова Н. П.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 10.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Морозова Н. П.\",\"full_name\":\"Морозова Наталья Петрович\",\"apartment\":\"10\",\"building\":\"1\",\"address\":\"корп. 1, кв. 10\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00008\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 193,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:1ad1f5c82b7a','2026-10-09 19:54:32','2026-10-09 19:54:34','2026-10-09 19:54:32'),
(15,'6ccefb44-5754-4294-a8b9-210a49f8a9af',1,'log',50,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Морозова Н. П.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 10.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Морозова Н. П.\",\"full_name\":\"Морозова Наталья Петрович\",\"apartment\":\"10\",\"building\":\"1\",\"address\":\"корп. 1, кв. 10\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00028-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 193,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:0f2eef3988c8','2026-10-09 19:54:32','2026-10-09 19:54:34','2026-10-09 19:54:32'),
(16,'f8908e16-7818-403a-89ef-8b1b0ce37844',1,'log',31,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Волков П. С.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 11.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Волков П. С.\",\"full_name\":\"Волков Павел Сергеевич\",\"apartment\":\"11\",\"building\":\"1\",\"address\":\"корп. 1, кв. 11\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00009\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:10a299184d09','2026-10-09 19:54:32','2026-10-09 19:54:34','2026-10-09 19:54:32'),
(17,'f8f67d6a-4977-4a9d-be6f-c90562737710',1,'log',51,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Волков П. С.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 11.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Волков П. С.\",\"full_name\":\"Волков Павел Сергеевич\",\"apartment\":\"11\",\"building\":\"1\",\"address\":\"корп. 1, кв. 11\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00029-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:3bf4b5f06a68','2026-10-09 19:54:32','2026-10-09 19:54:34','2026-10-09 19:54:32'),
(18,'ccd907ee-e35b-4623-81c2-0eba13bf0cd3',1,'log',32,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Алексеева Е. А.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 12.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Алексеева Е. А.\",\"full_name\":\"Алексеева Екатерина Андреевич\",\"apartment\":\"12\",\"building\":\"1\",\"address\":\"корп. 1, кв. 12\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00010\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:a7c30d8d556d','2026-10-09 19:54:32','2026-10-09 19:54:34','2026-10-09 19:54:32'),
(19,'e603c470-b607-4822-b6d5-6b077bb19959',1,'log',52,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Алексеева Е. А.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 12.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Алексеева Е. А.\",\"full_name\":\"Алексеева Екатерина Андреевич\",\"apartment\":\"12\",\"building\":\"1\",\"address\":\"корп. 1, кв. 12\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00030-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:5a5cf797e531','2026-10-09 19:54:32','2026-10-09 19:54:35','2026-10-09 19:54:32'),
(20,'a5e513ef-e061-4d7c-a52b-01e3b4aabeea',1,'log',33,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Лебедев Н. И.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 13.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Лебедев Н. И.\",\"full_name\":\"Лебедев Николай Ивановна\",\"apartment\":\"13\",\"building\":\"2\",\"address\":\"корп. 2, кв. 13\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00011\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:bdd28d57a087','2026-10-09 19:54:32','2026-10-09 19:54:35','2026-10-09 19:54:32'),
(21,'7b43f1ab-79b2-42d9-aa21-ecdedf10e547',1,'log',53,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Лебедев Н. И.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 13.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Лебедев Н. И.\",\"full_name\":\"Лебедев Николай Ивановна\",\"apartment\":\"13\",\"building\":\"2\",\"address\":\"корп. 2, кв. 13\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00031-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:8f25933b28da','2026-10-09 19:54:32','2026-10-09 19:54:35','2026-10-09 19:54:32'),
(22,'db7e3a44-e84f-4b6d-a5e3-62075cf89532',1,'log',34,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Семёнова Т. П.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 14.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Семёнова Т. П.\",\"full_name\":\"Семёнова Татьяна Петровна\",\"apartment\":\"14\",\"building\":\"2\",\"address\":\"корп. 2, кв. 14\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00012\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:824e4dde7368','2026-10-09 19:54:32','2026-10-09 19:54:35','2026-10-09 19:54:32'),
(23,'8ee9ccd4-533e-49ad-8d54-d754dc30a14c',1,'log',54,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Семёнова Т. П.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 14.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Семёнова Т. П.\",\"full_name\":\"Семёнова Татьяна Петровна\",\"apartment\":\"14\",\"building\":\"2\",\"address\":\"корп. 2, кв. 14\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00032-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:b96a1c570cb3','2026-10-09 19:54:32','2026-10-09 19:54:35','2026-10-09 19:54:32'),
(24,'a6550465-6926-4766-9263-711b106abe45',1,'log',35,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Егоров В. С.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 15.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Егоров В. С.\",\"full_name\":\"Егоров Виктор Сергеевна\",\"apartment\":\"15\",\"building\":\"2\",\"address\":\"корп. 2, кв. 15\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00013\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 193,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:69531e9e0577','2026-10-09 19:54:32','2026-10-09 19:54:35','2026-10-09 19:54:32'),
(25,'bd6e4b2d-cf1b-4cc2-a686-ed47999e19d7',1,'log',55,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Егоров В. С.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 15.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Егоров В. С.\",\"full_name\":\"Егоров Виктор Сергеевна\",\"apartment\":\"15\",\"building\":\"2\",\"address\":\"корп. 2, кв. 15\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00033-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 193,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:5d750d2dc7e6','2026-10-09 19:54:32','2026-10-09 19:54:36','2026-10-09 19:54:32'),
(26,'bc4bfdec-fc64-4101-8ba3-389dc4478e99',1,'log',36,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Павлова Ю. Н.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 16.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Павлова Ю. Н.\",\"full_name\":\"Павлова Юлия Николаевич\",\"apartment\":\"16\",\"building\":\"2\",\"address\":\"корп. 2, кв. 16\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00014\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:71a1ffb126e3','2026-10-09 19:54:32','2026-10-09 19:54:36','2026-10-09 19:54:32'),
(27,'e8287f76-557a-486b-9161-95d9aff65f25',1,'log',56,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Павлова Ю. Н.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 16.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Павлова Ю. Н.\",\"full_name\":\"Павлова Юлия Николаевич\",\"apartment\":\"16\",\"building\":\"2\",\"address\":\"корп. 2, кв. 16\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00034-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:74a3fe847b86','2026-10-09 19:54:32','2026-10-09 19:54:36','2026-10-09 19:54:32'),
(28,'d8f654c9-9a11-4c9a-ad4c-9a749a014253',1,'log',64,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Николаев А. С.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 818,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 19.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Николаев А. С.\",\"full_name\":\"Николаев Алексей Сергеевич\",\"apartment\":\"19\",\"building\":\"2\",\"address\":\"корп. 2, кв. 19\",\"amount\":\"818,18 ₽\",\"amount_raw\":818.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00042\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:d35b52a4415d','2026-10-09 19:54:32','2026-10-09 19:54:36','2026-10-09 19:54:32'),
(29,'295257f1-03ee-4d01-afcd-ea39728ccd48',1,'log',38,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Орлова О. А.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 20.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Орлова О. А.\",\"full_name\":\"Орлова Ольга Андреевич\",\"apartment\":\"20\",\"building\":\"2\",\"address\":\"корп. 2, кв. 20\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00016\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:37e531dab379','2026-10-09 19:54:32','2026-10-09 19:54:36','2026-10-09 19:54:32'),
(30,'4c46335e-38a5-45fb-af81-3861077af748',1,'log',58,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Орлова О. А.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 20.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Орлова О. А.\",\"full_name\":\"Орлова Ольга Андреевич\",\"apartment\":\"20\",\"building\":\"2\",\"address\":\"корп. 2, кв. 20\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00036-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:533e4df2ed39','2026-10-09 19:54:32','2026-10-09 19:54:36','2026-10-09 19:54:32'),
(31,'042bcd91-5640-4f15-955a-cb94a2d64f3a',1,'log',39,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Андреев Д. И.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 21.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Андреев Д. И.\",\"full_name\":\"Андреев Дмитрий Ивановна\",\"apartment\":\"21\",\"building\":\"2\",\"address\":\"корп. 2, кв. 21\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00017\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:5dddf6e108ab','2026-10-09 19:54:32','2026-10-09 19:54:36','2026-10-09 19:54:32'),
(32,'7a531f61-a665-4a55-8a4f-b3f30c99d392',1,'log',59,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Андреев Д. И.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 21.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Андреев Д. И.\",\"full_name\":\"Андреев Дмитрий Ивановна\",\"apartment\":\"21\",\"building\":\"2\",\"address\":\"корп. 2, кв. 21\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00037-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-818,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:782ef9d87f6d','2026-10-09 19:54:32','2026-10-09 19:54:37','2026-10-09 19:54:32'),
(33,'4408b9c9-2be7-4a1e-8f55-ff44be541d60',1,'log',40,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Макарова А. П.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 22.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Макарова А. П.\",\"full_name\":\"Макарова Анна Петровна\",\"apartment\":\"22\",\"building\":\"2\",\"address\":\"корп. 2, кв. 22\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00018\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 193,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:411afd037549','2026-10-09 19:54:32','2026-10-09 19:54:37','2026-10-09 19:54:32'),
(34,'042e2a78-aa66-4fce-9697-b0de18c5963a',1,'log',60,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Макарова А. П.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 22.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Макарова А. П.\",\"full_name\":\"Макарова Анна Петровна\",\"apartment\":\"22\",\"building\":\"2\",\"address\":\"корп. 2, кв. 22\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00038-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 193,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:b7511f06ee6c','2026-10-09 19:54:32','2026-10-09 19:54:37','2026-10-09 19:54:32'),
(35,'f5744a84-4f23-4712-8a4a-433c8caa45cf',1,'log',41,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Захаров С. С.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 23.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Захаров С. С.\",\"full_name\":\"Захаров Сергей Сергеевна\",\"apartment\":\"23\",\"building\":\"2\",\"address\":\"корп. 2, кв. 23\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00019\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:3f3adff7b68d','2026-10-09 19:54:32','2026-10-09 19:54:37','2026-10-09 19:54:32'),
(36,'b151d966-9d6f-41c6-af65-331216ffe997',1,'log',61,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Захаров С. С.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 23.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Захаров С. С.\",\"full_name\":\"Захаров Сергей Сергеевна\",\"apartment\":\"23\",\"building\":\"2\",\"address\":\"корп. 2, кв. 23\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00039-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:8a9724f55975','2026-10-09 19:54:32','2026-10-09 19:54:37','2026-10-09 19:54:32'),
(37,'30baf7da-ca47-4a42-a6bf-7f59e66afdc0',1,'log',42,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Зайцева Е. Н.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 750 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 24.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Зайцева Е. Н.\",\"full_name\":\"Зайцева Елена Николаевич\",\"apartment\":\"24\",\"building\":\"2\",\"address\":\"корп. 2, кв. 24\",\"amount\":\"750 ₽\",\"amount_raw\":750,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00020\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:444f931672a6','2026-10-09 19:54:32','2026-10-09 19:54:37','2026-10-09 19:54:32'),
(38,'bddae055-3725-462d-bef8-5e3d970adb2e',1,'log',62,'no-recipient:0','Оплата обслуживания шлагбаума — Сентябрь 2026','Здравствуйте, Зайцева Е. Н.!\n\nНачислена оплата за обслуживание шлагбаума за Сентябрь 2026: 68,18 ₽ RUB.\nСрок оплаты: 2026-10-23.\n\nОплатить: \n\nКвартира 24.\nЭто автоматическое сообщение.','payment_new','{\"name\":\"Зайцева Е. Н.\",\"full_name\":\"Зайцева Елена Николаевич\",\"apartment\":\"24\",\"building\":\"2\",\"address\":\"корп. 2, кв. 24\",\"amount\":\"68,18 ₽\",\"amount_raw\":68.18,\"currency\":\"RUB\",\"period\":\"Сентябрь 2026\",\"due_date\":\"2026-10-23\",\"deadline\":\"2026-10-23\",\"invoice_no\":\"INV-2026-00040-Д\",\"charge_no\":\"CHG-2026-0001\",\"balance\":\"-1 568,18 ₽\",\"debt\":\"0 ₽\",\"pay_link\":\"\",\"organisation\":\"\",\"support_phone\":\"\",\"support_email\":\"\",\"gate\":\"\",\"today\":\"09.10.2026\"}','sent',0,5,NULL,'log:e59ac4aa0eb9','2026-10-09 19:54:32','2026-10-09 19:54:38','2026-10-09 19:54:32');
/*!40000 ALTER TABLE `outbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `resident_id` bigint(20) unsigned NOT NULL,
  `invoice_id` bigint(20) unsigned DEFAULT NULL,
  `charge_id` bigint(20) unsigned DEFAULT NULL,
  `amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `paid_at` date DEFAULT NULL,
  `method` varchar(24) NOT NULL DEFAULT 'transfer',
  `reference` varchar(120) DEFAULT NULL,
  `payer_name` varchar(190) DEFAULT NULL,
  `note` longtext DEFAULT NULL,
  `external_id` varchar(96) DEFAULT NULL,
  `is_confirmed` tinyint(1) NOT NULL DEFAULT 1,
  `recorded_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payments_uuid_unique` (`uuid`),
  KEY `payments_resident_id_paid_at_index` (`resident_id`,`paid_at`),
  KEY `payments_invoice_id_index` (`invoice_id`),
  KEY `payments_paid_at_index` (`paid_at`),
  CONSTRAINT `payments_resident_id_fk` FOREIGN KEY (`resident_id`) REFERENCES `residents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES
(1,'0fbedfb4-9725-425d-8712-3db2dfd3d53b',1,1,1,750.00,'2026-10-23','transfer','ПЛ-F49357','Иванов Иван Иванович','Демо-оплата',NULL,1,NULL,'2026-10-23 00:00:00','2026-10-23 00:00:00'),
(2,'1fd4dfcb-feec-4ef6-aa43-402ec1ef817a',2,2,1,750.00,'2026-10-24','card','ПЛ-7B44FC','Петрова Мария Петрович','Демо-оплата',NULL,1,NULL,'2026-10-24 00:00:00','2026-10-24 00:00:00'),
(3,'d8d4978a-9a91-45d2-8ab1-b218a55d530a',3,3,1,375.00,'2026-10-21','sbp','ПЛ-111CF3','Сидоров Алексей Сергеевич','Демо-оплата',NULL,1,NULL,'2026-10-21 00:00:00','2026-10-21 00:00:00'),
(4,'33bbfbda-4ecf-42b3-9315-91e768b6e5b5',7,6,1,750.00,'2026-10-01','transfer','ПЛ-25F12C','Соколов Сергей Сергеевна','Демо-оплата',NULL,1,NULL,'2026-10-01 00:00:00','2026-10-01 00:00:00'),
(5,'59159b54-002c-4e3d-9f78-399a2b0bf7a6',9,7,1,750.00,'2026-10-12','card','ПЛ-F3818F','Фёдоров Андрей Иванович','Демо-оплата',NULL,1,NULL,'2026-10-12 00:00:00','2026-10-12 00:00:00'),
(6,'3c506379-265d-4251-b894-0dda24d515c8',10,8,1,375.00,'2026-10-25','sbp','ПЛ-8CD795','Морозова Наталья Петрович','Демо-оплата',NULL,1,NULL,'2026-10-25 00:00:00','2026-10-25 00:00:00'),
(7,'a8e625b1-ba9b-4353-b7f0-7a0a826a9578',13,11,1,750.00,'2026-10-19','transfer','ПЛ-E86D63','Лебедев Николай Ивановна','Демо-оплата',NULL,1,NULL,'2026-10-19 00:00:00','2026-10-19 00:00:00'),
(8,'c6660b3f-cdde-4aa7-bd96-47d910910a65',14,12,1,750.00,'2026-10-25','card','ПЛ-389094','Семёнова Татьяна Петровна','Демо-оплата',NULL,1,NULL,'2026-10-25 00:00:00','2026-10-25 00:00:00'),
(9,'219d1136-f88a-4311-878c-b2f9a19c6e8f',15,13,1,375.00,'2026-10-16','sbp','ПЛ-0D76B1','Егоров Виктор Сергеевна','Демо-оплата',NULL,1,NULL,'2026-10-16 00:00:00','2026-10-16 00:00:00'),
(10,'8522336f-6316-4463-888a-6f3bed2e8dda',20,16,1,750.00,'2026-10-25','transfer','ПЛ-317E6F','Орлова Ольга Андреевич','Демо-оплата',NULL,1,NULL,'2026-10-25 00:00:00','2026-10-25 00:00:00'),
(11,'b7bf120f-421f-450d-8eee-460bd74be624',21,17,1,750.00,'2026-10-09','card','ПЛ-DA0590','Андреев Дмитрий Ивановна','Демо-оплата',NULL,1,NULL,'2026-10-09 00:00:00','2026-10-09 00:00:00'),
(12,'d6aa610a-8b66-40e9-a4cf-49e781d1287d',22,18,1,375.00,'2026-10-23','sbp','ПЛ-8692B0','Макарова Анна Петровна','Демо-оплата',NULL,1,NULL,'2026-10-23 00:00:00','2026-10-23 00:00:00'),
(13,'0fd790a3-332d-4a3b-9eff-bb44743fcff8',1,23,2,750.00,'2026-10-09','cash',NULL,NULL,NULL,NULL,1,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32'),
(14,'42bc6507-c737-408e-a504-5ca207d42c9a',2,24,2,750.00,'2026-10-09','transfer',NULL,NULL,NULL,NULL,1,NULL,'2026-10-09 19:54:32','2026-10-09 19:54:32');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `residents`
--

DROP TABLE IF EXISTS `residents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `residents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `external_id` varchar(64) DEFAULT NULL,
  `last_name` varchar(120) NOT NULL DEFAULT '',
  `first_name` varchar(120) NOT NULL DEFAULT '',
  `patronymic` varchar(120) DEFAULT NULL,
  `full_name` varchar(255) NOT NULL DEFAULT '',
  `search_index` varchar(512) DEFAULT NULL,
  `apartment` varchar(24) NOT NULL DEFAULT '',
  `apartment_no` int(11) DEFAULT NULL,
  `building` varchar(24) DEFAULT NULL,
  `entrance` varchar(16) DEFAULT NULL,
  `floor` int(11) DEFAULT NULL,
  `area` decimal(10,2) NOT NULL DEFAULT 0.00,
  `persons` int(11) NOT NULL DEFAULT 1,
  `share` decimal(10,4) NOT NULL DEFAULT 1.0000,
  `role_in_home` varchar(24) NOT NULL DEFAULT 'owner',
  `phone` varchar(32) DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `access_granted` tinyint(1) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_billed` tinyint(1) NOT NULL DEFAULT 1,
  `allow_guest_pass` tinyint(1) NOT NULL DEFAULT 1,
  `notify_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `notes` longtext DEFAULT NULL,
  `tags` longtext DEFAULT NULL,
  `balance` decimal(12,2) NOT NULL DEFAULT 0.00,
  `last_payment_at` datetime DEFAULT NULL,
  `last_gate_event_at` datetime DEFAULT NULL,
  `avatar_path` varchar(255) DEFAULT NULL,
  `meta` longtext DEFAULT NULL,
  `guest_passes_issued` int(11) NOT NULL DEFAULT 0,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `archived_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `residents_uuid_unique` (`uuid`),
  KEY `residents_is_active_is_billed_index` (`is_active`,`is_billed`),
  KEY `residents_apartment_no_building_index` (`apartment_no`,`building`),
  KEY `residents_last_name_index` (`last_name`),
  KEY `residents_email_index` (`email`),
  KEY `residents_deleted_at_index` (`deleted_at`),
  KEY `residents_access_granted_index` (`access_granted`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `residents`
--

LOCK TABLES `residents` WRITE;
/*!40000 ALTER TABLE `residents` DISABLE KEYS */;
INSERT INTO `residents` VALUES
(1,'0acd58ec-ee33-4580-9b23-1d915a592a69',NULL,'Иванов','Иван','Иванович','Иванов Иван Иванович','иванов иван иванович кв 1 79092335715 ivanov.i1@example.com','1',1,'1','1',1,28.00,1,1.0000,'owner','+79092335715','Ivanov.i1@example.com',1,1,1,1,1,'Просил напоминать об оплате за 3 дня.','[\"староста\",\"актив\"]',-218.19,'2026-10-09 00:00:00','2026-10-09 19:54:38',NULL,NULL,1,NULL,NULL,'2026-07-12 19:54:30','2026-09-10 19:54:30',NULL,NULL),
(2,'9ea3d8d8-7d06-4c23-995b-fa61c93159b1',NULL,'Петрова','Мария','Петрович','Петрова Мария Петрович','петрова мария петрович кв 2 79079136210 petrova.m2@example.com','2',2,'1','2',2,39.50,2,1.0000,'owner','+79079136210','Petrova.m2@example.com',1,1,1,1,1,NULL,NULL,31.81,'2026-10-09 00:00:00','2026-10-09 19:26:49',NULL,NULL,0,NULL,NULL,'2025-08-20 19:54:30','2026-09-14 19:54:30',NULL,NULL),
(3,'9fb4f880-5770-42a9-aa89-aaf5a15ec50a',NULL,'Сидоров','Алексей','Сергеевич','Сидоров Алексей Сергеевич','сидоров алексей сергеевич кв 3 79063911526 sidorov.a3@example.com','3',3,'1','3',3,51.00,3,1.0000,'owner','+79063911526','Sidorov.a3@example.com',1,1,1,1,1,NULL,NULL,-1193.19,'2026-10-21 00:00:00','2026-10-08 21:31:29',NULL,NULL,0,NULL,NULL,'2025-03-06 19:54:30','2026-09-28 19:54:30',NULL,NULL),
(4,'cef636bb-f128-4c4d-a3f6-2cac56cababc',NULL,'Кузнецова','Ольга','Андреевич','Кузнецова Ольга Андреевич','кузнецова ольга андреевич кв 4 79038283891 kuznecova.o4@example.com','4',4,'1','4',4,62.50,4,1.0000,'owner','+79038283891','Kuznecova.o4@example.com',1,1,0,1,1,NULL,NULL,0.00,NULL,'2026-10-07 09:06:05',NULL,NULL,0,NULL,NULL,'2024-10-07 19:54:30','2026-09-26 19:54:30',NULL,NULL),
(5,'a737919c-de0a-4495-aa02-43c12e9e6b83',NULL,'Смирнов','Дмитрий','Ивановна','Смирнов Дмитрий Ивановна','смирнов дмитрий ивановна кв 5 79077765350 smirnov.d5@example.com','5',5,'1','1',5,74.00,1,1.0000,'tenant','+79077765350','Smirnov.d5@example.com',1,1,1,1,1,NULL,NULL,-1568.19,NULL,'2026-10-07 23:30:34',NULL,NULL,0,NULL,NULL,'2026-03-12 19:54:30','2026-09-27 19:54:30',NULL,NULL),
(6,'894e2962-26f2-4f9f-a1a9-6e8a5ddd7298',NULL,'Васильева','Анна','Петровна','Васильева Анна Петровна','васильева анна петровна кв 6 79069345335 vasileva.a6@example.com','6',6,'1','2',6,85.50,2,1.0000,'owner','+79069345335','Vasileva.a6@example.com',0,1,1,1,1,NULL,NULL,-1568.18,NULL,'2026-10-04 10:52:43',NULL,NULL,0,NULL,NULL,'2025-10-03 19:54:30','2026-09-25 19:54:30',NULL,NULL),
(7,'42c22d84-eb5b-4ab1-bc8c-562ac302bc37',NULL,'Соколов','Сергей','Сергеевна','Соколов Сергей Сергеевна','соколов сергей сергеевна кв 7 79058386241 sokolov.s7@example.com','7',7,'1','3',7,97.00,3,1.0000,'owner','+79058386241','Sokolov.s7@example.com',1,1,1,1,1,'Просил напоминать об оплате за 3 дня.',NULL,-818.18,'2026-10-01 00:00:00','2026-10-09 20:19:46',NULL,NULL,0,NULL,NULL,'2025-03-21 19:54:30','2026-10-01 19:54:30',NULL,NULL),
(8,'9e741262-c61f-4ac6-8a8d-14a9083c493a',NULL,'Михайлова','Елена','Николаевич','Михайлова Елена Николаевич','михайлова елена николаевич кв 8 79027575380 mihaylova.e8@example.com','8',8,'1','4',8,28.00,4,1.0000,'owner','+79027575380','Mihaylova.e8@example.com',1,1,1,1,1,NULL,'[\"староста\",\"актив\"]',-818.18,NULL,'2026-10-06 22:40:31',NULL,NULL,0,NULL,NULL,'2026-06-28 19:54:30','2026-09-16 19:54:30',NULL,NULL),
(9,'f79ec544-a490-452b-8cfd-f6e0e9dd0a86',NULL,'Фёдоров','Андрей','Иванович','Фёдоров Андрей Иванович','фёдоров андрей иванович кв 9 79091052626 fedorov.a9@example.com','9',9,'1','1',9,39.50,1,1.0000,'owner','+79091052626','Fedorov.a9@example.com',1,1,1,1,0,NULL,NULL,-818.18,'2026-10-12 00:00:00','2026-10-09 08:13:53',NULL,NULL,0,NULL,NULL,'2025-07-21 19:54:30','2026-09-13 19:54:30',NULL,NULL),
(10,'0a9ed7da-b75a-4655-b467-fcf43cf8d4af',NULL,'Морозова','Наталья','Петрович','Морозова Наталья Петрович','морозова наталья петрович кв 10 79026889499 morozova.n10@example.com','10',10,'1','2',1,51.00,2,1.0000,'tenant','+79026889499','Morozova.n10@example.com',1,1,1,1,1,NULL,NULL,-1193.18,'2026-10-25 00:00:00','2026-10-08 06:24:17',NULL,NULL,0,NULL,NULL,'2024-07-26 19:54:30','2026-10-01 19:54:30',NULL,NULL),
(11,'3d4007b7-5580-49fb-b9f8-68ddf9b02648',NULL,'Волков','Павел','Сергеевич','Волков Павел Сергеевич','волков павел сергеевич кв 11 79023922895 volkov.p11@example.com','11',11,'1','3',2,62.50,3,1.0000,'owner','+79023922895','Volkov.p11@example.com',1,1,1,1,1,NULL,NULL,-1568.18,NULL,'2026-10-09 19:16:32',NULL,NULL,0,NULL,NULL,'2025-01-23 19:54:30','2026-09-18 19:54:30',NULL,NULL),
(12,'36df5a40-3f68-4d58-a42c-775e2cb3c4a6',NULL,'Алексеева','Екатерина','Андреевич','Алексеева Екатерина Андреевич','алексеева екатерина андреевич кв 12 79092148503 alekseeva.e12@example.com','12',12,'1','4',3,74.00,4,1.0000,'owner','+79092148503','Alekseeva.e12@example.com',1,1,1,1,1,NULL,NULL,-1568.18,NULL,'2026-10-08 15:09:38',NULL,NULL,0,NULL,NULL,'2025-09-13 19:54:30','2026-09-27 19:54:30',NULL,NULL),
(13,'fe205309-ebbe-4780-a307-72401ac6a031',NULL,'Лебедев','Николай','Ивановна','Лебедев Николай Ивановна','лебедев николай ивановна кв 13 79063514435 lebedev.n13@example.com','13',13,'2','1',4,85.50,1,1.0000,'owner','+79063514435','Lebedev.n13@example.com',1,1,1,1,1,'Просил напоминать об оплате за 3 дня.',NULL,-818.18,'2026-10-19 00:00:00','2026-10-09 20:20:44',NULL,NULL,0,NULL,NULL,'2025-03-16 19:54:30','2026-09-16 19:54:30',NULL,NULL),
(14,'58a73ec0-292a-4009-bc90-aec4b97f6816',NULL,'Семёнова','Татьяна','Петровна','Семёнова Татьяна Петровна','семёнова татьяна петровна кв 14 79082546520 semenova.t14@example.com','14',14,'2','2',5,97.00,2,1.0000,'owner','+79082546520','Semenova.t14@example.com',1,1,1,1,1,NULL,NULL,-818.18,'2026-10-25 00:00:00','2026-10-05 23:28:28',NULL,NULL,0,NULL,NULL,'2026-04-25 19:54:30','2026-09-28 19:54:30',NULL,NULL),
(15,'a852e133-de54-42ab-a525-34c96c8480ce',NULL,'Егоров','Виктор','Сергеевна','Егоров Виктор Сергеевна','егоров виктор сергеевна кв 15 79024787652 egorov.v15@example.com','15',15,'2','3',6,28.00,3,1.0000,'tenant','+79024787652','Egorov.v15@example.com',1,1,1,1,1,NULL,'[\"староста\",\"актив\"]',-1193.18,'2026-10-16 00:00:00','2026-10-06 22:01:39',NULL,NULL,0,NULL,NULL,'2025-01-14 19:54:30','2026-09-23 19:54:30',NULL,NULL),
(16,'ad57243e-139b-4900-843b-641c3ce0f844',NULL,'Павлова','Юлия','Николаевич','Павлова Юлия Николаевич','павлова юлия николаевич кв 16 79041217404 pavlova.y16@example.com','16',16,'2','4',7,39.50,4,1.0000,'owner','+79041217404','Pavlova.y16@example.com',1,1,1,1,1,NULL,NULL,-1568.18,NULL,'2026-10-07 23:16:23',NULL,NULL,0,NULL,NULL,'2025-01-23 19:54:30','2026-09-14 19:54:30',NULL,NULL),
(17,'a5e62fae-46cf-4017-9713-a0aee68d809e',NULL,'Козлов','Иван','Иванович','Козлов Иван Иванович','козлов иван иванович кв 17 79048484930 kozlov.i17@example.com','17',17,'2','1',8,51.00,1,1.0000,'owner','+79048484930','Kozlov.i17@example.com',1,1,0,1,1,NULL,NULL,0.00,NULL,'2026-10-09 14:28:37',NULL,NULL,0,NULL,NULL,'2025-10-30 19:54:30','2026-10-05 19:54:30',NULL,NULL),
(18,'13c32526-c703-4823-aa74-9cfd6a08a221',NULL,'Степанова','Мария','Петрович','Степанова Мария Петрович','степанова мария петрович кв 18 79061339372 stepanova.m18@example.com','18',18,'2','2',9,62.50,2,1.0000,'owner','+79061339372','Stepanova.m18@example.com',1,1,1,1,0,NULL,NULL,-1568.18,NULL,'2026-10-09 10:45:13',NULL,NULL,0,NULL,NULL,'2024-10-17 19:54:30','2026-09-12 19:54:30',NULL,NULL),
(19,'59ae66d6-7fc2-42e2-802a-61df25739947',NULL,'Николаев','Алексей','Сергеевич','Николаев Алексей Сергеевич','николаев алексей сергеевич кв 19 79049666810 nikolaev.a19@example.com','19',19,'2','3',1,74.00,3,1.0000,'owner','+79049666810','Nikolaev.a19@example.com',1,1,1,1,1,'Просил напоминать об оплате за 3 дня.',NULL,-818.18,NULL,'2026-10-07 15:51:59',NULL,NULL,0,NULL,NULL,'2025-04-15 19:54:30','2026-09-17 19:54:30',NULL,NULL),
(20,'56fc3a72-d346-430a-a3ce-f4aa17255e56',NULL,'Орлова','Ольга','Андреевич','Орлова Ольга Андреевич','орлова ольга андреевич кв 20 79078834953 orlova.o20@example.com','20',20,'2','4',2,85.50,4,1.0000,'tenant','+79078834953','Orlova.o20@example.com',1,1,1,1,1,NULL,NULL,-818.18,'2026-10-25 00:00:00','2026-10-09 20:31:03',NULL,NULL,0,NULL,NULL,'2026-05-30 19:54:30','2026-09-14 19:54:30',NULL,NULL),
(21,'1c8be039-eded-46bb-a2ab-ee5d640e8a58',NULL,'Андреев','Дмитрий','Ивановна','Андреев Дмитрий Ивановна','андреев дмитрий ивановна кв 21 79072541424 andreev.d21@example.com','21',21,'2','1',3,97.00,1,1.0000,'owner','+79072541424','Andreev.d21@example.com',1,1,1,1,1,NULL,NULL,-818.18,'2026-10-09 00:00:00','2026-10-09 06:05:33',NULL,NULL,0,NULL,NULL,'2026-04-15 19:54:30','2026-10-02 19:54:30',NULL,NULL),
(22,'c853bc92-4cf0-4edf-bbb9-832c707e297d',NULL,'Макарова','Анна','Петровна','Макарова Анна Петровна','макарова анна петровна кв 22 79075481733 makarova.a22@example.com','22',22,'2','2',4,28.00,2,1.0000,'owner','+79075481733','Makarova.a22@example.com',1,1,1,1,1,NULL,'[\"староста\",\"актив\"]',-1193.18,'2026-10-23 00:00:00','2026-10-04 20:17:45',NULL,NULL,0,NULL,NULL,'2024-10-10 19:54:30','2026-09-09 19:54:30',NULL,NULL),
(23,'f7147d00-890e-4521-9123-1cdf218e791d',NULL,'Захаров','Сергей','Сергеевна','Захаров Сергей Сергеевна','захаров сергей сергеевна кв 23 79072570629 zaharov.s23@example.com','23',23,'2','3',5,39.50,3,1.0000,'owner','+79072570629','Zaharov.s23@example.com',0,1,1,1,1,NULL,NULL,-1568.18,NULL,'2026-10-06 08:15:32',NULL,NULL,0,NULL,NULL,'2025-07-26 19:54:30','2026-10-05 19:54:30',NULL,NULL),
(24,'44d87473-a6ab-4e1c-ad39-7748cf1972f6',NULL,'Зайцева','Елена','Николаевич','Зайцева Елена Николаевич','зайцева елена николаевич кв 24 79098009940 zayceva.e24@example.com','24',24,'2','4',6,51.00,4,1.0000,'owner','+79098009940','Zayceva.e24@example.com',1,1,1,1,1,NULL,NULL,-1568.18,NULL,'2026-10-07 17:15:39',NULL,NULL,0,NULL,NULL,'2025-11-11 19:54:30','2026-10-07 19:54:30',NULL,NULL);
/*!40000 ALTER TABLE `residents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions_meta`
--

DROP TABLE IF EXISTS `sessions_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` varchar(128) NOT NULL DEFAULT '',
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(512) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `last_used_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sessions_meta_session_id_unique` (`session_id`),
  KEY `sessions_meta_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions_meta`
--

LOCK TABLES `sessions_meta` WRITE;
/*!40000 ALTER TABLE `sessions_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `key` varchar(120) NOT NULL,
  `value` longtext DEFAULT NULL,
  `type` varchar(12) NOT NULL DEFAULT 'string',
  `group` varchar(40) NOT NULL DEFAULT 'general',
  `is_secret` tinyint(1) NOT NULL DEFAULT 0,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `updated_by` varchar(64) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`key`),
  KEY `settings_group_index` (`group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES
('billing.charge_counter','1','int','billing',0,0,NULL,'2026-10-09 19:54:32'),
('billing.invoice_counter','42','int','billing',0,0,NULL,'2026-10-09 19:54:32'),
('billing.last_allocation','equal','string','billing',0,0,NULL,'2026-10-09 19:54:32'),
('billing.last_period','Сентябрь 2026','string','billing',0,0,NULL,'2026-10-09 19:54:32'),
('billing.last_total','15000','float','billing',0,0,NULL,'2026-10-09 19:54:32');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL DEFAULT '',
  `login` varchar(64) NOT NULL DEFAULT '',
  `email` varchar(190) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL DEFAULT '',
  `full_name` varchar(190) NOT NULL DEFAULT '',
  `role` varchar(16) NOT NULL DEFAULT 'resident',
  `resident_id` bigint(20) unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `must_change_password` tinyint(1) NOT NULL DEFAULT 0,
  `remember_token` varchar(100) DEFAULT NULL,
  `totp_secret` varchar(255) DEFAULT NULL,
  `totp_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `recovery_codes` longtext DEFAULT NULL,
  `failed_attempts` int(11) NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `last_login_ip` varchar(45) DEFAULT NULL,
  `password_changed_at` datetime DEFAULT NULL,
  `preferences` longtext DEFAULT NULL,
  `locale` varchar(8) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_login_unique` (`login`),
  KEY `users_role_is_active_index` (`role`,`is_active`),
  KEY `users_resident_id_index` (`resident_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'6cc0313b-7373-4c8f-ba79-19a7baf6aad6','admin','admin@example.com','$argon2id$v=19$m=65536,t=4,p=1$ci9Dd20wamg2YmtGcVJxZw$9iKqpH8enaNUYAWsjv3QeKjcv5Uk/RLgOV2aseBOx34','Smoke Admin','admin',NULL,1,0,NULL,NULL,0,NULL,0,NULL,NULL,NULL,'2026-10-09 19:54:31',NULL,NULL,'2026-10-09 19:54:31','2026-10-09 19:54:31',NULL),
(2,'332be578-9358-4989-9658-ffda6c5a1ed0','dispatcher',NULL,'$argon2id$v=19$m=65536,t=4,p=1$OUdRb3RVczhmWnA5ZHU0ZA$AaG1ieD8yzDXQfzdHcKga7GVQ4xnZFAz2ByodqhEKCs','Dispatcher','operator',NULL,1,1,NULL,NULL,0,NULL,0,NULL,NULL,NULL,'2026-10-09 19:54:31',NULL,NULL,'2026-10-09 19:54:31','2026-10-09 19:54:31',NULL),
(3,'233dd625-0eba-4438-8da9-4545af280f01','resident',NULL,'$argon2id$v=19$m=65536,t=4,p=1$cGZrMmwxNlgxR2JmR2NZdg$g2hz1t/Cs+2WZcvJQgIXciFbqHRQY0Uc/8bwSHtBxxg','Resident','resident',1,1,1,NULL,NULL,0,NULL,0,NULL,NULL,NULL,'2026-10-09 19:54:31',NULL,NULL,'2026-10-09 19:54:31','2026-10-09 19:54:31',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'basip_smoke'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-09 16:54:38
